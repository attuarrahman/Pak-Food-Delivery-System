<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


/*
* Forgot password
*/
Route::get('/check-account','CheckAccountController@checkAccount');
Route::post('/send-email-to-account','CheckAccountController@sendEmail');
Route::get('/verification-code','NewPasswordController@verificationCode');
Route::post('/code-verification','NewPasswordController@verifyCode');
Route::post('/new-password-view','NewPasswordController@newPassword');
Route::post('/search_country','SearchController@search_country');




Route::get('/','indexController@index');
Route::get('/search','SearchController@store'); 
Route::get('/serachcity','SearchController@searchcity'); 

// Customer Routes
Route::group(['prefix' => 'customer'], function (){

    Route::post('/login', 'Auth\CustomerLoginController@login')->name('customer.login');
    Route::post('/register','Auth\CustomerRegisterController@register')->name('customer.register');
    Route::get('/register', function (){
        return view('auth.customer-reg');
    })->name('customer.register');


    Route::get('/login', function (){
        return view('auth.customer-login');
    })->name('customer.login');
    Route::resource('customer_profile','CustomerProfileController');

    Route::resource('my-cart','HomeCartController');
    Route::resource('my-accounts','MyAccountController');
    Route::resource('check-out','HomeOrderController');
    Route::resource('super-cart','SuperCartController');
    Route::resource('super-order','HotelSuperCartController');
    Route::resource('customerMessenger','CustomerMessangerController');

    Route::get('get-customer-notification','CustomerNotification@getNotification');


});


// Hotel Routes

Auth::routes();
Route::get('/dashboard', 'HomeController@index')->name('dashboard');


// Admin Routes
Route::group(['prefix' => 'admin'], function(){
    Route::resource('hotel','AdminHotelController');
    Route::resource('country','AdminCountryController');
    Route::resource('province','AdminProvinceController');
    Route::resource('money','MoneyController');
    Route::resource('city','AdminCityController');

    Route::resource('Block','BlockController');
    Route::resource('request_hotel','RequestHotelController');

});

// Hotel Routes
Route::group(['prefix' => 'hotel'], function(){

    Route::resource('my-account','HotelAccountController');
    Route::resource('employee','HotelEmployeeController');
    Route::resource('expenses','ExpensesController');
    Route::resource('food','HotelFoodController');
    Route::resource('user-menu','HotelMenuController');
    Route::resource('chat','HotelMessengerController');
    Route::resource('order-request','HotelOrderRequestController');
    Route::resource('schedule','HotelScheduleController');
    Route::resource('order-history','HotelOrderHistoryController');
    Route::resource('special-order','HotelSpecialOrderController');
    Route::resource('check-out','HomeOrderController');
    Route::resource('hotel-rating','RatingController'); 
    Route::get('get-order-notification','HotelNotification@orderNotification');

});

// General Routes

Route::get('get-province-name','AjaxController@getProvince');
Route::get('search-city','SearchCityController@serach');
Route::get('get-category','CategoryController@store');
Route::get('get-city-name','AjaxController@getCity');
Route::resource('hotels','HomeHotelController');
Route::resource('product','HomeProductController');
