<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>@yield('title','Home')</title>
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="shortcut icon" href=""/>
    <link rel="stylesheet" href="{{ asset('css/site.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}">
    <script src="{{ asset('js/html5shiv.js') }}"></script>
    <script src="{{ asset('js/respond.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/site.min.js') }}"></script>
    
<!------ Include the above in your HEAD tag ---------->
</head>
<style>
    .disabled {
        pointer-events: none;
        cursor: default;
        opacity: 0.3;
    }
</style>
<style type="text/css">

     .badge1 {
   position:relative;
}
.badge1[data-badge]:after {
   content:attr(data-badge);
   position:absolute;
   top:-30px;
   right:-170px;
   font-size:.7em;
   background:red;
   color:white;
   width:18px;height:18px;
   text-align:center;
   line-height:18px;
   border-radius:50%;
   box-shadow:0 0 1px #333;
}
  .badge3 {
   position:relative;
}
.badge3[data-badge]:after {
   content:attr(data-badge);
   position:absolute;
   top:-30px;
   right:-120px;
   font-size:.7em;
   background:red;
   color:white;
   width:18px;height:18px;
   text-align:center;
   line-height:18px;
   border-radius:50%;
   box-shadow:0 0 1px #333;
}
</style>


<body>
<nav role="navigation" class="navbar navbar-custom">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button data-target="#bs-content-row-navbar-collapse-5" data-toggle="collapse" class="navbar-toggle"
                    type="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="#" style="color:white" class="navbar-brand">{{Auth::user()->name}}</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div id="bs-content-row-navbar-collapse-5" class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">

                <!-- <li class="disabled"><a href="#">Link</a></li> -->
                <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">Notification <sup>43</sup></a>
                    <ul role="menu" class="dropdown-menu">
                        <li id="new_notification"></li>
                    </ul>
                </li>

            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<br>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-3  sidebar-offcanvas" role="navigation">
            <ul class="list-group panel">
                <li style="color:white ;background-color: steelblue" class="list-group-item"><h3>SIDE PANEL</h3></li>
                
                <li class="list-group-item">
                    <h5><a href="{{ route('dashboard') }}" style="display: block;">Dashboard</a></h5>
                </li>
                @if(Auth::user()->status == 0)
                 <li class="list-group-item">
                    <h5 class="disabled"><a href="" style="display: block;">My Account</a></h5>
                </li>
                <li class="list-group-item">
                    <h5 class="disabled"><a href="" style="display: block;">Expenses</a></h5>
                </li>
                <li class="list-group-item">
                    <h5 class="disabled"><a href="" style="display: block;">Employee</a></h5>
                </li>
                <li class="list-group-item">
                    <h5 class="disabled"><a href="" style="display: block;">Food</a></h5>
                </li>
                <li class="list-group-item">
                    <h5 class="disabled"><a href="" style="display: block;">Schedule</a></h5>
                </li>
                <li class="list-group-item">
                    <h5  class="disabled"><a href="" style="display: block;">Menu Setup</a></h5>
                </li>

                <li class="list-group-item">
                    <h5  class="disabled"><a href="" style="display: block;">Order Requests</a></h5>
                </li>
                <li class="list-group-item">
                    <h5  class="disabled"><a href="" style="display: block;">Special Order Requests</a>
                    </h5>
                </li>
                <li class="list-group-item">
                    <h5 class="disabled"><a href="" style="display: block;">Order History</a></h5>
                </li>
               


                @else


                <li class="list-group-item">
                    <h5><a href="{{ route('my-account.show',Auth::id()) }}" style="display: block;">My Account</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="{{ route('expenses.index') }}" style="display: block;">Expenses</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="{{ route('employee.index') }}" style="display: block;">Employee</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="{{ route('food.index') }}" style="display: block;">Food</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="{{ route('schedule.index') }}" style="display: block;">Schedule</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="{{ route('user-menu.index') }}" style="display: block;">Menu Setup</a></h5>
                </li>

                <li class="list-group-item">
                    <h5><a href="{{ route('order-request.index') }}" style="display: block;">Order Requests</a></h5>
                      <?php $orders = DB::table('orders')->where('user_id',Auth::id())->get(); ?>
                    <?php $count = $orders->count(); ?>
                    @if($count > 0)
                    <a href="" class="badge3" data-badge="{{$count}}" ></a>
                    @else
                    @endif

                </li>
                <li class="list-group-item">
                    <h5><a href="{{ route('special-order.index') }}" style="display: block;">Special Order Requests</a>
                    </h5>
                    <?php $orders = DB::table('special_orders')->where('user_id',Auth::id())->get(); ?>
                    <?php $count = $orders->count(); ?>
                    @if($count > 0)
                    <a href="" class="badge1" data-badge="{{$count}}"></a>
                    @else
                    @endif
                </li>
                <li class="list-group-item">
                    <h5><a href="{{ route('order-history.index') }}" style="display: block;">Order History</a></h5>
                </li>
               

@endif


                <li class="list-group-item">
                    <h5>
                        <a style="display: block;" href="{{ route('logout') }}"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            {{ __('Logout') }}
                        </a>

                        <form id="logout-form" action="{{ route('logout') }}" method="POST"
                              style="display: none;">
                            @csrf
                        </form>
                    </h5>
                </li>
            </ul>
        </div>
        <div class="col-md-9">
            @yield('body_content')
        </div>
    </div>
</div>


{{--JQuery & JavaScript Files--}}
<script src="{{ asset('js/jquery-1.10.1.min.js') }}"></script>
<script src="{{ asset('js/bootstrap.min.js') }}"></script>
<script src="{{ asset('js/vendor.bundle.addons.js') }}"></script>
<script src="{{ asset('js/vendor.bundle.base.js') }}"></script>
<script src="{{ asset('js/application.js') }}"></script>
<script src="{{ asset('js/icheck.min.js') }}"></script>
<script src="{{ asset('js/jquery.fs.selecter.min.js') }}"></script>
<script src="{{ asset('js/jquery.fs.stepper.min.js') }}"></script>

@yield('script_content')

<script>

    $(document).ready(function () {
        getNewNotifications();
    });

    function getNewNotifications() {
        window.setInterval(getNotification, 5000);
    }

    function getNotification() {
        var data = "user_id=" + {{ Auth::id() }};
        $.ajax({
            type: "GET",
            url: '{{ URL::to('/hotel/get-order-notification') }}',
            data: data,
            success: function (data) {
                if (data != 1) {
                    var audio = new Audio('{{ asset('assets/notification.wav') }}');
                    audio.play();
                    document.getElementById('new_notification').innerHTML += data;
                }
            }
        });
    }

</script>

</body>
</html>