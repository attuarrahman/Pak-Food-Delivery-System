@extends('layouts.master-layout')
@section('title','Hotel Reviews')
@section('body_content')

    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>
                        Recent Reviews <br>
                    </h1>
                    <p>
                        @if($ratings->count() > 0)
                        <?php
                        $total_stars = 0;
                        foreach ($ratings as $item) {
                            $total_stars = $total_stars + $item->starts;
                        }
                        $rating = $total_stars / $ratings->count();
                        ?>
                        Rating ({{ $rating }} <i class="fa fa-star"></i>)
                    </p>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="shop_area shop_reverse">
        <div class="container">

            <!--shop tab product start-->
            <div class="tab-content">
                <div class="tab-pane grid_view fade show active" id="large" role="tabpanel">
                    <div class="row">
                        @foreach($ratings as $rating)
                            <div class="col-md-3">
                                <div class="sidebar_widget widget_categories">
                                    <h3 class="widget_title">
                                        {{ $rating->customer->name }} <span style="float: right;">@for($i = 1;$i <= $rating->starts;$i++)<i class="fa fa-star" style="color: green"></i>@endfor</span>
                                    </h3>
                                    <ul>
                                        <li>
                                            {{ $rating->review }}
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        @else
        <h4 style="text-align: center;">No Customer Reviews and Rating are found</h4>
        @endif
        </div>
    </div>

@endsection
@section('script_content')

    <script></script>

@endsection