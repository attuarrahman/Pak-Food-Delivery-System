@extends('layouts.master-layout')
@section('title','Product Details')
@section('body_content')
 
    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>Product Details</h1>
                </div>
            </div>
        </div>
    </div>
    <hr>
    @if(session('info'))
        <p class="alert alert-success">{{ session('info') }}</p>
    @endif
    @if(session('warning'))
        <p class="alert alert-warning">{{ session('warning') }}</p>
    @endif
    <div class="product_details">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-5">
                    <div class="product-details-tab">

                        <div id="img-1" class="zoomWrapper single-zoom">
                            <a href="#">
                                <img id="zoom1" src="{{ asset('uploads/food/'.$product->image) }}">
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 col-md-7">
                    <div class="product_d_right">
                        <h1>{{ $product->name }}</h1>
                        <div class="product_price">
                            <span class="current_price">Rs. {{ $product->userMenuDetail->price }}</span>
                            @if($product->userMenuDetail->price != $product->price)
                                <span class="old_price">Rs. {{ $product->price }}</span>
                            @endif
                        </div>
                        <div class="product_desc">
                            <p>{{ $product->description }}</p>
                        </div>
                        {{ Form::open(['action' => 'HomeCartController@store']) }}
                        <input type="hidden" name="price" value="{{ $product->userMenuDetail->price }}">
                        <input type="hidden" name="food_id" value="{{ $product->id }}">
                        <div class="form-group">
                            <label for="">No of Parsal</label>
                            <input type="number" name="quantity" min="1" max="5" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-md btn-success">Add to Cart</button>
                            |
                            Price are count on per parsal
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
                <div class="col-lg-3 offset-lg-0 col-md-6 offset-md-3">
                    <div class="best_seller_product">
                        <div class="best_seller_titile">
                            <h3>Recent Rating</h3>
                            <div class="single_bestseller slick-slide slick-cloned slick-active" data-slick-index="-1"
                                 aria-hidden="false" tabindex="-1" style="width: 238px;">
                                <div class="bestseller_thumb">
                                    <a href="product-details.html" tabindex="0">
                                        <img class="primary_img" src="">
                                    </a>
                                </div>
                                <div class="bestseller_content">
                                    <div class="product_ratting">
                                        <ul>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection