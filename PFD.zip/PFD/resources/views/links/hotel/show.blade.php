@extends('layouts.master-layout')
@section('title','Hotel Details')
@section('body_content')

    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1><p style="color:#7ecc13;"> {{$hotel->name}}</p> Products</h1>
                    <p>
                        @if(session('hotel')->rating->count() > 0)
                        <?php
                        $total_stars = 0;
                        foreach (session('hotel')->rating as $item) {
                            $total_stars = $total_stars + $item->starts;
                        }
                        $rating = $total_stars / session('hotel')->rating->count();
                        ?>
                        <span>Rating ({{ round($rating,1) }} <i class="fa fa-star"></i>)</span>
                        @else
                        (0 <i class="fa fa-star"></i>)
                        @endif
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div   class="row">
        <div class="col-md-2">
            <b style="margin-left: 30px">Serach food by category</b>
         </div>
         <div class="col-md-3">
            <div class="form-group" >
                <select class="form-control"  id="catID" >
                   
                    <option >Select Food Category</option>
                    
                   @foreach(session('hotel')->foods as $food)

                    <option  value="{{$food->id}}">{{$food->category->name}}</option>
                    @endforeach
                 
                </select>
                

            </div>
           
        </div>
        <button id="findBtn"  class="btn btn-success" height ="5" style="margin-bottom: 20px">Find</button>
  
    </div>   
    <hr>
    @if(session('info'))
        <p class="alert alert-success">{{ session('info') }}</p>
    @endif
    @if(session('warning'))
        <p class="alert alert-warning">{{ session('warning') }}</p>
    @endif 
    <div class="shop_area shop_reverse">
        <div class="container">

            <!--shop tab product start-->
            <div class="tab-content">
                <div class="tab-pane grid_view fade show active" id="large" role="tabpanel">
                    <div class="row">
                        <div  id="productData" class="col-md-8">
                            <div class="row">
                                @if($hotel->userMenu) 
                                @if($hotel->userMenu->userMenuDetails()->count() > 0)
                                @foreach($hotel->userMenu->userMenuDetails as $detail)
                  
                                    <div  class="col-lg-3 col-md-4">
                                        <div class="single_product">
                                            <div class="product_thumb">
                                                <a href=""><img src="{{ asset('uploads/food/'.$detail->food->image) }}"
                                                                alt=""></a>
                                            </div>
                                            <div id="category_id" class="product_content">
                                                <h3>
                                                    <a href="{{ route('product.show',$detail->food_id) }}">{{ $detail->food->name }}</a>
                                                </h3>
                                                <span class="current_price">Rs. {{ $detail->price }}/-</span><br>
                                                {{ Form::open(['action' => 'HomeCartController@store']) }}
                                                <input type="hidden" name="price" value="{{ $detail->price }}">
                                                <input type="hidden" name="quantity" value="1">
                                                <input type="hidden" name="food_id" value="{{ $detail->food_id }}">
                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-md btn-success">Add to Cart
                                                    </button>
                                                </div>
                                                {{ Form::close() }}
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                                @endif
                                @else
                                <h5 style="color:red">product is not found that</h5>
                                @endif
                               
                            </div>
                        </div>
                        <div class="col-md-4">
                            @if(\Illuminate\Support\Facades\Auth::guard('customer')->user())
                                <button type="button" class="btn btn-block btn-md btn-success"
                                        data-toggle="modal" data-target="#rate-model">
                                    Rate Hotel &nbsp; <i class="fa fa-star"></i><i class="fa fa-star"></i><i
                                            class="fa fa-star"></i>
                                </button>
                                <br>
                            @endif
                            <div class="sidebar_widget widget_categories">
                                <h3 class="widget_title">Our Menu For the Day!</h3>
                                <ul>
                                    @if($hotel->userMenu)
                                    @foreach($hotel->userMenu->userMenuDetails as $detail)
                                        <li>
                                            <a href="{{ route('product.show',$detail->food_id) }}">{{ $detail->food->name }}</a>
                                            (PKR: {{ $detail->price }})
                                        </li>
                                    @endforeach
                                    @else
                                    @endif
                                </ul>
                            </div>
                            <div class="sidebar_widget widget_categories">
                                <h3 class="widget_title">
                                    Request through Special Order? <br>
                                    <p>"Special service through special order, some are":</p>
                                </h3>
                                <ul>
                                    <li>On time delivery</li>
                                    <li>Order beyond the limits</li>
                                    <li>Special Cooking</li>
                                    <li>More Cost but good food.</li>
                                    <br>
                                    <li>
                                        @if(Auth::guard('customer')->user())
                                        @if($hotel->userMenu)
                                        <h4><a href="{{ route('super-cart.index') }}"
                                               class="btn btn-block btn-md btn-primary">Click to Order!</a></h4>
                                               @else
                                                  <h4><a href="#"
                                               class="btn btn-block btn-md btn-primary ">NO item</a></h4>

                                               @endif
                                               @else
                                               <h4><a href="{{ route('customer.login') }}" style="color:white" 
                                               class="btn btn-block btn-md btn-success">Click to Order!</a></h4>
                                               @endif
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--shop tab product end-->
        </div>
    </div>

    <div class="modal fade" id="rate-model" tabindex="-1" role="dialog" aria-labelledby="modal-default"
         aria-hidden="true">
        <div class="modal-dialog modal- modal-dialog-centered modal-" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="modal-title-default">Write A Review</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <button class="btn btn-md btn-default" onclick="addStars(1)" id="btn_1"><i
                                    class="fa fa-star"></i></button>
                        <button class="btn btn-md btn-default" onclick="addStars(2)" id="btn_2"><i
                                    class="fa fa-star"></i></button>
                        <button class="btn btn-md btn-default" onclick="addStars(3)" id="btn_3"><i
                                    class="fa fa-star"></i></button>
                        <button class="btn btn-md btn-default" onclick="addStars(4)" id="btn_4"><i
                                    class="fa fa-star"></i></button>
                        <button class="btn btn-md btn-default" onclick="addStars(5)" id="btn_5"><i
                                    class="fa fa-star"></i></button>
                    </div>
                    {{ Form::open(['action' => 'RatingController@store']) }}
                    <input type="hidden" name="stars" id="stars" value="">
                    <div class="form-group">
                        <label for="">Review</label>
                        <textarea name="review" rows="4" class="form-control">
                        </textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-md btn-default">Rate Now</button>
                    {{ Form::close() }}
                    <button type="button" class="btn btn-md btn-link" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


@endsection
@section('script_content')
    <script>

        function addStars(stars) {
            document.getElementById('stars').value = stars;
            if (stars == 1) {
                $('#btn_1').addClass('btn-success', true);
                $('#btn_2').addClass('btn-default', true);
                $('#btn_3').addClass('btn-default', true);
                $('#btn_4').addClass('btn-default', true);
                $('#btn_5').addClass('btn-default', true);
            }
            if (stars == 2) {
                $('#btn_2').addClass('btn-success', true);
                $('#btn_1').addClass('btn-default', true);
                $('#btn_3').addClass('btn-default', true);
                $('#btn_4').addClass('btn-default', true);
                $('#btn_5').addClass('btn-default', true);
            }
            if (stars == 3) {
                $('#btn_3').addClass('btn-success', true);
                $('#btn_2').addClass('btn-default', true);
                $('#btn_1').addClass('btn-default', true);
                $('#btn_4').addClass('btn-default', true);
                $('#btn_5').addClass('btn-default', true);
            }
            if (stars == 4) {
                $('#btn_4').addClass('btn-success', true);
                $('#btn_2').addClass('btn-default', true);
                $('#btn_3').addClass('btn-default', true);
                $('#btn_1').addClass('btn-default', true);
                $('#btn_5').addClass('btn-default', true);
            }
            if (stars == 5) {
                $('#btn_5').addClass('btn-success', true);
                $('#btn_2').addClass('btn-default', true);
                $('#btn_3').addClass('btn-default', true); 
                $('#btn_4').addClass('btn-default', true);
                $('#btn_1').addClass('btn-default', true);
            }
        }

    </script>
<!-- <script type="text/javascript">
  function SearchCategory(){  
     document.getElementById('category_id').value;  
            $.ajax({
                type: "GET",
                url: '{{ URL::to('/get-category') }}',
                data: {category_id:category_id}
                success: function (data) {
                    document.getElementById('category_id').innerHTML = data;
                }
            });
}
</script>
 -->
 <script>
$(document).ready(function(){

  $("#findBtn").click(function(){
    var cat = $("#catID").val();
    $.ajax({
      type: 'get',
      dataType: 'html',
      url: '{{ URL::to('/get-category') }}',
      data: 'cat_id=' + cat,
      success:function(response){
        console.log(response);
        $("#productData").html(response);
      }
    });


  });

});
</script>


@endsection