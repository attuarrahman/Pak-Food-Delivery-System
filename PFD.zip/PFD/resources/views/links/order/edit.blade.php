@extends('layouts.master-layout')
@section('title','Order Details')
@section('body_content')

    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>Order Details</h1>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <section class="main_content_area">
        <div class="container">
            <div class="account_dashboard">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h2>{{ $order->user->name }}</h2>
                        
                       <!--  @if($order->status == 1  )
                        <b>Order Status:Your Order is Successfully completed</b>
                        @else
                        <b>Yoru Order is in Pending please wait...</b>
                        @endif  -->
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table_desc">
                            <div class="cart_page table-responsive">
                                <table>
                                    <thead>
                                    <tr>
                                        <th class="product_remove">S.No</th>
                                        <th class="product_thumb">Image</th>
                                        <th class="product_name">Product</th>
                                        <th class="product-price">Price</th>
                                        <th class="product_quantity">Quantity</th>
                                        <th class="product_total">Total</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $sno = 1; $grand_total = 0; ?>
                                    @foreach($order->orderHistoryDetails as $detail)
                                        <tr>
                                            <td>{{ $sno++ }}</td>
                                            <td><img src="{{ asset('uploads/food/'.$detail->food->image) }}" width="100px" height="100px"></td>
                                            <td>{{ $detail->food->name }}</td>
                                            <td>PKR {{ $detail->price }}/-</td>
                                            <td>{{ $detail->quantity }}</td>
                                            <?php $total = $detail->price * $detail->quantity; ?>
                                            <td>PKR {{ $total }}/-</td>
                                        </tr>
                                        <?php $grand_total = $grand_total + $total; ?>
                                    @endforeach
                                    </tbody>
                                </table>
                                <hr>
                                <h3 style="text-align: right">Total: {{ $grand_total }}/-</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
@section('script_content')

    <script></script>

@endsection