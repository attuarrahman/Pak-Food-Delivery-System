@extends('layouts.master-layout')
@section('title','My Account')
@section('body_content')
    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>My Account</h1>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
       <div style="margin-left: 380px" class="col-md-6"> 
            <div class="card">
                <div style="background-color:#428bca;color: white" class="card-header">Profile Updation</div>

                <div class="card-body">
                 {{Form::open(['method'=>'put','files'=>true,'action'=>['CustomerProfileController@update',$profile->id]])}}
                 <div class="row">
                 <div class="col-md-6">
                 <div class="form-group">
                  <label>Name</label>
                  <input class="form-control" type="name" name="name" value="{{$profile->name}}" >
                  <label>Email</label>
                  <input class= "form-control" type="email" name="email" value="{{$profile->email}}">
                  <div class="form-group">
                  <label>Mobile</label>
                  <input class="form-control" type="text" name="mobile" value="{{$profile->mobile}}">
                  <label>CNIC No</label>
                  <input class="form-control" type="text" name="cnic" value="{{$profile->cnic}}">
                   </div>
                 <!--  <?php $countries=DB::table('countries')->get(); ?>
                  <label>Country</label>
                  <select class="form-control" name="country_id" value="country_id">
                  <option value="">Select Country</option>
                  @foreach($countries as $country)
                  <option  value="{{$country->id}}">{{$country->name}}</option>
                  @endforeach
                  </select>
                  <label>Province</label>
                  <select class="form-control" name="province_id" id="province_id" value="{{$profile->province->name}}">
                    <option value="">select province</option>
                  </select>
                  <label>City</label>
                 <select class="form-control" name="city_id" id="city_id" value="{{$profile->city->city_name}}" id="city_id" required>
                                        <option value="">Select City</option>
                                    </select> -->
                  <br>
                {{Form::submit('Update Profile',['class'=>'btn btn-primary'])}}
                 
                  
                </div>
                 </div>
                 <div class="col-md-6">
                 <label>DOB</label>
                  <input class="form-control" type="date" name="dob" value="{{$profile->dob}}">
                  <label>Address</label>
                  <input class="form-control" type="text" name="address" value="{{$profile->address}}">
                  <label>Picture</label>
                <input class="form-control" type="file" name="profile">
            </div>
              

              {{Form::close()}} 
                </div>
              </div>
            </div>
        </div>
    </div>


@endsection
@section('script_content')

   <script>

    function getProvince() {
        var country_id = document.getElementById('country_id').value;
        if (country_id == null) {
            document.getElementById('country_id').style.border = "1px solid red";
        } else {
            document.getElementById('country_id').style.border = "1px solid #ced4da";
            var data = "country_id=" + country_id;
            $.ajax({
                type: "GET",
                url: '{{ URL::to('/get-province-name') }}',
                data: data,
                success: function (data) {
                    document.getElementById('province_id').innerHTML = data;
                }
            });
        }
    }

    function getCity() {
        var province_id = document.getElementById('country_id').value;
        if (province_id == null) {
            document.getElementById('province_id').style.border = "1px solid red";
        } else {
            document.getElementById('province_id').style.border = "1px solid #ced4da";
            var data = "province_id=" + province_id;
            $.ajax({
                type: "GET",
                url: '{{ URL::to('/get-city-name') }}',
                data: data,
                success: function (data) {
                    document.getElementById('city_id').innerHTML = data;
                }
            });
        }
    }

</script>
@endsection