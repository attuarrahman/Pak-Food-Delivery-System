@extends('layouts.master-layout')
@section('title','My Account')
@section('body_content')

    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>My Account</h1>
                </div>
            </div>
        </div>
    </div>
    <hr>

    <section class="main_content_area">
        <div class="container">
            <div class="account_dashboard">
                <div class="row">
                    <div class="col-sm-12 col-md-3 col-lg-3">
                        @if(session('info'))
                            <p class="alert alert-success">{{ session('info') }}</p>
                    @endif
                    <!-- Nav tabs -->
                        <div class="dashboard_tab_button">
                            <ul role="tablist" class="nav flex-column dashboard-list">
                                

                                <li><a href="#dashboard" data-toggle="tab" class="nav-link active" style="background-color: black">Dashboard</a></li>
                                <li><a href="#orders" data-toggle="tab" class="nav-link ">Orders</a></li>
                                <li><a href="#downloads" data-toggle="tab" class="nav-link">Downloads</a></li>

                        <li><a href="#profile" data-toggle="tab" class="nav-link">Profile</a></li>

                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-9 col-lg-9">
                        <!-- Tab panes -->
                        <div class="tab-content dashboard_content">
                            <div class="tab-pane fade show active" id="dashboard">
                                <h3>Dashboard </h3>
                                <p>From your account dashboard. you can easily check &amp; view your <a
                                            href="my-account.html#">recent orders</a>, manage your <a
                                            href="my-account.html#">shipping and billing addresses</a> and <a
                                            href="my-account.html#">Edit your password and account details.</a></p>
                            </div>
                            <div class="tab-pane fade" id="orders">
                                <h3>Current Orders  
                               
                                </h3>
                                <hr>
                                
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Order</th>
                                            <th>Date</th>
                                            <th>Type</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php $i = 1; $customer = \Illuminate\Support\Facades\Auth::guard('customer')->user(); ?>
                                        @foreach($customer->orders()->orderBy('created_at','desc')->limit(10)->get() as $order)
                                            <tr>
                                                <td>{{ $i++ }}</td>
                                                <td>{{ $order->created_at->toFormattedDateString() }}</td>
                                                <td>Normal</td>
                                                <td><span class="success">
                                                        @if($order->status == 0)
                                                            Pending.
                                                        @else
                                                            Completed.
                                                        @endif
                                                    </span></td>
                                                <td><a href="{{ route('check-out.edit',$order->id) }}"
                                                       class="view">view</a></td>
                                            </tr>
                                        @endforeach
                                        @foreach($customer->specialOrders()->orderBy('created_at','desc')->limit(10)->get() as $specialorder)
                                            <tr>

                                                <td>{{ $i++ }}</td>
                                                <td>{{ $specialorder->created_at->toFormattedDateString() }}</td>
                                                <td>Special</td>
                                                <td><span class="success">
                                                        @if($specialorder->status == 0)
                                                            Pending.
                                                        @else
                                                            Completed.
                                                        @endif
                                                    </span></td>
                                                <td><a href="{{ route('check-out.show',$specialorder->id) }}"
                                                       class="view">view</a></td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>

                                <br>
                                <h3>Recent Orders</h3>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Order</th>
                                            <th>Date</th>
                                            <th>Type</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $i = 1; $customer = \Illuminate\Support\Facades\Auth::guard('customer')->user(); ?>
                                        @foreach($customer->orderHistories()->orderBy('created_at','desc')->limit(10)->get() as $order)
                                            <tr>
                                                <td>{{ $i++ }}</td>
                                                <td>{{ $order->created_at->toFormattedDateString() }}</td>
                                                <td>
                                                    @if($order->order_type == 1)
                                                        Special
                                                    @else
                                                        Normal
                                                    @endif
                                                </td>
                                                <td><span class="success">
                                                        @if($order->status == 0)
                                                            Pending.
                                                        @else
                                                            Completed.
                                                        @endif
                                                    </span></td>
                                                <td><a href="{{ route('check-out.edit',$order->id) }}"
                                                       class="view">view</a></td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>




     <!------------------------------- customer messenger side ------------------- -->

                            <!-- end of the customer messenger side -->
                            <div class="tab-pane fade" id="downloads">
                                <h3>Downloads</h3>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Downloads</th>
                                            <th>Expires</th>
                                            <th>Download</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>Shopnovilla - Free Real Estate PSD Template</td>
                                            <td>May 10, 2018</td>
                                            <td><span class="danger">Expired</span></td>
                                            <td><a href="my-account.html#" class="view">Click Here To Download Your
                                                    File</a></td>
                                        </tr>
                                        <tr>
                                            <td>Organic - ecommerce html template</td>
                                            <td>Sep 11, 2018</td>
                                            <td>Never</td>
                                            <td><a href="my-account.html#" class="view">Click Here To Download Your
                                                    File</a></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                             <div class="tab-pane fade" id="profile">
                                <h3>Customer Profile</h3>
                                <hr>
                                <div class="row">
                                    <div class="col-lg-6 col-md-12">
                             <div  class="contact_message content">         
                            <ul>
                                <li><i class="fa fa-user"></i>&nbsp &nbsp &nbsp Name : {{$customer->name}}</li>
                                <li><i class="fa fa-envelope-o"></i>&nbsp &nbsp &nbsp Email : {{$customer->email}}</li>
                                <li><i class="fa fa-globe"></i>&nbsp &nbsp &nbsp Country : {{$customer->country->name}}</li> 
                                <li><i class="fa fa-bullseye"></i>&nbsp &nbsp &nbsp Province : {{$customer->province->name}}</li>
                                <li><i class="fa fa-map-marker"></i>&nbsp &nbsp &nbsp City : {{$customer->city->city_name}}</li>
                                <li><i class="fa fa-phone"> </i>&nbsp &nbsp &nbsp Mobile :{{$customer->mobile}}</li>
                                <li><i class="fa fa-server"></i>&nbsp &nbsp &nbsp CNIC : {{$customer->cnic}}</li>
                                <li><i class="fa fa-genderless"></i>&nbsp &nbsp &nbsp Gender : {{$customer->gender}}</li>
                                <li><i class="fa fa-clock-o"></i>&nbsp &nbsp &nbsp DOB :{{$customer->dob}}</li>
                               <li><i class="fa fa-location-arrow"></i>&nbsp &nbsp &nbsp Addrees: {{$customer->address}}</li>
                           </ul>
                           <br>
                           <br>
                          <a href="{{route('customer_profile.edit',$customer->id)}}" class="btn btn-success">Update Profile</a>   
                        </div>
                    </div>
                          <div style="width: 150px; height: 80px; ">
                            <img src="{{asset('upload/customerImg/'.$customer->profile)}}" alt="No Image Found">  Profile Image       
                          </div>
                                    
                                </div>
                            </div>

                           
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
@section('script_content')

    <script></script>

@endsection