<option value="">Select City</option>
@foreach($cities as $city)
    <option value="{{ $city->id }}">{{ $city->city_name }}</option>
@endforeach