<option value="">Select Province</option>
@foreach($provinces as $province)
    <option value="{{ $province->id }}">{{ $province->name }}</option>
@endforeach