@foreach($notifications as $notification)

    <li>
        <a href="{{ route('check-out.edit',$notification->order_history_id) }}">
            {{ $notification->orderHistory->user->name }}
            <br>
            <span>Date: {{ $notification->created_at->toDateTimeString() }}</span>
        </a>
    </li>

@endforeach