@foreach($notifications as $notification)

    <li>
        <a href="{{ route('order-request.show',$notification->order_id) }}"
           style="font-size: 20px; background-color: #e4b9b9; color: #000;">
            {{ $notification->order->customer->name }}
            | {{ $notification->order->order_location }}
            <br>
            <span>Date: {{ $notification->created_at->toDateTimeString() }}</span>
        </a>
    </li>
    <li class="divider"></li>

@endforeach