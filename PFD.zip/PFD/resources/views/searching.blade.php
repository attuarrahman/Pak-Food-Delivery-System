@forelse($hotels as $hotel)
    <div  style="margin-left: 50px" class="col-md-3">
        <div class="demo-item">
            <h4 class="title">
                <a href="{{ route('hotels.show',$hotel->id) }}">{{ $hotel->name }} 
                    <img src="{{ asset('uploads/food/'.$hotel->logo) }}" class="img-responsive">
                </a>
            </h4>
                <b>Country Name:</b>{{$hotel->country->name}}<br>
                <b>Province:</b>{{$hotel->province->name}}<br>  
                <b>City:</b>{{$hotel->city->city_name}}<br>
                <b>Current Location:</b>{{$hotel->location}}
                         
        </div>
    </div>   
@empty
    <h4 style="text-align: center;color:red">Restaurant record not found.</h4>
@endforelse