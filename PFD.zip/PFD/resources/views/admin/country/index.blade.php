@extends('layouts.app')
@section('title','Countries')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div style="color:white;background-color: steelblue" class="card-header">
                    All Countries
                    <a href="{{ route('country.create') }}" class="btn btn-md btn-success" style="float: right;">Add
                        Country</a>
                </div>
                <div class="card-body">
                    <?php $i = 1; ?>
                    @forelse($countries as $country)
                        <p>({{ $i++ }}) {{ $country->name }} | Code: {{ $country->code }}</p>
                    @empty
                        <p>No record found</p>
                    @endforelse
                </div>
            </div>
        </div>
    </div>

@endsection