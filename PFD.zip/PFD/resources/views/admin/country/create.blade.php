@extends('layouts.app')
@section('title','Add Country')
@section('body_content')

    @if (session('info'))
        <div class="alert alert-success" role="alert">
            {{ session('info') }}
        </div>
    @endif    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div style="color:white;background-color: steelblue" class="card-header">Add Country
                    <a href="{{ route('country.index') }}" class="btn btn-md btn-success" style="float: right;">View All</a>
                </div>
                <div class="card-body">
                    {{ Form::open(['action' => 'AdminCountryController@store']) }}
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <lable>Country Name</lable>
                                <input type="text" name="name" placeholder="Country Name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <lable>Short Name</lable>
                                <input type="text" name="short_name" placeholder="Short Name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-md btn-primary">Add</button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <lable>Country Code</lable>
                                <input type="text" name="code" placeholder="Country Code" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script_content')

    <script></script>

@endsection