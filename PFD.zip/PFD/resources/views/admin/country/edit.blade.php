@extends('layouts.app')
@section('title','')
@section('body_content')

@endsection
@section('script_content')

    <script></script>

@endsection