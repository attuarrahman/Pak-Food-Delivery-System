@extends('layouts.app')
@section('title','Provinces')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div style="color:white; background-color: steelblue" class="card-header">All Provinces
                    <a href="{{ route('province.create') }}" class="btn btn-md btn-success" style="float: right;">Add Province</a>
                </div>
                <div class="card-body">
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script_content')

    <script></script>

@endsection