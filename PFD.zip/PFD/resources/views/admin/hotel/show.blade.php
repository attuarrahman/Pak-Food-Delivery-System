@extends('layouts.app')
@section('title','')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div style="color:white;background-color: steelblue" class="card-header">{{$hotel->name}}</div>
                <div class="card-body">
                   <table class="table">
                       <thead>
                           <th>Country</th>
                           <th>Province</th>
                           <th>Location</th>
                           <th>Phone</th>
                           <th>Email</th>
                           <th>Total many</th>

                       </thead>

                       <tr class="">
                           <td>{{$hotel->country->name}}</td>
                           <td>{{$hotel->province->name}}</td>
                           <td>{{$hotel->city->city_name}}</td>
                           <td>{{$hotel->phone}}</td>
                           <td>{{$hotel->email}}</td>
                          
                           <td>Rs|{{$hotel->orderHistories->count()}}</td>
                          
                          

                           


                       </tr>
                      
                  <tr>
                   <td>
                   {{Form::open(['method' => 'DELETE', 'action'=>['AdminHotelController@destroy',$hotel->id], 'role'=>'form', 'files'=>'true'])}}
            <button type="submit" class="btn btn-danger">Delete</button>
              
                  {{Form::close()}}
                  </td>
                  <td>

                       {{Form::open(['method' => 'PUT', 'action'=>['AdminHotelController@update',$hotel->id], 'role'=>'form', 'files'=>'true'])}}
                       <input type="hidden" name="Block" value="5">
            <button type="submit" class="btn btn-warning">Block</button>
            {{Form::close()}}
            </td>
            
             
                  </tr>
                 
                  </table>
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script_content')

    <script></script>

@endsection