@extends('layouts.app')
@section('title','')
@section('body_content')
<style type="text/css">
    
</style>

    <div class="row">
        <div class="col-md-12">
            @if(seesion ('success'))
            <p class="alert alert-success">{{session('success')}}</p>
            @endif
            <div class="card">
                <div style="color:white;background-color: steelblue" class="card-header">Dashboard</div>
                <div class="card-body">
                    <div class="row">
                       
                            <?php $hotel = DB::table('users')->where('status',2)->get(); ?>
                            @foreach($hotel as $hotels)
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header" style="background-color: blue; color: white">{{$hotels->name}}</div>
                                <div class="card-body">
                                    <img src="{{asset('uploads/food/'.$hotels->logo)}}" height="100" width="200">
                                    <p class="">Mobile Number|{{$hotels->phone}}</p>
                                    <div>
                                        <p class="">Deuration|{{ date('m-Y', strtotime($hotels->created_at))}}</p>
                                    </div>
                                    <a href="{{route('hotel.show',$hotels->id)}}" class="btn btn-primary">Views</a>
                                </div>
                            </div>
                        </div>
                        @endforeach
                       
                 
                    </div>

          </div>
            </div>
        </div>
    </div>

@endsection
@section('script_content')

    <script></script>

@endsection