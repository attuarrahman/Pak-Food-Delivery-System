@extends('layouts.app')
@section('title','Request Restaurant')
@section('body_content')
<style type="text/css">
    
</style> 

    <div class="row">
        <div class="col-md-12">
              @if(session('success'))
            <p class="alert alert-info">{{session('success')}}</p>
            @endif
            <div class="card">
                <div style="color:white;background-color: steelblue" class="card-header">Restaurant Request</div>
                <div class="card-body">
                    <div class="row">
                       
                            <?php $hotel = DB::table('users')->where('status',0)->get(); ?>
                            @forelse($hotel as $hotels)
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header" style="background-color: blue; color: white">{{$hotels->name}}</div>
                                <div class="card-body">
                                    <img src="{{asset('uploads/food/'.$hotels->logo)}}" height="100" width="200">
                                    <p class="">Mobile Number|{{ date('m-Y', strtotime($hotels->created_at))}}</p>
                                    <div>
                                        <p class="">Deuration</p>
                                    </div>
                                    <a href="{{route('request_hotel.show',$hotels->id)}}" class="btn btn-success">Views</a>
                                </div>
                            </div>
                        </div>
                        @empty
                        <h5 style="text-align: center;">No Restaurant Request Found!</h5>
                        @endforelse
                       
                 
                    </div>

          </div>
            </div>
        </div>
    </div>

@endsection
@section('script_content')

    <script></script>

@endsection