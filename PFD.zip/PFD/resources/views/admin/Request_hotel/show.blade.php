@extends('layouts.app')
@section('title',' Restaurant Request')
@section('body_content')

   
            <div class="card">
                <div style="color:white; background-color: steelblue" class="card-header">{{$hotel->name}}
                   <a href="{{url('/admin/request_hotel')}}" class="btn btn-md btn-success" style="float: right;">View All
                  </a>
                </div>
                <div class="card-body">
                   <table class="table">
                       <thead>
                           <th>Country</th>
                           <th>Province</th>
                           <th>Location</th>
                           <th>Phone</th> 
                           <th>Email</th>
                           <th>Total money</th>

                       </thead>

                       <tr class="">
                           <td>{{$hotel->country->name}}</td>
                           <td>{{$hotel->province->name}}</td>
                           <td>{{$hotel->city->city_name}}</td>
                           <td>{{$hotel->phone}}</td>
                           <td>{{$hotel->email}}</td>
                          
                           <td>Rs|{{$hotel->orderHistories->count()}}</td>
                       </tr>
                       <tr> 
                   <td>
                   {{Form::open(['method' => 'DELETE', 'action'=>['AdminHotelController@destroy',$hotel->id], 'role'=>'form', 'files'=>'true'])}}
                    <button type="submit" class="btn btn-danger">Delete Restaurant</button>
                  {{Form::close()}}
                  </td> 
                  <td>
                       {{Form::open(['method' => 'PUT', 'action'=>['RequestHotelController@update',$hotel->id], 'role'=>'form', 'files'=>'true'])}}
                       <input type="hidden" name="Block" value="5">
                 <button type="submit" class="btn btn-primary">Approve Restaurant</button>
                  {{Form::close()}}
                </td>
                  </tr>
                  </table>
                </div>
            </div>
      

@endsection
@section('script_content')

    <script></script>

@endsection