@extends('layouts.app')
@section('title','Block Restaurant')
@section('body_content')
<style type="text/css">
    
</style>

    <div class="row">
        <div class="col-md-12">
            @if(session('success'))
            <p class="alert alert-danger">{{session('success')}}</p>
            @endif
            <div class="card">
                <div  style="color:white;background-color: steelblue" class="card-header">All Block Restaurant</div>
                <div class="card-body">
                    <div class="row">
                       
                            <?php $hotel = DB::table('users')->where('status',2)->get(); ?>
                            @if($hotel->count() > 0)
                            @foreach($hotel as $hotels)
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header" style="background-color: gainsboro; color: white">{{$hotels->name}}</div>
                                <div class="card-body">
                                    <img src="{{asset('uploads/food/'.$hotels->logo)}}" height="100" width="200">
                                    <p class="">Mobile Number|{{ date('m-Y', strtotime($hotels->created_at))}}</p>
                                    <div>
                                        <p class="">Deuration</p>
                                    </div>
                                    <a href="{{route('Block.show',$hotels->id)}}" class="btn btn-primary">Views</a>
                                </div>
                            </div> 
                        </div>
                        @endforeach
                        @else
                        <h5 style="text-align:center">No Restaurnt Found!</h5>
                       @endif
                 
                    </div>

          </div>
            </div>
        </div>
        

@endsection
@section('script_content')

    <script></script>

@endsection