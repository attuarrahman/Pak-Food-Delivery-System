@extends('layouts.app')
@section('title','Block Restaurant')
@section('body_content')

    <div class="row">
        <div class="col-lg-12 col-xs-6  col-sm-12">
          @if(session('success'))
          <p class="alert alert-info">{{session('success')}}</p>
          @endif
            <div class="card">
                <div style="color:white;background-color: steelblue" class="card-header">Block Restaurant</div>
                <div class="card-body">
                  @if($hotel->count() > 0 or $hotel->stutus==2)
                   <table class="table">
                       <thead>
                          <th>Restaurnt Name</th>
                           <th>Country</th>
                           <th>Province</th>
                           <th>Location</th>
                           <th>Phone</th>
                           <th>Email</th>
                           <th>Total Money</th>
                           <th>Remaning Money</th>
                           <th>Recevied</th>
                           

                       </thead>

                       <tr >
                           <td>{{$hotel->name}}</td>
                           <td>{{$hotel->country->name}}</td>
                           <td>{{$hotel->province->name}}</td>
                           <td>{{$hotel->city->city_name}}</td>
                           <td>{{$hotel->phone}}</td>
                           <td>{{$hotel->email}}</td>
                          <?php $rupes=$hotel->orderHistories->count() ?>
                          <?php $recevied_money=DB::table('Money')->get(); ?>
                          <td>{{$rupes}}/PKR</td>
                          @if($recevied_money->count() > 0 )
                          @foreach($recevied_money as $money)
                          {{$money->money}}
                          <?php $paymoney=$rupes-$money->money ?>
                          @endforeach
                           
                           <td>{{$paymoney}}</td> 
                            @endif
                           
                           <td>
            <button style="margin-left:-30px" type="button" class="btn btn-md-success" data-toggle="modal" data-target="#modal-notification">recevied</button>
            <div class="modal fade" id="modal-notification" tabindex="-1" role="dialog" aria-labelledby="modal-notification" aria-hidden="true">
              <div class="modal-dialog modal-danger modal-dialog-centered modal-" role="document">
                <div class="modal-content bg-gradient-danger">
                  <div class="modal-header" style="background-color:goldenrod">
                    <h6 class="modal-title" id="modal-title-notification">Recevied Money From Restaurant</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="py-2 text-center">
                       {{Form::open(['method'=>'POST','action'=>['MoneyController@store','files'=>true]])}}
                        
                        <label><b>Enter Recevied Money</b></label>
                        <div class="form-group">
                        <input type="number" name="money" class="form-control">
                      </div>
                      <button type="submit" class="btn btn-white">Add</button>
                     {{Form::close()}}
                    </div>
                  </div>
                  <div class="modal-footer">
                    
                    <button type="button" class="btn btn-link text-white ml-auto" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>
             </td>
              </tr>
              <tr>
                <td>
              {{ Form::open(['method' => 'put', 'action' => ['BlockController@update',$hotel->id]]) }}
              <button type="submit" class="btn btn-danger">Block Restaurant</button>
            </td>
          </tr></table>
                  @else
                  <h5 style="text-align: center"> Restaurant not found!</h5>
                  @endif
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script_content')

    <script></script>

@endsection