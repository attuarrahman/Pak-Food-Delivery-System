@extends('layouts.app')
@section('title','Dashboard')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div style="color:white;background-color: steelblue" class="card-header">Dashboard</div>
                <div class="card-body">
                    <p>Welcome to the Admin dashboard</p>
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script_content')

    <script></script>

@endsection