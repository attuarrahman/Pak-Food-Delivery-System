@extends('layouts.app')
@section('title','Add City')
@section('body_content')

    @if (session('info'))
        <div class="alert alert-success" role="alert">
            {{ session('info') }}
        </div>
    @endif
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div style="color:white;background-color: steelblue" class="card-header">Add City
                    <a href="{{ route('city.index') }}" class="btn btn-md btn-success" style="float: right;">View
                        All</a></div>
                <div class="card-body">
                    {{ Form::open(['action' => 'AdminCityController@store']) }}
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <lable>Select Country</lable>
                                <select name="country_id" id="country_id" class="form-control" required
                                        onblur="getProvince()">
                                    <option value="">Select Country</option>
                                    @foreach($countries as $country)
                                        <option value="{{ $country->id }}">{{ $country->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <lable>City Name</lable>
                                <input type="text" name="city_name" placeholder="City Name" class="form-control">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-md btn-primary">Add</button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="">Select Province</label>
                                <select name="province_id" id="province_id" class="form-control" required>
                                    <option value="">Select Province</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <lable>City Code</lable>
                                <input type="text" name="city_code" placeholder="City Code" class="form-control">
                            </div>
                        </div>
                    </div>
                    {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script_content')


@endsection