@extends('layouts.app')
@section('title','Cities')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div style=" color:white; background-color: steelblue" class="card-header">All Citites
                    <a href="{{ route('city.create') }}" class="btn btn-md btn-success" style="float: right;">Add City</a></div>
                <div class="card-body">
                </div>
            </div>
        </div>
    </div>

@endsection
@section('script_content')

    <script></script>

@endsection