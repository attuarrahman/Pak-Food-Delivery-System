@extends('layouts.app')
@section('title','Verification Code')
@section('body_content')

    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-2">
                @if(Session::has('success'))
                    <p class="alert alert-primary">{{Session('success')}}</p>
                @endif
                    @if(Session::has('warning'))
                        <p class="alert alert-primary">{{Session('warning')}}</p>
                    @endif
                <div class="panel panel-primary">
                    <div class="panel-heading">Enter Verification Code</div>
                    <div class="panel-body">
                        <form action="{{ url('/code-verification') }}" method="post">
                            @csrf
                            <div class="form-group">
                                <input type="text" name="token" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-md btn-primary">Verify Code</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection