@extends('layouts.app')
@section('title','New Password')
@section('body_content')

    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-2">
                <div class="panel panel-primary">
                    <div class="panel-heading">Enter New Password</div>
                    <div class="panel-body">
                        <form action="{{ url('/new-password-view') }}" method="post">
                            @csrf
                            <div class="form-group">
                                <input type="hidden" name="user_id" value="{{ $user->id }}">
                            </div>
                            <div class="form-group">
                                <label for="">New Password</label>
                                <input type="text" name="password" class="form-control" required placeholder="New Password">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-md btn-primary">Change Password</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection