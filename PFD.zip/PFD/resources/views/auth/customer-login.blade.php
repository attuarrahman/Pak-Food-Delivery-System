@extends('layouts.form-template')
@section('title','Customer Login')
@section('body_content')

    <div class="breadcrumbs_area other_bread" style="margin-bottom: 100px;">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="customer_login" style="margin-top: 50px;">
        <div class="container">
            <div class="row">
                <div class="col-md-4"></div>
                <div style="" class="col-md-4"><br>
                    <h3><b style="margin-left: 80px;color:black">Customer Login</b></h3>
                    <hr>
                    <form method="POST" action="{{ route('customer.login') }}">
                        @csrf

                        <div class="form-group">
                            <label for="email">{{ __('E-Mail Address') }}</label>
                            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror"
                                   name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                            @error('email')
                            <span style="color:red" class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <input id="password" type="password"
                                   class="form-control @error('password') is-invalid @enderror" name="password" required
                                   autocomplete="current-password">

                            @error('password')
                            <span class="invalid-feedback" role="alert">
                                        <strong style="color: red;">{{ $message }}</strong>
                                    </span>
                            @enderror
                        </div>
                        <br>
                        <div class="form-group">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="remember"
                                       id="remember" {{ old('remember') ? 'checked' : '' }}>

                                <label class="form-check-label" for="remember">
                                    {{ __('Remember Me') }}
                                </label>
                            </div>
                        </div>
                        <br>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">
                                {{ __('Login') }}
                            </button>
                           <a class="btn btn-dark" href="{{ route('customer.register') }}" style="float:right; margin-right:">Sign Up</a>|

                            @if (Route::has('password.request'))
                                <a class="btn btn-link" href="{{ route('password.request') }}">
                                    {{ __('Forgot Your Password?') }}
                                </a>

                            @endif
                            <hr>
                             


                        </div>

                    </form>
                </div>
                <div class="col-md-2">
                     

                </div>
            </div>
            <br>
            <br>
        </div>
    </div>

@endsection
