@extends('layouts.form-template')
@section('title','Register as Hotel')
@section('body_content')

    <div class="breadcrumbs_area other_bread" style="margin-bottom: 100px;">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="customer_login" style="margin-top: 50px;">
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div> 
               <div  class="col-md-6"><br>
                    <h3 style="text-align: center; font-family: serif; color: black"><b>Restaurant Registration </b></h3>
                    <hr>
                    <form method="POST" action="{{ route('register') }}">
                        @csrf

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{ __('Hotel Name') }}</label>
                                    <small style="color: red;"> *</small>
                                    <input id="name" type="text"
                                           class="form-control @error('name') is-invalid @enderror"
                                           name="name" placeholder="Hotel Name" value="{{ old('name') }}"
                                           required autocomplete="name" autofocus>

                                    @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="password">{{ __('Password') }}</label>
                                    <small style="color: red;"> *</small>
                                    <input id="password" type="password"
                                           class="form-control @error('password') is-invalid @enderror"
                                           name="password"
                                           required autocomplete="new-password" placeholder="Password"
                                           aria-required="true">

                                    @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="">Select Country</label>
                                    <small style="color: red;"> *</small>
                                    <select name="country_id" id="country_id" onblur="getProvince()" required
                                            class="form-control @error('country_id') is-invalid @enderror">
                                        <option value="">Select Country</option>
                                        @foreach($countries as $country)
                                            <option value="{{ $country->id }}">{{ $country->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Select City</label>
                                    <small style="color: red;"> *</small>
                                    <select name="city_id" id="city_id" required
                                            class="form-control @error('city_id') is-invalid @enderror">
                                        <option value="">Select City</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Phone</label>
                                    <small style="color: red;"> *</small>
                                    <input type="text"
                                           class="form-control @error('phone') required is-invalid @enderror"
                                           name="phone" placeholder="Phone">
                                </div>
                                <div class="form-group">
                                    <label for="">Service</label>
                                    <small style="color: red;"> * Service hotel will provide</small>
                                    <textarea type="text" required
                                              class="form-control @error('service') is-invalid @enderror"
                                              name="service" placeholder="Service"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="">Opening Hours</label>
                                    <small style="color: red;"> * Opening hour of hotel.</small>
                                    <input type="text" required
                                           class="form-control @error('opening_timing') is-invalid @enderror"
                                           name="opening_timing" placeholder="Opening Hours">
                                </div>
                                <div class="form-group">
                                    <label for="">Description</label>
                                    <small style="color: red;"> * Full description of hotel.</small>
                                    <textarea type="text" required
                                              class="form-control @error('description') is-invalid @enderror"
                                              name="description" placeholder="Description"></textarea>
                                </div>

                               
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">{{ __('E-Mail Address') }}</label>
                                    <small style="color: red;"> *</small>
                                    <input id="email" type="email"
                                           class="form-control @error('email') is-invalid @enderror"
                                           name="email" placeholder="Email address" value="{{ old('email') }}"
                                           required autocomplete="email">

                                    @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="password-confirm">{{ __('Confirm Password') }}</label>
                                    <small style="color: red;"> *</small>
                                    <input id="password-confirm" type="password" class="form-control"
                                           name="password_confirmation" placeholder="Confirm Password" required
                                           autocomplete="new-password">
                                </div>
                                <div class="form-group">
                                    <label for="">Select Province</label>
                                    <small style="color: red;"> *</small>
                                    <select name="province_id" required id="province_id" onblur="getCity()"
                                            class="form-control @error('province_id') is-invalid @enderror">
                                        <option value="">Select Province</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Full Address</label>
                                    <small style="color: red;"> * Full address of hotel.</small>
                                    <textarea type="text" required
                                              class="form-control @error('location') is-invalid @enderror"
                                              name="location" placeholder="Full Address"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="">Opening Days</label>
                                    <small style="color: red;"> * Total no of days hotel will be open.</small>
                                    <input type="text" required
                                           class="form-control @error('opening_days') is-invalid @enderror"
                                           name="opening_days" placeholder="Opening Days">
                                </div>
                                <div class="form-group">
                                    <label for="">Closing Hours</label>
                                    <small style="color: red;"> * Closing hour of hotel.</small>
                                    <input type="text" required
                                           class="form-control @error('closing_timing') is-invalid @enderror"
                                           name="closing_timing" placeholder="Closing Hours">
                                </div>



                                 <div class="form-group">
                                    <button type="submit" class="btn btn-primary" style="font-family: serif; color: black">
                                        {{ __('Register Account') }}
                                    </button> | Already have account? <a href="{{ route('login') }}">Login</a>
                                </div>


                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-1"></div>
            </div>
            <br>
            <br>
        </div>
    </div>

@endsection
