@extends('layouts.form-template')
@section('title','Customer Registration')
@section('body_content')

    <div class="breadcrumbs_area other_bread" style="margin-bottom: 100px;">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="customer_login" style="margin-top: 50px;">
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div>
                <div style="" class="col-md-8"><br>
                    <h3 style="text-align: center; font-family:serif;"><b>Customer Registration</b></h3>
                    <hr>
                    <form method="POST" action="{{ route('customer.register') }}" enctype="multipart/form-data">
                        @csrf

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">{{ __('Customer Name') }}</label>
                                    <small style="color: red;"> *</small>
                                    <input id="name" type="text"
                                           class="form-control @error('name') is-invalid @enderror"
                                           name="name" placeholder="Customer Name" value="{{ old('name') }}"
                                           required autocomplete="name" autofocus>

                                    @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="password">{{ __('Password') }}</label>
                                    <small style="color: red;"> *</small>
                                    <input id="password" type="password"
                                           class="form-control @error('password') is-invalid @enderror"
                                           name="password"
                                           required autocomplete="new-password" placeholder="Password"
                                           aria-required="true">

                                    @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="">Select Country</label>
                                    <small style="color: red;"> *</small>
                                    <select name="country_id" id="country_id" onblur="getProvince()" required
                                            class="form-control @error('country_id') is-invalid @enderror">
                                        <option value="">Select Country</option>
                                        @foreach($countries as $country)
                                            <option value="{{ $country->id }}">{{ $country->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Select City</label>
                                    <small style="color: red;"> *</small>
                                    <select name="city_id" id="city_id" required
                                            class="form-control @error('city_id') is-invalid @enderror">
                                        <option value="">Select City</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Phone</label>
                                    <small style="color: red;"> *</small>
                                    <input type="text"
                                           class="form-control @error('phone') required is-invalid @enderror"
                                           name="phone" placeholder="Phone">
                                </div>
                                <div class="form-group">
                                    <label for="">CNIC</label>
                                    <small style="color: red;"> *</small>
                                    <input type="text" required
                                           class="form-control @error('cnic') is-invalid @enderror"
                                           name="cnic" placeholder="CNIC">
                                </div>
                                 <div class="form-group">
                                    <label for="">Picture</label>
                                    <small>optional</small>
                                    <input type="file" name="profile" value="profile" class="form-control">
                                </div>
                               
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">{{ __('E-Mail Address') }}</label>
                                    <small style="color: red;"> *</small>
                                    <input id="email" type="email"
                                           class="form-control @error('email') is-invalid @enderror"
                                           name="email" placeholder="Email address" value="{{ old('email') }}"
                                           required autocomplete="email">

                                    @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="password-confirm">{{ __('Confirm Password') }}</label>
                                    <small style="color: red;"> *</small>
                                    <input id="password-confirm" type="password" class="form-control"
                                           name="password_confirmation" placeholder="Confirm Password" required
                                           autocomplete="new-password">
                                </div>
                                <div class="form-group">
                                    <label for="">Select Province</label>
                                    <small style="color: red;"> *</small>
                                    <select name="province_id" required id="province_id" onblur="getCity()"
                                            class="form-control @error('province_id') is-invalid @enderror">
                                        <option value="">Select Province</option>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label for="">DOB</label>
                                    <small style="color: red;"> *</small>
                                    <input type="date" required
                                           class="form-control @error('dob') is-invalid @enderror"
                                           name="dob">
                                </div>
                                <div class="form-group">
                                    <label for="">Full Address</label>
                                    <small style="color: red;"> *.</small>
                                    <textarea type="text" required
                                              class="form-control @error('address') is-invalid @enderror"
                                              name="address" placeholder="Full Address"></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="">Select Gender</label>
                                    <small style="color: red;"> *</small>
                                    <br>
                                    Male <input type="radio" name="gender" value="Male">
                                    Female<input type="radio" name="gender" value="Female">
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary" style="font-family: serif; color: black">
                                        {{ __('Register Account') }}
                                    </button> | Already have account? <a href="{{ route('customer.login') }}">Login</a>
                                </div>

                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-1"></div>
            </div>
            <br>
        </div>
    </div>

@endsection
