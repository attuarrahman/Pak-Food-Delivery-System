<html>
<head>
    <title>Account Verification Code</title>
</head>
<body>
<h1>Your verification code is: {{ $token }}.</h1>
<p>Please Enter This code to reset your password.</p>
</body>
</html>