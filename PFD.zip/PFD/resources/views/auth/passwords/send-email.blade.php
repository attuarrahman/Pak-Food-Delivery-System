<form action="{{ url('/send-email-to-account') }}" method="post">
    @csrf
    <input type="hidden" value="{{ $user->id }}" name="user_id">
    <input type="hidden" value="{{ $user->token }}" name="token">
    <div class="form-group">
        <label for="">Email</label>
        <input type="text" name="email" value="{{ $user->email }}" class="form-control" readonly>
    </div>
    <div class="form-group">
        <button class="btn btn-md btn-primary">Send Reset Password Link</button>
    </div>
</form>