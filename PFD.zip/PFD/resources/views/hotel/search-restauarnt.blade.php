<option value="">Select City</option>
@foreach($restaurant_search as $restaurant)
    <option value="{{ $restaurant->id }}">{{ $restaurant->city_name }}</option>
@endforeach