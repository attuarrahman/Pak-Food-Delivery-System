@extends('layouts.admin-template')
@section('title','')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All
                    
                </div>
                <div class="panel-body">
                   <div class="panel">
                       <div class="panel-heading"></div>
                       <div class="panel-body">
                        @if($orders->count() > 0)
                           <table class="table table-striped">
  <thead>
    <label style="margin-left: 400px; color: blue">Simple Order</label>
    <tr>
      <th scope="col">S_No</th>
      <th scope="col">Customer Name</th>

    </tr>
  </thead>
  <tbody>
   
    <tr>
        <?php $i = 1; ?>
        @foreach($orders as $order)
      <th scope="row">{{$i++}}</th>
    
  
      <td>{{$order->customer->name}}</td>
      <td><a href="{{route('order-history.show',$order->id)}}" class="btn btn-primary">Views </a></td>
      @endforeach
    </tr>
   
  </tbody>
  
</table>
@else
<h4 style="text-align: center">No Normal Orders History is Found!</h4>
@endif
<br>
<hr>
<br>
@if($special->count() > 0)
<table class="table table-striped">
  <thead>
    <label style="margin-left: 400px; color: blue">Special Order</label>
    <tr>
      <th scope="col">S_NO</th>
      <th scope="col">Customer Name</th>
     
    </tr>
  </thead>
  <tbody>
    <tr>
        <?php $i = 1; ?>
        @foreach($special as $details)
      <th scope="row">{{$i++}}</th>
      <td>{{$details->customer->name}}</td>
      
      
      <td><a href="{{route('order-history.show',$details->id)}}" class="btn btn-primary">Views </a></td>
      @endforeach
    </tr>
   
  </tbody>
  
</table>
@else
<h4 style="text-align: center">No Speical Orders History is Found!</h4>
@endif


                       </div>
                   </div>

                </div>
            </div>
        </div>
    </div>

@endsection