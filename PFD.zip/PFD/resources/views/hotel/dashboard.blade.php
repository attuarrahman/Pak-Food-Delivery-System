@extends('layouts.admin-template')
@section('title','My Account')
@section('body_content')

<div class="row">
        <div class="col-md-12">

@if(Auth::user()->status == 0)
          <div class="card">
            <div class="card-header " style="font-size: 40px">Details </div>
            <div class="card-body">
              <p style="margin-left: 220px; font-size: 20px; font-family: serif;">your request is succefully send to admin
Please Wait for registration</p>

              <p style="margin-left: 220px; font-size: 20px; font-family: serif;">your restaurant will be register once approve from admin</p>
               


              
            </div>
          </div>
            
@else
<div class="row">
  <div class="col-md-4">
<div class="card">
  <div class="card-header">
    
  </div>
  <div class="card-body">
   <div class="penal">
     <div class="penal-heading btn btn-primary">information about food </div>
     <div class="penal-body"></div>
   </div>
  </div>
</div>
</div>

 <div class="col-md-4">
<div class="card">
  <div class="card-header">
    
  </div>
  <div class="card-body">
   <div class="penal">
     <div class="penal-heading btn btn-primary">information about acount  </div>
     <div class="penal-body"></div>
   </div>
  </div>
</div>
</div>
 <div class="col-md-4">
<div class="card">
  <div class="card-header">
    
  </div>
  <div class="card-body">
   <div class="penal ">
     <div class="penal-heading btn btn-primary
 ">information about admin </div>
     <div class="penal-body">
       
     </div>
   </div>
  </div>
</div>
</div>

</div>

@endif
        </div>
    </div>



@endsection