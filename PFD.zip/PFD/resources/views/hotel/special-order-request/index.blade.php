@extends('layouts.admin-template')
@section('title','All Orders')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All Special Orders
                </div>
                <div class="panel-body">
                    @if($orders->count() > 0)
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Details</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $sno = 1; ?>
                        @foreach($orders as $order)
                            <tr>
                                <td>{{ $sno++ }}</td>
                                <td>{{ $order->customer->name }}</td>
                                <td>{{ $order->created_at->toDateTimeString() }}</td>
                                <td>
                                    <a href="{{ route('special-order.show',$order->id) }}" class="btn btn-sm btn-primary">View</a>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    @else
                    <h4 style="text-align: center">No special ordes found</h4>
                    @endif
                </div>
            </div>
        </div>
    </div>

@endsection