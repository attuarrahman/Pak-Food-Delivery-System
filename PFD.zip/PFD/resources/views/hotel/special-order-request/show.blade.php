@extends('layouts.admin-template')
@section('title','Order Details')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Order Details
                    <a href="{{ route('special-order.index') }}" class="btn btn-md btn-primary" style="float: right;">
                        View All
                    </a>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h3>Customer Details</h3>
                            <hr>
                            <h4>Customer: {{ $order->customer->name }}</h4>
                            <h4>Mobile: {{ $order->customer->mobile }}</h4>
                            <h4>Address: {{ $order->customer->address }}</h4>
                        </div>
                        <div class="col-md-6">
                            <h3>Order Details</h3>
                            <hr>
                            <h4>Order Location: {{ $order->order_location }}</h4>
                            <h4>Order Description: {{ $order->description }}</h4>
                            <h4>Order Date: {{ $order->created_at->toDateTimeString() }}</h4>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Sub Total</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $sno = 1; $grand_total = 0; ?>
                                @foreach($order->orderDetails as $detail)
                                    <tr>
                                        <td>{{ $sno++ }}</td>
                                        <td>{{ $detail->food->name }}</td>
                                        <td>{{ $detail->quantity }}</td>
                                        <td>{{ $detail->price }}</td>
                                        <td>
                                            <?php $total = $detail->price * $detail->quantity;?>
                                            PKR {{ $total }}
                                        </td>
                                    </tr>
                                    <?php $grand_total = $grand_total + $total; ?>
                                @endforeach
                                </tbody>
                            </table>
                            <hr>
                            <h4 style="float: right;">Total: PKR {{ $grand_total }}</h4>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            {{ Form::open(['method' => 'put','action' => ['HotelSpecialOrderController@update',$order->id]]) }}
                            <button type="submit" class="btn btn-md btn-success">Complete Order</button>
                            {{ Form::close() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection