@extends('layouts.admin-template')
@section('title','Food Detail')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Schedule Detail
                    <a href="{{route('schedule.index') }}" class="btn btn-md btn-default" style="float: right;">
                        View All
                    </a>
                </div>

                
                <div class="panel-body">
                    @if($schedules->count() > 0)

                     <p style='text-align: center'><b>{{$schedules->day}} Schedule</b> {{$schedules->created_at->toformattedDateString()}}</p>
                    <hr>
                    <p></p>
                    @foreach($schedules->scheduleDetails as $schedule)
                    <h5>Name:{{$schedule->food->name}}</h5>
                    <h5>Food price:{{$schedule->food->price}}</h5>
                    <h5>Food Description:{{$schedule->description}}</h5>
                    <p></p>
                    <hr style="border: 10px solid lightblue; border-radius: 3px;">
                    @endforeach
                     @else
                     <h3>No Schedule detail found</h3>
@endif
                </div>
            </div>
        </div>
    </div>

@endsection