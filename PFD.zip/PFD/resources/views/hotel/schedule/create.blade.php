@extends('layouts.admin-template')
@section('title','Add Schedule')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Add Schedule
                    <a href="{{ route('schedule.index') }}" class="btn btn-md btn-default" style="float: right;">
                        View All
                    </a>
                </div>
                <div class="panel-body">
                    {{ Form::open(['action' => 'HotelScheduleController@store']) }}
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">Day</label>
                                <small> *</small>
                                <input type="text" name="day" class="form-control" placeholder="Day Name" required>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-md btn-primary">Add Day</button>
                            </div>
                        </div>
                    </div>
                    {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>

@endsection