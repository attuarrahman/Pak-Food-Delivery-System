@extends('layouts.admin-template')
@section('title','All Schedules')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All Schedules
                    <a href="{{ route('schedule.create') }}" class="btn btn-md btn-default" style="float: right;">
                        Add Schedule
                    </a>
                </div>
<br>

    @forelse($schedules as $schedule)

        <div class="row">
            <div class="col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        {{ $schedule->day }}
                    </div>
                    <div class="panel-body">
                        
                        <a href="{{ route('schedule.edit',$schedule->id) }}" class="btn btn-md btn-primary">
                            Add Food
                        </a>
                        <a href="{{ route('schedule.show',$schedule->id) }}" class="btn btn-md btn-primary">View
                            Details</a>
                    </div>
                </div>
            </div>
        </div> 

    @empty

        <p>No schedule found.</p>

    @endforelse
            </div>
        </div>
    </div>
@endsection