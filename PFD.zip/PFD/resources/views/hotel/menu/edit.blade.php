@extends('layouts.admin-template')
@section('title','')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    All
                    <a href="" class="btn btn-md btn-primary" style="float: right;">

                    </a>
                </div>
                <div class="card-body">

                </div>
            </div>
        </div>
    </div>

@endsection