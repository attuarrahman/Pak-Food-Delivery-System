@extends('layouts.admin-template')
@section('title','')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Our hotel menu
                    <a href="{{ route('user-menu.create') }}" class="btn btn-md btn-default" style="float: right;">
                    Add Menu
                    </a>
                </div>
                <div class="panel-body"> 
                 <?php $i =1; ?>
                                     
                                    @foreach($userMenu->userMenuDetails as $detail)
                                        <p>({{ $i++ }}) {{ $detail->food->name }} | Price: {{ $detail->price }}</p>
                                        <hr>
                            {{Form::open(['method'=>'Delete', 'action'=>['HotelMenuController@destroy',$detail->id],'role'=>'form', 'files'=>'true'])}}

                               <button type="submit" class="btn btn-warning" style="float: right;">Delete</button>


                               {{Form::close()}}

                                    @endforeach


                </div>
            </div>
        </div>
    </div>

@endsection