@extends('layouts.admin-template')
@section('title','Add Menu')
@section('body_content')

    @if(session('info'))
        <p class="alert alert-success">{{ session('info') }}</p>
    @endif
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Add Menu
                    <a href="{{route('user-menu.index')}}" class="btn btn-md btn-primary" style="float: right;"> Views all</a>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-8">
                            {{ Form::open(['action' => 'HotelMenuController@store']) }}
                            <input type="hidden" name="user_menu_id" value="{{ $userMenu->id }}">
                            <div class="form-group">
                                <label for="">Select Food</label>
                                <select name="food_id" class="form-control" required>
                                    <option value="">Select Food</option>
                                    @foreach($foods as $food)
                                        <option value="{{ $food->id }}">{{ $food->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Price</label>
                                <input type="text" name="price" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-md btn-primary">Add</button>
                            </div>
                            {{ Form::close() }}
                        </div>
                        <div class="col-md-4">
                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <h3>Already Added Menu</h3>
                                    <hr>
                                    <?php $i =1; ?>
                                    @foreach($userMenu->userMenuDetails as $detail)
                                        <p>({{ $i++ }}) {{ $detail->food->name }} | Price: {{ $detail->price }}</p>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection