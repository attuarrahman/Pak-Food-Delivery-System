@extends('layouts.admin-template')
@section('title','')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    All
                    <a href="" class="btn btn-md btn-primary" style="float: right;">

                    </a>
                </div>
                <div class="card-body">
                    <hr>
                  <div class="panel-group">
                  
                    <div class="panel panel-primary">
                    <div class="panel-body">
                       <table class="table">
                        <tr>
                            <td>
                                Image
                       
                            </td>
                            <td>Category </td>
                            <td>Food_name </td>
                            <td>price </td>
                            <td>Delete</td>

                        </tr>
                        <tr>
                            <td>
                             <img src="{{asset('uploads/food/'.$food->image)}}" height="100" width="100" class="img-circle" ></td>
                            <td>{{$food->category->name}}</td>
                            <td>{{$food->name}}</td>
                            <td>{{$food->price}}</td>
                            <td>
                                {{Form::open(['method'=>'Delete', 'action'=>['HotelFoodController@destroy',$food->id],'role'=>'form', 'files'=>'true'])}}

                                <button type="submit" class="btn btn-danger">Delete</button>
                                {{Form::close()}}
                            </td>


                        </tr>
                       
                       </table>
                       
                        
                    </div>
                    </div>
                   
                    
                    </div>


                </div>
            </div>
        </div>
    </div>

@endsection