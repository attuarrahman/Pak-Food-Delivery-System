@extends('layouts.admin-template')
@section('title','Add Food')
@section('body_content')

    @if(session('info'))
        <p class="alert alert-success">{{ session('info') }}</p>
        @endif
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Add Food
                    <a href="{{ route('food.index') }}" class="btn btn-md btn-primary" style="float: right;">
                        View All
                    </a>
                </div>
                <div class="panel-body">
                    {{ Form::open(['action' => 'HotelFoodController@store','files' => true]) }}
                    <div class="row">
                        <div class="col-md-4">
                            <label for="">Select Category</label>
                            <small> *</small>
                            <select name="category_id" class="form-control" required>
                                <option value="">Select Category</option>
                                @foreach($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="">Food</label>
                            <small> *</small>
                            <input type="text" name="name" class="form-control" placeholder="Food Name" required>
                        </div>
                        <div class="col-md-4">
                            <label for="">Price</label>
                            <small> *</small>
                            <input type="text" name="price" class="form-control" placeholder="Food Price" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <label for="">Select Image</label>
                            <small> *</small>
                            <input type="file" name="image" class="form-control" required>
                        </div>
                        <div class="col-md-8">
                            <label for="">Description</label>
                            <small> *</small>
                            <textarea name="description" class="form-control" rows="4" placeholder="Description..." required></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-md btn-primary">Add Food</button>
                            </div>
                        </div>
                    </div>
                    {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>

@endsection