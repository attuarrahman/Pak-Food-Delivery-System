@extends('layouts.admin-template')
@section('title','All Foods')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All Foods
                    <a href="{{ route('food.create') }}" class="btn btn-md btn-default" style="float: right;">
                        Add Food
                    </a>
              
   </div>
   

    <div class="row">
        @forelse($foods as $food)

            <div class="col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        {{ $food->name }}
                    </div>
                    <div class="panel-body">
                        <img src="{{ asset('uploads/food/'.$food->image) }}" class="img-responsive">
                        <hr>
                        Category: {{ $food->category->name }} <br>
                        Price: {{ $food->price }} <br>
                        <a href="{{ route('food.show',$food->id) }}" class="btn btn-block btn-md btn-primary">View
                            Details</a>
                    </div>
                </div>
            </div>

        @empty

            <p style="text-align: center">No food found. please add some food.</p>

        @endforelse
    </div>
     </div>
          </div>
            </div>
            

@endsection