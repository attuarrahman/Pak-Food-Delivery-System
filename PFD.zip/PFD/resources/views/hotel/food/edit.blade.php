@extends('layouts.admin-template')
@section('title','')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="penal-heading">
                    All
                    <a href="" class="btn btn-md btn-default" style="float: right;">

                    </a>
                </div>
                <div class="card-body">

                </div>
            </div>
        </div>
    </div>

@endsection