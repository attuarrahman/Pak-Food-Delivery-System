@extends('layouts.admin-template')
@section('title','Add Employee')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            @if(session('info'))
        <p class="alert alert-success">{{ session('info') }}</p>
        @endif
            <div class="panel panel-primary">

                <div class="panel-heading">
                    All
                    <a href="{{ route('expenses.index') }}" class="btn btn-md btn-default" style="float: right;">
                        View All
                    </a>
                </div>
                <div class="panel-body">
                    {{ Form::open(['action' => 'ExpensesController@store']) }}
                    <div class="row">
                        <div class="col-md-12">
                             <input type="hidden" name="user_id" value="{{Auth::id()}}">
                         <div class="form-group">
                           
                                <lable>Amount</lable>
             <input type="text" name="amount" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <lable>Description</lable>
                                <textarea name="description" class="form-control"></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary" style="float: right; margin-right: 20px">ADD</button>
                    </div>
                    {{ Form::close() }}

                </div>
            </div>
        </div>
    </div>

@endsection