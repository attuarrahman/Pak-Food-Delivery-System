@extends('layouts.admin-template')
@section('title','')
@section('body_content')

     <div class="row">
        <div class="col-md-12">
          @if(session('info'))
        <p class="alert alert-success">{{ session('info') }}</p>
        @endif
         @if(session('warning'))
        <p class="alert alert-warning">{{ session('warning') }}</p>
        @endif
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All Expenses
                    <a href="{{ route('expenses.create') }}" class="btn btn-md btn-default" style="float: right;">
                        Add Expenses
                    </a>
                </div>
                <div class="panel-body">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>S.No</th>
                          <th>Amount</th>
                          <th>Date</th>
                          <th>Details</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $i = 1; ?>
                    @foreach(Auth::user()->expenses as $expenses)
                        <tr>
                          <td>{{ $i++ }}</td>                          
                          <td>{{ $expenses->amount }}</td>                          
                          <td>{{ $expenses->created_at->toFormattedDateString() }}</td>                          
                          <td>
                            <a href="{{route('expenses.show',$expenses->id)}}" class="btn btn-sm btn-primary">View</a>
                          </td>                          
                        </tr>
                     @endforeach
                      </tbody>
                    </table>
            </div>
        </div>
    </div>

@endsection