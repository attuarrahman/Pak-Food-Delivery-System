@extends('layouts.admin-template')
@section('title','')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Expense Details
                    <a href="{{ route('expenses.index') }}" class="btn btn-md btn-default" style="float: right;">
                        View All
                    </a>                </div>
                <div class="panel-body">
                    <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Amount</th>
      <th scope="col">Description</th>
      <th scope="col">Update</th>
      <th scope="col">Delete</th>

     
    </tr>
  </thead>
  <tbody>

    <tr>
      <th scope="row">1</th>
      <td>{{$expenses->amount}}</td>
      <td>{{$expenses->description}}</td>
      <td>
          {{Form::open(['method' => 'GET', 'action'=>['ExpensesController@edit',$expenses->id], 'role'=>'form', 'files'=>'true'])}}
            <button type="submit" class="btn btn-primary">Update</button>
              
        {{Form::close()}}
      </td>
      <td>
          {{Form::open(['method' => 'DELETE', 'action'=>['ExpensesController@destroy',$expenses->id], 'role'=>'form', 'files'=>'true'])}}
            <button type="submit" class="btn btn-danger">Delete</button>
              
        {{Form::close()}}
      </td>

     
    </tr>
  </tbody>
</table>

                </div>
            </div>
          
        </div>
    </div>

@endsection