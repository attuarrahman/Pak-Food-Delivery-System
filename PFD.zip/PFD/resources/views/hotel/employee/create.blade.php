@extends('layouts.admin-template')
@section('title','Add Employee')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All
                    <a href="{{ route('employee.index') }}" class="btn btn-md btn-default" style="float: right;">
                        View All
                    </a>
                </div>
                <div class="panel-body">
                    {{ Form::open(['action' => 'HotelEmployeeController@store']) }}
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <lable>Select Type</lable>
                                <select name="employee_type_id" class="form-control" required>
                                    <option value="">Select Type</option>
                                    @foreach($types as $type)
                                        <option value="{{ $type->id }}">{{ $type->type_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <lable>Mobile</lable>
                                <input type="text" name="mobile" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <lable>Salary</lable>
                                <input type="text" name="salary" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-md btn-primary">Add Employee</button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <lable>Name</lable>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <lable>Address</lable>
                                <input type="text" name="address" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    {{ Form::close() }}

                </div>
            </div>
        </div>
    </div>

@endsection