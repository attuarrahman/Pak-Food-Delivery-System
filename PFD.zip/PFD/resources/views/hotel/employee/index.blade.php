@extends('layouts.admin-template')
@section('title','Employee Home')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All
                    <a href="{{ route('employee.create') }}" class="btn btn-md btn-default" style="float: right;">
                        Add Employee
                    </a>
                </div>
                <div class="panel-body">
                  @if($employees->count() > 0)
                    <table class="table">
                      <thead>
                        <tr>
                          <th>S.No</th>
                          <th>Name</th>
                          <th>Employee Type</th>
                          <th>Phone</th>
                          <th>Details</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $i = 1; ?>
                   @foreach($employees as $employee)
                        <tr>
                          <td>{{ $i++ }}</td>                          
                          <td>{{ $employee->name }}</td>                          
                          <td>{{ $employee->employeeType->type_name }}</td>
                          <td>{{ $employee->mobile }}</td>                        
                          <td>
                            <a href="{{route('employee.show',$employee->id)}}" class="btn btn-sm btn-primary">View</a>
                          </td>                          
                        </tr>
                     @endforeach
                      </tbody>
                    </table>
                    @else
                    <h4> Employee Record Not found</h4>
                    @endif
                </div>
            </div>
        </div>
    </div>

@endsection