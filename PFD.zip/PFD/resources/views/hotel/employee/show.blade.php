@extends('layouts.admin-template')
@section('title','Employee Details')
@section('body_content')

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Employee Details
                    <a href="{{ route('employee.index') }}" class="btn btn-md btn-default" style="float: right;">
                        View All
                    </a>

                </div>
                <div class="panel-body">
                    <div class="row">
                       
                        <div class="col-md-4">
                            <h3>Employee Type</h3>
                            <p>{{ $employee->employeeType->type_name }}</p>
                            <hr>
                            <h3>Address</h3>
                            <p>{{ $employee->address }}</p>
                            <hr>
                        </div>
                        <div class="col-md-4">
                            <h3>Name</h3>
                            <p>{{ $employee->name }}</p>
                            <hr>
                            <h3>Salary</h3>
                            <p>{{ $employee->salary }}</p>
                            <hr>
                        </div>
                        <div class="col-md-4">
                            <h3>Mobile</h3>
                            <p>{{ $employee->mobile }}</p>
                            <hr>
                            <h4>Delete</h4>
                            {{Form::open(['method' => 'DELETE', 'action'=>['HotelEmployeeController@destroy',$employee->id], 'role'=>'form', 'files'=>'true'])}}
                            <button class="btn btn-warning">Delete</button>
                            {{ Form::close()}}
                            <h4>Update</h4>
                             <a href="{{route('employee.edit',$employee->id)}}" class="btn btn-primary">Update</a>
                            <hr>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection