  <div class="shop_area shop_reverse">
        <div class="container">
            <!--shop tab product start-->
            <div class="tab-content">
                <div class="tab-pane grid_view fade show active" id="large" role="tabpanel">
	                    @foreach($food_category as $category)
                             <div class="row">
                             	@if($category->user->userMenu)
                            <div  class="col-lg-3 col-md-4">
                                        <div class="single_product">
                                            <div class="product_thumb">
                                                <a href=""><img src="{{ asset('uploads/food/'.$category->image) }}"
                                                                alt=""></a>
                                            </div>
                                            <div class="product_content">
                                           <h3>
                                                    <a href="{{ route('product.show',$category->id) }}">{{ $category->name }}</a>
                                                </h3>
                                                <span class="current_price">Rs.{{ $category->price }}/-</span><br>
                                                {{ Form::open(['action' => 'HomeCartController@store']) }}
                                                <input type="hidden" name="price" value="{{ $category->price }}">
                                                <input type="hidden" name="quantity" value="1">
                                                <input type="hidden" name="food_id" value="{{ $category->id }}">
                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-md btn-success">Add to Cart
                                                    </button>
                                                </div>
                                                {{ Form::close() }}
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                            </div> 
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
