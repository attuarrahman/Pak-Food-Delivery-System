<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\User::create([
            'name' => 'Atta Ur Rahman',
            'email' => 'attaurrahman@gmail.com',
            'password' => bcrypt('rahmanrahman'),
            'password_hint' => 'rahmanrahman',
            'status' => 1
        ]);
    }
}
