<?php

use Illuminate\Database\Seeder;

class EmployeeTypesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\EmployeeType::create([
            'type_name' => 'Manager'
        ]);

        \App\EmployeeType::create([
            'type_name' => 'Cooker'
        ]);

        \App\EmployeeType::create([
            'type_name' => 'Waiter'
        ]);

        \App\EmployeeType::create([
            'type_name' => 'Washer'
        ]);

        \App\EmployeeType::create([
            'type_name' => 'Cleaner'
        ]);
    }
}
