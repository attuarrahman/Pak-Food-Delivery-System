<?php

use Illuminate\Database\Seeder;

class CategoriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Category::create([
            'name' => 'Vegetables'
        ]);

        \App\Category::create([
            'name' => 'Beans'
        ]);

        \App\Category::create([
            'name' => 'Breads'
        ]);

        \App\Category::create([
            'name' => 'Cereals'
        ]);

        \App\Category::create([
            'name' => 'Rice'
        ]);

        \App\Category::create([
            'name' => 'Fruit'
        ]);

        \App\Category::create([
            'name' => 'Salad'
        ]);

        \App\Category::create([
            'name' => 'Meat'
        ]);
    }
}
