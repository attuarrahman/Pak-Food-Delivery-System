<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('country_id')->nullable();
            $table->integer('province_id')->nullable();
            $table->integer('city_id')->nullable();
            $table->string('name');
            $table->string('email')->email_verified_at();
            $table->string('password');
            $table->string('password_hint');
            $table->string('phone')->nullable();
            $table->string('location')->nullable();
            $table->string('service')->nullable();
            $table->string('opening_days')->nullable();
            $table->string('opening_timing')->nullable();
            $table->string('closing_timing')->nullable();
            $table->text('description')->nullable();
            $table->string('logo')->nullable();
            $table->string('banner')->nullable();
            $table->integer('status')->default(0);
            $table->text('token')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /** 
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
