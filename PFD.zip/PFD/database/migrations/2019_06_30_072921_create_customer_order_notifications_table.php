<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCustomerOrderNotificationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customer_order_notifications', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('order_history_id');
            $table->integer('customer_id');
            $table->integer('sound_status')->default(0);
            $table->integer('seen_status')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customer_order_notifications');
    }
}
