<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    protected $fillable = [
        'chat_id',
        'customer_id',
        'user_id',
        'message',
        'seen_status',
        'sound_status'
    ];

    public function chat()
    {
        return $this->belongsTo(Chat::class);
    }


    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
