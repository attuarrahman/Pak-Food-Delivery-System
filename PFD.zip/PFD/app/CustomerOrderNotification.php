<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerOrderNotification extends Model
{
    protected $fillable = [
        'order_history_id',
        'customer_id',
        'sound_status',
        'seen_status'
    ];

    public function orderHistory()
    {
        return $this->belongsTo(OrderHistory::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }
}
