<?php

namespace App\Http\Controllers;

use App\Category;
use App\Food;
use App\ScheduleDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class HotelFoodController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $foods = Food::where('user_id', Auth::id())->paginate(30);
        return view('hotel.food.index', compact('foods'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::orderBy('name', 'asc')->get();
        return view('hotel.food.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // validation


        // image uplaoding
        $file = $request->image;
        $name = time() . $file->getClientOriginalName();
        $file->move('public/uploads/food/', $name);

        // creation
        Food::create([
            'category_id' => $request->category_id,
            'user_id' => Auth::id(),
            'name' => $request->name,
            'price' => $request->price,
            'image' => $name,
            'description' => $request->description
        ]);

        Session::flash('info', 'Food added');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

         $food = Food::find($id);
        return view('hotel.food.show', compact('food'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       $find = Food::find($id);
      $find->delete();

         
      return redirect()->route('food.index');
 
    }
}
