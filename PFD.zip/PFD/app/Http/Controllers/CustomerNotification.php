<?php

namespace App\Http\Controllers;

use App\CustomerOrderNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class CustomerNotification extends Controller
{
    public function getNotification(Request $request)
    {
        $notifications = CustomerOrderNotification::where('customer_id',$request->customer_id)->orderBy('created_at', 'desc')->where('seen_status', 0)->get();
        $count = $notifications->count();
        if (session('order_limit') < $count) {
            $new_notification = $count - session('order_limit');
            $notifications = CustomerOrderNotification::where('customer_id',$request->customer_id)->orderBy('created_at', 'desc')->where('seen_status', 0)->limit($new_notification)->get();
            Session::put('order_limit', $count);
            return view('ajax-views.customer-notification', compact('notifications'));
        } else {
            Session::put('order_limit', $count);
            return 1;
        }
    }
}
