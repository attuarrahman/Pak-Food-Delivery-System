<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

class AdminHotelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $hotels = User::where('status',1)->paginate(20);
        return view('admin.hotel.index',compact('hotels'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $hotel = User::find($id);
        return view('admin.hotel.show',compact('hotel',$hotel));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $find = User::find($id);
        
        if ($request->Block) {
            $find->update([
              'status' => 2,

            ]);
            return redirect()->back();
            
         }
        elseif ($request->UnBlock) {
          $find->update([
              'status' => 0,

            ]);
            return redirect()->back();
        }
        elseif ($request->Improve) {
            $find->update([
              'status' => 0,

            ]);
            return redirect()->back();
        }

      
       
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $find =  User::find($id);
        $find->delete();
        return redirect()->route('hotel.index');

    }
}
