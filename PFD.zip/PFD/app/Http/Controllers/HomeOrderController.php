<?php

namespace App\Http\Controllers;

use App\Customer;
use App\HotelOrderNotification;
use App\Order;
use App\OrderDetail;
use App\OrderHistory;
use App\SpecialOrder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class HomeOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $customer = Customer::find($request->customer_id);

        // order create
        $order = Order::create([
            'user_id' => $request->user_id,
            'customer_id' => $request->customer_id,
            'order_location' => $request->order_location,
            'description' => $request->description
        ]);

        // order details create
        foreach ($customer->carts as $item) {
            OrderDetail::create([
                'order_id' => $order->id,
                'food_id' => $item->food_id,
                'quantity' => $item->quantity,
                'price' => $item->price
            ]);

            // delete current item
            $item->delete();
        }

        // notification
        HotelOrderNotification::create([
            'order_id' => $order->id,
            'user_id' => $order->user_id
        ]);


        // session flash & return
        Session::flash('info', 'Your order has been sent successfully.');
        return redirect('/customer/my-accounts');
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $order = SpecialOrder::find($id);
        return view('links.order.show', compact('order'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $order = OrderHistory::find($id);
       $incomplete_normal_order=Order::find($id);
        return view('links.order.edit', compact('order','incomplete_normal_order'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
