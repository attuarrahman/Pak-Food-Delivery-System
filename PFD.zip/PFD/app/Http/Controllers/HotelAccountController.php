<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Auth;

class HotelAccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::find($id);
        return view('hotel.my-account.show',compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return view('hotel.my-account.edit');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       $user = User::find($id);
       $file = $request->logo;
        $logo = time() . $file->getClientOriginalName();
        $file->move('public/uploads/food/', $logo);
        $file = $request->banner;
        $banner = time() . $file->getClientOriginalName();
        $file->move('public/uploads/food/', $banner);

       $user->update([
        'country_id' => $request->country_id,
        'province_id' => $request->province_id,
        'city_id' => $request->city_id,
        'name' => $request->name,
        'email' => $request->email,
        'password' => Hash::make($request['password']),
        'password_hint' => $request->password_confirmation,
        'phone' => $request->phone,
        'location ' => $request->location,
        'service' => $request->service,
        'opening_days' => $request->opening_days,
        'opening_timing' => $request->opening_timing,
        'closing_timing' => $request->closing_timing,
        'description'=> $request->description,
        'logo' =>$logo,
        'banner'=> $banner
        

       ]);
       return redirect()->route('my-account.show',Auth::id());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
