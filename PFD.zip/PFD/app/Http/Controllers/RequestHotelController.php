<?php

namespace App\Http\Controllers;

use App\RequestHotel;
use App\User;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;

class RequestHotelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       return view('admin.request_hotel.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\RequestHotel  $requestHotel
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $hotel = User::find($id);
        return view('admin.Request_hotel.show',compact('hotel',$hotel));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\RequestHotel  $requestHotel
     * @return \Illuminate\Http\Response
     */
    public function edit(RequestHotel $requestHotel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\RequestHotel  $requestHotel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $find = User::find($id);
        $find->update([
        'status' =>2,
        ]);
        Session::flash('success','HI Restaurant is Successfully approved');
        return redirect()->route('request_hotel.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\RequestHotel  $requestHotel
     * @return \Illuminate\Http\Response
     */
    public function destroy(RequestHotel $requestHotel)
    {
        //
    }
}
