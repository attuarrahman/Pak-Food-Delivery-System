<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    public function index()
    {
        $hotels = User::where('status', 2)->get();
        return view('index', compact('hotels'));

    }
} 
