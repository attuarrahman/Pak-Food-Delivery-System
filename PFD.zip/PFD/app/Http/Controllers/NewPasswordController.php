<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class NewPasswordController extends Controller
{
    public function verificationCode()
    {
        return view('auth.new-password.verification-code');
    }

    public function verifyCode(Request $request)
    {
        $user = User::where('token', $request->token)->first();
        if ($user) {
            return view('auth.new-password.new-password', compact('user'));
        } else {

            return redirect()->back()->with('warning', 'Check verification code!');
        }
    }

    public function newPassword(Request $request)
    {
        $user = User::find($request->user_id);
        $user->update([
            'password' => bcrypt($request->password),
            'token' => ''
        ]);

        return redirect('/login')->with('success','Your password has been reset successfuly');
    }
}
