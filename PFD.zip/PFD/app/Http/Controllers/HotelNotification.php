<?php

namespace App\Http\Controllers;

use App\HotelOrderNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class HotelNotification extends Controller
{
    // get notification for normal orders
    public function orderNotification(Request $request)
    {
        $notifications = HotelOrderNotification::where('user_id', $request->user_id)->orderBy('created_at', 'desc')->where('seen_status', 0)->get();
        $count = $notifications->count();
        if (session('order_limit') < $count) {
            $new_notification = $count - session('order_limit');
            $notifications = HotelOrderNotification::where('user_id', $request->user_id)->orderBy('created_at', 'desc')->where('seen_status', 0)->limit($new_notification)->get();
            Session::put('order_limit', $count);
            return view('ajax-views.hotel-order-notification', compact('notifications'));
        } else {
            Session::put('order_limit', $count);
            return 1;
        }
    }
}
