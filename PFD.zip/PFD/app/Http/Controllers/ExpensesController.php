<?php

namespace App\Http\Controllers;

use App\Expenses;
use Illuminate\Http\Request;
use Session;

class ExpensesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('hotel.expenses.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       return view('hotel.expenses.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Expenses::create([
         'user_id' => $request->user_id,
         'amount' => $request->amount,
         'description'=>$request->description
        ]);
        session::flash('info','Expenses add');
        return redirect()->route('expenses.index');
    
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Expenses  $expenses
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $expenses = Expenses::find($id);
        return view('hotel.expenses.show',compact('expenses',$expenses));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Expenses  $expenses
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       $expenses = Expenses::find($id);
       return view('hotel.expenses.edit',compact('expenses',$expenses));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Expenses  $expenses
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      
      $expenses = Expenses::find($id);
      $expenses->update([
       'user_id' => $request->user_id,
       'amount' => $request->amount,
       'description' => $request->description
 
      ]);
      Session::flash('info','update is succesfully');
      return redirect()->route('expenses.index');


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Expenses  $expenses
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $expenses = Expenses::find($id);
        $expenses->delete();
        Session::flash('warning','expenses is delete succesfully');
        return redirect()->route('expenses.index');
    }
}
