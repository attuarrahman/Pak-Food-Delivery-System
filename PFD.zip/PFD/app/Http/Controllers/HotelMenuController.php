<?php

namespace App\Http\Controllers;

use App\Food;
use App\UserMenu;
use App\UserMenuDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class HotelMenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $userMenu = UserMenu::where('user_id',Auth::id())->first();
        if($userMenu == null) {
            $userMenu = UserMenu::create([
                'user_id' => Auth::id()
            ]);
        }

        $foods = Food::where('user_id', Auth::id())->get();
        return view('hotel.menu.index',compact('userMenu'));
}
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $userMenu = UserMenu::where('user_id',Auth::id())->first();
        if($userMenu == null) {
            $userMenu = UserMenu::create([
                'user_id' => Auth::id()
            ]);
        }

        $foods = Food::where('user_id', Auth::id())->get();
        return view('hotel.menu.create', compact('foods','userMenu'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        UserMenuDetail::create([
            
            'user_menu_id' => $request->user_menu_id,
            'food_id' => $request->food_id,
            'price' => $request->price
        ]);

        Session::flash('info','Food added to menu list');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $menu = UserMenu::find($id);
        return view('hotel.menu.show', compact('menu'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         $find = UserMenuDetail::find($id);
         $find->delete();
         
         return redirect()->back();
    }
}
