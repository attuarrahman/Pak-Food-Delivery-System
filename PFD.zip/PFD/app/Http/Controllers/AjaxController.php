<?php

namespace App\Http\Controllers;

use App\City;
use App\Province;
use Illuminate\Http\Request;

class AjaxController extends Controller
{
    public function getProvince(Request $request)
    {
        $provinces = Province::where('country_id',$request->country_id)->orderBy('name','asc')->get();
        return view('ajax-views.get-provinces',compact('provinces'));
    }

    public function getCity(Request $request)
    {
        $cities = City::where('province_id',$request->province_id)->orderBy('city_name','asc')->get();
        return view('ajax-views.get-cities',compact('cities'));
    }
}
