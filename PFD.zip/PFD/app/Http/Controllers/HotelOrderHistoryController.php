<?php

namespace App\Http\Controllers;

use App\OrderHistory;
use App\OrderHistoryDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HotelOrderHistoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $orders = OrderHistory::where('user_id',Auth::id())->where('order_type',0)->paginate(50);
        $special= OrderHistory::where('user_id',Auth::id())->where('order_type',1)->paginate(50);
        return view('hotel.order-history.index',compact('orders','special'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $orders = OrderHistoryDetail::find($id);
        return view('hotel.order-history.show',compact('orders'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $order = OrderHistory::find($id);
        return view('hotel.order-history.edit',compact('order'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $find = OrderHistory::find($id);
        $find->delete();
        return redirect()->route('order-history.index');
    }
}
