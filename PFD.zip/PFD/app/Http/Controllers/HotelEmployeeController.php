<?php

namespace App\Http\Controllers;

use App\Employee;
use App\EmployeeType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;

class HotelEmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

      
         $employees = Employee::where('user_id', Auth::id())->paginate(30);
        return view('hotel.employee.index', compact('employees'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $types = EmployeeType::orderBy('type_name','asc')->get();
        return view('hotel.employee.create',compact('types'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $employee = Employee::create([
            'user_id' => Auth::id(),
            'employee_type_id' => $request->employee_type_id,
            'name' => $request->name,
            'mobile' => $request->mobile,
            'address' => $request->address,
            'salary' => $request->salary
        ]);

        Session::flash('info', 'Employee created successfully');
        return redirect('/hotel/employee/' . $employee->id);
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $employee = Employee::find($id);
        return view('hotel.employee.show', compact('employee'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $employee = Employee::find($id);
          $types = EmployeeType::orderBy('id','asc')->get();


        return view('hotel.employee.edit',compact('employee',$employee,'types',$types));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $employee = Employee::find($id);
        $employee->update([

         'employee_type_id' =>$request->employee_type_id,
         'user_id' => $request->user_id,
         'name' => $request->name,
         'mobile' => $request->mobile,
         'address' =>$request->address,
         'salary' => $request->salary,
        

        ]);
        Session::flash('info','successfully updated it now');
        return redirect()->route('employee.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $find = Employee::find($id);
        $find->delete();
        return redirect()->route('employee.index');
    }
}
