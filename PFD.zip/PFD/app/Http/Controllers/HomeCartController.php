<?php

namespace App\Http\Controllers;

use App\Cart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;

class HomeCartController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth:customer');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customer = Auth::guard('customer')->user();
        return view('links.cart.index', compact('customer'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (Auth::guard('customer')->user()) {
              $customer_id = Auth::guard('customer')->id();
        $check = Cart::where('customer_id', $customer_id)->where('food_id', $request->food_id)->first();
        if ($check) {
            Session::flash('warning', 'Product already added to cart!');
            return redirect()->back();
        } else {
            Cart::create([
                'customer_id' => $customer_id,
                'food_id' => $request->food_id,
                'price' => $request->price,
                'quantity' => $request->quantity
            ]);

            Session::flash('info', 'Product added to cart!');
            return redirect()->back();
        }
           
        }
        else
        {
            return redirect()->route('customer.login');
        }
      
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $cart = Cart::find($id);
        $cart->update([
            'quantity' => $request->quantity
        ]);

        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $cart = Cart::find($id);
        $cart->delete();
        return redirect()->back();
    }
}
