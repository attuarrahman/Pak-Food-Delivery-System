<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Money;

class MoneyController extends Controller
{
    public function store(Request $request)
{
	Money::create([
   'money'=>$request->money

	]);

 return redirect()->back();
}
 

}
