<?php

namespace App\Http\Controllers;

use App\Mail\PasswordReset;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class CheckAccountController extends Controller
{

    public function checkAccount(Request $request)
    {
        $user = User::where('email',$request->data)->orWhere('phone',$request->data)->first();
        $token = str_random(6);
        $user->update([
            'token' => $token
        ]);

        if ($user != null) {
            return view('auth.passwords.send-email', compact('user'));
        } else {
            return 0;
        }
    }

    public function sendEmail(Request $request)
    {
        $user = User::find($request->user_id);
        Mail::send(new PasswordReset());

        return redirect('/verification-code')->with('success', 'Verification code has been sent to your email.');
    }
}
