<?php

namespace App\Http\Controllers\Auth;

use App\Customer;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;

class CustomerRegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest:customer');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255', 'regex:/^[A-Z a-z]*$/'],
            'email' => ['required', 'email', 'max:255','unique:customers'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
            'country_id' => 'required',
            'province_id' => 'required',
            'city_id' => 'required',
            'phone' => ['required', 'regex:/^[0-9]*$/'],
            'address' => 'required',
            'dob' => 'required',
            'cnic' => 'required',
            'gender' => 'required'
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array $data
     * @return \App\User
     */
    protected function create(array $data)
    {
       
            $file= $data['profile'];
             $name=time().$file->getClientOriginalName();
             $file->move('public/upload/customerImg/',$name);
             $customer = Customer::create([
            'country_id' => $data['country_id'],
            'province_id' => $data['province_id'],
            'city_id' => $data['city_id'],
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'password_hint' => $data['password'],
            'mobile' => $data['phone'],
            'cnic' => $data['cnic'],
            'profile'=>$name,
            'dob' => $data['dob'],
            'gender' => $data['gender'],
            'address' => $data['address']
        ]);

        Auth::guard('customer')->login($customer);
        return $customer;
    }
}
