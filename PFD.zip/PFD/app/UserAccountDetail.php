<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserAccountDetail extends Model
{
    protected $fillable = [
        'user_account_id',
        'amount',
        'description'
    ];

    public function userAccount()
    {
        return $this->belongsTo(UserAccount::class);
    }
}
