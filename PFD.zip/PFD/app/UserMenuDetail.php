<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserMenuDetail extends Model
{
    protected $fillable = [
        'user_menu_id',
        'food_id',
        'price'
    ];

    public function userMenu()
    {
        return $this->belongsTo(UserMenu::class);
    }

    public function food()
    {
        return $this->belongsTo(Food::class);
    }
}
