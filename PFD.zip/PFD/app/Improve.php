<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Improve extends Model
{
    //
}
