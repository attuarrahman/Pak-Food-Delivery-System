<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Chat extends Model
{
    protected $fillable = [
        'creator_id',
        'follower_id',
        'chat_key',
        'notification_status'
    ];

    public function messages()
    {
        return $this->hasMany(Message::class);
    }
}
