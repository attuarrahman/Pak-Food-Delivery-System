<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderHistoryDetail extends Model
{
    protected $fillable = [
        'order_history_id',
        'food_id',
        'quantity',
        'price'
    ];

    public function orderHistory()
    {
        return $this->belongsTo(OrderHistory::class);
    }

    public function food()
    {
        return $this->belongsTo(Food::class);
    }
}
