<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HotelSpecialOrderNotification extends Model
{
    protected $fillable = [
        'special_order_id',
        'user_id',
        'sound_status',
        'seen_status'
    ];

    public function specialOrder()
    {
        return $this->belongsTo(SpecialOrder::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
