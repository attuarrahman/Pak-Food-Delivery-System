<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SpecialOrderDetail extends Model
{
    protected $fillable = [
        'order_id',
        'food_id',
        'quantity',
        'price'
    ];

    public function order()
    {
        return $this->belongsTo(SpecialOrder::class,'order_id');
    }

    public function food()
    {
        return $this->belongsTo(Food::class);
    }
}
