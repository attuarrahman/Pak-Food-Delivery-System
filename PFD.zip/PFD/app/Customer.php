<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Customer extends Authenticatable
{
    protected $guard = 'customer';

    protected $fillable = [
        'country_id',
        'province_id',
        'city_id',
        'name',
        'email',
        'password',
        'password_hint',
        'mobile',
        'cnic',
        'dob',
        'gender',
        'status',
        'bio',
        'address',
        'facebook',
        'profile'
    ];

    public function country()
    {
        return $this->belongsTo(Country::class);
    }

    public function province()
    {
        return $this->belongsTo(Province::class);
    }

    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function messages()
    {
        return $this->hasMany(Message::class);
    }

    public function orderHistories()
    {
        return $this->hasMany(OrderHistory::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    public function specialOrders()
    {
        return $this->hasMany(SpecialOrder::class);
    }

    public function carts()
    {
        return $this->hasMany(Cart::class);
    }

    public function superCarts()
    {
        return $this->hasMany(SuperCart::class);
    }

    public function rating()
    {
        return $this->hasMany(Rating::class);
    }

    public function orderNotifications()
    {
        return $this->hasMany(CustomerOrderNotification::class);
    }
}
