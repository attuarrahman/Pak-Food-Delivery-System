<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SuperCart extends Model
{
    protected $fillable = [
        'customer_id',
        'food_id',
        'price',
        'quantity'
    ];


    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function food()
    {
        return $this->belongsTo(Food::class);
    }
}
