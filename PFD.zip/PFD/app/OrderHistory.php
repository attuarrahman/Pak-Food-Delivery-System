<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderHistory extends Model
{
    protected $fillable = [
        'user_id',
        'customer_id',
        'status',
        'order_type',
        'rupees'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function orderHistoryDetails()
    {
        return $this->hasMany(OrderHistoryDetail::class);
    }

}
