<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Food extends Model
{
    protected $fillable = [
        
        'category_id',
        'user_id',
        'name',
        'price',
        'image',
        'description'
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }


    public function scheduleDetails()
    {
        return $this->hasMany(ScheduleDetail::class);
    }

    public function userMenuDetail()
    {
        return $this->hasOne(UserMenuDetail::class);
    }
    public function schedules()
    {
        return $this->belongsTo(Schedule::class);
    }
}
