<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ScheduleDetail extends Model
{
    protected $fillable = [
        'schedule_id',
        'food_id',
        'description'
    ];

    public function schedule()
    {
        return $this->belongsTo(Schedule::class);
    }

    public function food()
    {
        return $this->belongsTo(Food::class);
    }
}
