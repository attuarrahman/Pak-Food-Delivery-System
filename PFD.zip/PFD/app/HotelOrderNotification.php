<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HotelOrderNotification extends Model
{
    protected $fillable = [
        'order_id',
        'user_id',
        'seen_status',
        'sound_status'
    ];

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
