<?php

namespace App;


use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'country_id',
        'province_id',
        'city_id',
        'name',
        'email',
        'password',
        'password_hint',
        'phone',
        'location',
        'service',
        'opening_days',
        'opening_timing',
        'closing_timing',
        'description',
        'logo',
        'banner',
        'status',
        'token'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function messages()
    {
        return $this->hasMany(Message::class);
    }

    public function orderHistories()
    {
        return $this->hasMany(OrderHistory::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    public function employees()
    {
        return $this->hasMany(Employee::class);
    }

    public function userAccount()
    {
        return $this->hasOne(UserAccount::class);
    }

    public function userMenu()
    {
        return $this->hasOne(UserMenu::class);
    }

    public function foods()
    {
        return $this->hasMany(Food::class);
    }

    public function country()
    {
        return $this->belongsTo(Country::class);
    }

    public function province()
    {
        return $this->belongsTo(Province::class);
    }

    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function rating()
    {
        return $this->hasMany(Rating::class);
    }

    public function orderNotifications()
    {
        return $this->hasMany(HotelOrderNotification::class);
    }

    public function specialOrderNotifications()
    {
        return $this->hasMany(HotelSpecialOrderNotification::class);
    }
    public function expenses()
    {
     return $this->hasMany(Expenses::class);   
    }
}
