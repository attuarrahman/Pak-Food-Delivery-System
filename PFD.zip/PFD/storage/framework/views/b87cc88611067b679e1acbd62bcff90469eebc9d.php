<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All
                    
                </div>
                <div class="panel-body">
                   <div class="panel">
                       <div class="panel-heading"></div>
                       <div class="panel-body">
                        <?php if($orders->count() > 0): ?>
                           <table class="table table-striped">
  <thead>
    <label style="margin-left: 400px; color: blue">Simple Order</label>
    <tr>
      <th scope="col">S_No</th>
      <th scope="col">Customer Name</th>

    </tr>
  </thead>
  <tbody>
   
    <tr>
        <?php $i = 1; ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <th scope="row"><?php echo e($i++); ?></th>
    
  
      <td><?php echo e($order->customer->name); ?></td>
      <td><a href="<?php echo e(route('order-history.show',$order->id)); ?>" class="btn btn-primary">Views </a></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
   
  </tbody>
  
</table>
<?php else: ?>
<h4 style="text-align: center">No Normal Orders History is Found!</h4>
<?php endif; ?>
<br>
<hr>
<br>
<?php if($special->count() > 0): ?>
<table class="table table-striped">
  <thead>
    <label style="margin-left: 400px; color: blue">Special Order</label>
    <tr>
      <th scope="col">S_NO</th>
      <th scope="col">Customer Name</th>
     
    </tr>
  </thead>
  <tbody>
    <tr>
        <?php $i = 1; ?>
        <?php $__currentLoopData = $special; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <th scope="row"><?php echo e($i++); ?></th>
      <td><?php echo e($details->customer->name); ?></td>
      
      
      <td><a href="<?php echo e(route('order-history.show',$details->id)); ?>" class="btn btn-primary">Views </a></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
   
  </tbody>
  
</table>
<?php else: ?>
<h4 style="text-align: center">No Speical Orders History is Found!</h4>
<?php endif; ?>


                       </div>
                   </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PFD\resources\views/hotel/order-history/index.blade.php ENDPATH**/ ?>