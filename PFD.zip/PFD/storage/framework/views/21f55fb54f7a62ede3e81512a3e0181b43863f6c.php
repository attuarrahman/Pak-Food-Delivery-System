<?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li>
        <a href="<?php echo e(route('order-request.show',$notification->order_id)); ?>"
           style="font-size: 20px; background-color: #e4b9b9; color: #000;">
            <?php echo e($notification->order->customer->name); ?>

            | <?php echo e($notification->order->order_location); ?>

            <br>
            <span>Date: <?php echo e($notification->created_at->toDateTimeString()); ?></span>
        </a>
    </li>
    <li class="divider"></li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\Xampp\htdocs\OFO\resources\views/ajax-views/hotel-order-notification.blade.php ENDPATH**/ ?>