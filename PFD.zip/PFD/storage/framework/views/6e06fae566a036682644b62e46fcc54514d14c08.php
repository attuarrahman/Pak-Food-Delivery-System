<?php $__env->startSection('title','Order Details'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Order Details
                    <a href="<?php echo e(route('order-request.index')); ?>" class="btn btn-md btn-primary" style="float: right;">
                        View All
                    </a>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h3>Customer Details</h3>
                            <hr>
                            <h4>Customer: <?php echo e($order->customer->name); ?></h4>
                            <h4>Mobile: <?php echo e($order->customer->mobile); ?></h4>
                            <h4>Address: <?php echo e($order->customer->address); ?></h4>
                        </div>
                        <div class="col-md-6">
                            <h3>Order Details</h3>
                            <hr>
                            <h4>Order Location: <?php echo e($order->order_location); ?></h4>
                            <h4>Order Description: <?php echo e($order->description); ?></h4>
                            <h4>Order Date: <?php echo e($order->created_at->toDateTimeString()); ?></h4>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Sub Total</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $sno = 1; $grand_total = 0; ?>
                                <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sno++); ?></td>
                                        <td><?php echo e($detail->food->name); ?></td>
                                        <td><?php echo e($detail->quantity); ?></td>
                                        <td><?php echo e($detail->price); ?></td>
                                        <td>
                                            <?php $total = $detail->price * $detail->quantity;?>
                                            PKR <?php echo e($total); ?>

                                        </td>
                                    </tr>
                                    <?php $grand_total = $grand_total + $total; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <hr>
                            <h4 style="float: right;">Total: PKR <?php echo e($grand_total); ?></h4>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo e(Form::open(['method' => 'put','action' => ['HotelOrderRequestController@update',$order->id]])); ?>

                            <button type="submit" class="btn btn-md btn-success">Complete Order</button>
                            <?php echo e(Form::close()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PFD\resources\views/hotel/order-request/show.blade.php ENDPATH**/ ?>