<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    All
                    <a href="" class="btn btn-md btn-primary" style="float: right;">

                    </a>
                </div>
                <div class="card-body">
                    <hr>
                  <div class="panel-group">
                  
                    <div class="panel panel-primary">
                    <div class="panel-body">
                       <table class="table">
                        <tr>
                            <td>
                                Image
                       
                            </td>
                            <td>Category </td>
                            <td>Food_name </td>
                            <td>price </td>
                            <td>Delete</td>

                        </tr>
                        <tr>
                            <td>
                             <img src="<?php echo e(asset('uploads/food/'.$food->image)); ?>" height="100" width="100" class="img-circle" ></td>
                            <td><?php echo e($food->category->name); ?></td>
                            <td><?php echo e($food->name); ?></td>
                            <td><?php echo e($food->price); ?></td>
                            <td>
                                <?php echo e(Form::open(['method'=>'Delete', 'action'=>['HotelFoodController@destroy',$food->id],'role'=>'form', 'files'=>'true'])); ?>


                                <button type="submit" class="btn btn-danger">Delete</button>
                                <?php echo e(Form::close()); ?>

                            </td>


                        </tr>
                       
                       </table>
                       
                        
                    </div>
                    </div>
                   
                    
                    </div>


                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\PFD\resources\views/hotel/food/show.blade.php ENDPATH**/ ?>