<?php $__env->startSection('title','Countries'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    All Countries
                    <a href="<?php echo e(route('country.create')); ?>" class="btn btn-md btn-primary" style="float: right;">Add
                        Country</a>
                </div>
                <div class="card-body">
                    <?php $i = 1; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <p>(<?php echo e($i++); ?>) <?php echo e($country->name); ?> | Code: <?php echo e($country->code); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No record found</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\OFO\resources\views/admin/country/index.blade.php ENDPATH**/ ?>