<?php $__empty_1 = true; $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div  style="margin-left: 50px" class="col-md-3">
        <div class="demo-item">
            <h4 class="title">
                <a href="<?php echo e(route('hotels.show',$hotel->id)); ?>"><?php echo e($hotel->name); ?> 
                    <img src="<?php echo e(asset('uploads/food/'.$hotel->logo)); ?>" class="img-responsive">
                </a>
            </h4>
                <b>Country Name:</b><?php echo e($hotel->country->name); ?><br>
                <b>Province:</b><?php echo e($hotel->province->name); ?><br>  
                <b>City:</b><?php echo e($hotel->city->city_name); ?><br>
                <b>Current Location:</b><?php echo e($hotel->location); ?>

                         
        </div>
    </div>   
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h4 style="text-align: center;color:red">Restaurant record not found.</h4>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\PFD\resources\views/searching.blade.php ENDPATH**/ ?>