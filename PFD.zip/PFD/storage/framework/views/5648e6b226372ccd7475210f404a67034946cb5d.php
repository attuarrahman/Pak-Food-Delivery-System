<?php $__env->startSection('title','All Schedules'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All Schedules
                    <a href="<?php echo e(route('schedule.create')); ?>" class="btn btn-md btn-default" style="float: right;">
                        Add Schedule
                    </a>
                </div>
<br>

    <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <?php echo e($schedule->day); ?>

                    </div>
                    <div class="panel-body">
                        
                        <a href="<?php echo e(route('schedule.edit',$schedule->id)); ?>" class="btn btn-md btn-primary">
                            Add Food
                        </a>
                        <a href="<?php echo e(route('schedule.show',$schedule->id)); ?>" class="btn btn-md btn-primary">View
                            Details</a>
                    </div>
                </div>
            </div>
        </div> 

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <p>No schedule found.</p>

    <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\OFO\resources\views/hotel/schedule/index.blade.php ENDPATH**/ ?>