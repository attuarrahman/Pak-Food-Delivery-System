<?php $__env->startSection('title','Register as Hotel'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="breadcrumbs_area other_bread" style="margin-bottom: 100px;">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="customer_login" style="margin-top: 50px;">
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div> 
               <div style="border:solid 5px #dfdfdf 
;border-radius: 20px;background-color:#dfdfdf ;color:black" class="col-md-6"><br>
                    <h3 style="text-align: center;color: black"><b>Restaurant Registration </b></h3>
                    <hr>
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name"><?php echo e(__('Hotel Name')); ?></label>
                                    <small style="color: red;"> *</small>
                                    <input id="name" type="text"
                                           class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="name" placeholder="Hotel Name" value="<?php echo e(old('name')); ?>"
                                           required autocomplete="name" autofocus>

                                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="password"><?php echo e(__('Password')); ?></label>
                                    <small style="color: red;"> *</small>
                                    <input id="password" type="password"
                                           class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="password"
                                           required autocomplete="new-password" placeholder="Password"
                                           aria-required="true">

                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Select Country</label>
                                    <small style="color: red;"> *</small>
                                    <select name="country_id" id="country_id" onblur="getProvince()" required
                                            class="form-control <?php if ($errors->has('country_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('country_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <option value="">Select Country</option>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Select City</label>
                                    <small style="color: red;"> *</small>
                                    <select name="city_id" id="city_id" required
                                            class="form-control <?php if ($errors->has('city_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <option value="">Select City</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Phone</label>
                                    <small style="color: red;"> *</small>
                                    <input type="text"
                                           class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> required is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="phone" placeholder="Phone">
                                </div>
                                <div class="form-group">
                                    <label for="">Service</label>
                                    <small style="color: red;"> * Service hotel will provide</small>
                                    <textarea type="text" required
                                              class="form-control <?php if ($errors->has('service')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('service'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                              name="service" placeholder="Service"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="">Opening Hours</label>
                                    <small style="color: red;"> * Opening hour of hotel.</small>
                                    <input type="text" required
                                           class="form-control <?php if ($errors->has('opening_timing')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('opening_timing'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="opening_timing" placeholder="Opening Hours">
                                </div>
                                <div class="form-group">
                                    <label for="">Description</label>
                                    <small style="color: red;"> * Full description of hotel.</small>
                                    <textarea type="text" required
                                              class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                              name="description" placeholder="Description"></textarea>
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Register Account')); ?>

                                    </button> | Already have account? <a href="<?php echo e(route('login')); ?>">Login</a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email"><?php echo e(__('E-Mail Address')); ?></label>
                                    <small style="color: red;"> *</small>
                                    <input id="email" type="email"
                                           class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="email" placeholder="Email address" value="<?php echo e(old('email')); ?>"
                                           required autocomplete="email">

                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="password-confirm"><?php echo e(__('Confirm Password')); ?></label>
                                    <small style="color: red;"> *</small>
                                    <input id="password-confirm" type="password" class="form-control"
                                           name="password_confirmation" placeholder="Confirm Password" required
                                           autocomplete="new-password">
                                </div>
                                <div class="form-group">
                                    <label for="">Select Province</label>
                                    <small style="color: red;"> *</small>
                                    <select name="province_id" required id="province_id" onblur="getCity()"
                                            class="form-control <?php if ($errors->has('province_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('province_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <option value="">Select Province</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Full Address</label>
                                    <small style="color: red;"> * Full address of hotel.</small>
                                    <textarea type="text" required
                                              class="form-control <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                              name="location" placeholder="Full Address"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="">Opening Days</label>
                                    <small style="color: red;"> * Total no of days hotel will be open.</small>
                                    <input type="text" required
                                           class="form-control <?php if ($errors->has('opening_days')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('opening_days'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="opening_days" placeholder="Opening Days">
                                </div>
                                <div class="form-group">
                                    <label for="">Closing Hours</label>
                                    <small style="color: red;"> * Closing hour of hotel.</small>
                                    <input type="text" required
                                           class="form-control <?php if ($errors->has('closing_timing')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('closing_timing'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="closing_timing" placeholder="Closing Hours">
                                </div>

                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-1"></div>
            </div>
            <br>
            <br>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.form-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PFD\resources\views/auth/register.blade.php ENDPATH**/ ?>