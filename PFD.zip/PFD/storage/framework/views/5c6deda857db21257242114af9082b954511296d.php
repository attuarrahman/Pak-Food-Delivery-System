<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title','Home'); ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="">
    <!-- All CSS Files -->
    <!-- Bootstrap css -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/bootstrap.min.css')); ?>">
    <!-- Icon Font -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <!-- Plugins css file -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/plugins.css')); ?>">
    <!-- Theme main style -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/style.css')); ?>">
    <!-- Modernizr JS -->
    <script src="<?php echo e(asset('dist/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>

</head>

<body>

<header class="header_area header_two">
    <div class="header_inner">

        <!--header middel css here-->
        <div class="header_middel middel_two">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-3">
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>"><img src="" alt="">Online Food Ordering</a>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-6">

                        <div class="header_search">

                            <form action="index-2.html#">
                                <div class="select_categorie">
                                    <span class="categorie_toggle">All Categories <i
                                                class="fa fa-caret-down"></i></span>
                                </div>
                                <input placeholder="Search product..." type="text">
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3">
                        <?php if(Auth::guard('customer')->user()): ?>
                            <div class="shipping_cart">
                                <a href="<?php echo e(route('my-cart.index')); ?>">
                                    <span>My Cart</span>
                                    <span class="cart_icon"><i class="fa fa-shopping-bag"></i></span>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!--header middel css end-->
    </div>

    <!--header bottom css here-->
    <div class="header_bottom bottom_two">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-9 col-md-12">
                    <div class="bottom_left">
                        <div class="home_icone">
                            <a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i></a>
                        </div>
                        <div class="menu_inner">
                            <div class="main_menu d-none d-lg-block">
                                <ul>
                                    <?php if(session('hotel')): ?>
                                        <li><a href="<?php echo e(route('hotels.show',session('hotel')->id)); ?>">Home</a></li>
                                        <li><a href="<?php echo e(route('hotel-rating.index')); ?>">Rating</a></li>
                                    <?php endif; ?>
                                    <?php if(Auth::guard('customer')->user()): ?>
                                        <li><a href="<?php echo e(route('my-cart.index')); ?>">My Cart</a></li>
                                        <li><a href="<?php echo e(route('my-accounts.index')); ?>">My Account</a></li>

                                        <!-- Notification -->
                                        <li><a href="">Notification <sup>(45)</sup></a>
                                            <ul class="sub_menu">
                                                <li id="new_notification"></li>
                                            </ul>
                                        </li>

                                        <li>
                                            <a href="<?php echo e(route('logout')); ?>"
                                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                                <?php echo e(__('Logout')); ?>

                                            </a>

                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                  style="display: none;">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e(route('customer.login')); ?>">Login</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--header bottom css here-->
</header>


<?php echo $__env->yieldContent('body_content'); ?>

<!-- Placed JS at the end of the document so the pages load faster -->
<!-- jQuery latest version -->
<script src="<?php echo e(asset('dist/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
<!-- Popper JS -->
<script src="<?php echo e(asset('dist/js/popper.min.js')); ?>"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('dist/js/bootstrap.min.js')); ?>"></script>
<!-- Plugins js -->
<script src="<?php echo e(asset('dist/js/plugins.js')); ?>"></script>
<!-- Main js -->
<script src="<?php echo e(asset('dist/js/main.js')); ?>"></script>
<?php echo $__env->yieldContent('script_content'); ?>

<script>

    <?php if(Auth::guard('customer')->user()): ?>

    $(document).ready(function () {
        getNewNotifications();
    });

    function getNewNotifications() {
        window.setInterval(getNotification, 5000);
    }

    function getNotification() {
        var data = "customer_id=" + <?php echo e(Auth::guard('customer')->id()); ?>;
        $.ajax({
            type: "GET",
            url: '<?php echo e(URL::to('/customer/get-customer-notification')); ?>',
            data: data,
            success: function (data) {
                if (data != 1) {
                    var audio = new Audio('<?php echo e(asset('assets/notification.wav')); ?>');
                    audio.play();
                    document.getElementById('new_notification').innerHTML += data;
                }
            }
        });
    }

    <?php endif; ?>

</script>

</body>

</html><?php /**PATH C:\xampp\htdocs\OFO\resources\views/layouts/master-layout.blade.php ENDPATH**/ ?>