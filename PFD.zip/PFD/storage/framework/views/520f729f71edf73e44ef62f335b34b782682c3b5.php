<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title','Home'); ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="">
    <!-- All CSS Files -->
    <!-- Bootstrap css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <!-- Icon Font -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/et-line.css')); ?>">
    <!-- Plugins css file -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.css')); ?>">
    <!-- Theme main style -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>">
    <!-- Responsive css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
    <!-- Modernizr JS -->
    <script src="<?php echo e(asset('assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>

    <style>

        .buy-btn.top-btn {
            background-color: #7ecc13;
            border-color: #7ecc13;
        }

        .buy-btn:hover {
            background-color: #7ecc13;
            border-color: #7ecc13;
        }

        .buy-btn:focus {
            color: #fff;
        }

        .demo-item .image::after {
            background-color: #7ecc13;
        }

        .demo-item .image i:hover {
            color: #7ecc13;
        }

        .stick .buy-btn.top-btn {
            border: 2px solid #7ecc13;
            color: #fff;
        }

        .stick .buy-btn {
            border: 2px solid #7ecc13;
            color: #7ecc13;
        }

        .single-feature .icon {
            color: #7ecc13;
        }

        .footer-section {
            background-color: #444;
        }

        .stick .buy-btn:hover {
            color: #fff;
        }

        .demo-item .title a:hover {
            color: #7ecc13;
        }

        .footer-section .buy-btn:hover {
            color: #7ecc13;
        }

        .footer-section .buy-btn.bottom-btn {
            color: #fff;
            background-color: #7ecc13;
            border: 2px solid #7ecc13;
        }

        .hero-content h1 strong {
            text-transform: capitalize;
        }

        .stick .non-sticky {
            display: none;
        }

        .demo-item {
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.15);
        }

        .demo-item .title {
            padding: 20px 0;
            margin: 0;
        }

        .section-title h1 {
            line-height: 30px;
            font-size: 30px;
            text-transform: uppercase;
        }

        .logo {
            margin: 5px 0;
        }

        .overlay::before {
            opacity: 0.5;
        }

        @media  only screen and (max-width: 767px) {
            .section-title.mb-70 {
                margin-bottom: 40px;
            }

            .section-title h1 {
                font-size: 25px;
                line-height: 25px;
            }

            .demo-item .title {
                font-size: 16px;
            }

            .demo-item .title a {
                line-height: 22px;
            }

            .stick .logo a .sticky-logo {
                max-width: 130px;
            }

            @media  only screen and (max-width: 450px) {
                .logo {
                    margin: 0;
                }
            }
        }

    </style>

</head>

<body>

<!-- Navbar -->
<div class="header-section section sticker stick">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                 <a href="<?php echo e(url('/')); ?>"><img style="width: 100px; height:100px" src="<?php echo e(asset('uploads\logo\logo.png')); ?>"></a>   
               </div>
                <div class="logo float-left">
            </div>
            <div class="col-md-7">
                <a class="btn btn-md btn-primary" href="<?php echo e(route('register')); ?>" style="float: right;">Restaurant</a>
                <a class="btn btn-md btn-default" href="<?php echo e(route('customer.register')); ?>" style="float: right;">Customer</a>
            </div>
        </div>
    </div>
</div>
<br>
<?php echo $__env->yieldContent('body_content'); ?>

<div class="footer-section section pt-65 pb-50">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h1>Make your website come to life quickly.</h1>
            </div>
        </div>
    </div>
</div>


<!-- Placed JS at the end of the document so the pages load faster -->
<!-- jQuery latest version -->
<script src="<?php echo e(asset('assets/js/vendor/jquery-3.1.1.min.js')); ?>"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<!-- Plugins js -->
<script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
<!-- Main js -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php echo $__env->yieldContent('script_content'); ?>
<script>

    function getProvince() {
        var country_id = document.getElementById('country_id').value;
        if (country_id == null) {
            document.getElementById('country_id').style.border = "1px solid red";
        } else {
            document.getElementById('country_id').style.border = "1px solid #ced4da";
            var data = "country_id=" + country_id;
            $.ajax({
                type: "GET",
                url: '<?php echo e(URL::to('/get-province-name')); ?>',
                data: data,
                success: function (data) {
                    document.getElementById('province_id').innerHTML = data;
                }
            });
        }
    }

    function getCity() {
        var province_id = document.getElementById('province_id').value;
        if (province_id == null) {
            document.getElementById('province_id').style.border = "1px solid red";
        } else {
            document.getElementById('province_id').style.border = "1px solid #ced4da";
            var data = "province_id=" + province_id;
            $.ajax({
                type: "GET",
                url: '<?php echo e(URL::to('/get-city-name')); ?>',
                data: data,
                success: function (data) {
                    document.getElementById('city_id').innerHTML = data;
                }
            });
        }
    }

</script>

</body>

</html><?php /**PATH C:\xampp\htdocs\PFD\resources\views/layouts/form-template.blade.php ENDPATH**/ ?>