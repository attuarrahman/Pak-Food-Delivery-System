<?php $__env->startSection('title','Employee Home'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All
                    <a href="<?php echo e(route('employee.create')); ?>" class="btn btn-md btn-default" style="float: right;">
                        Add Employee
                    </a>
                </div>
                <div class="panel-body">
                  <?php if($employees->count() > 0): ?>
                    <table class="table">
                      <thead>
                        <tr>
                          <th>S.No</th>
                          <th>Name</th>
                          <th>Employee Type</th>
                          <th>Phone</th>
                          <th>Details</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $i = 1; ?>
                   <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($i++); ?></td>                          
                          <td><?php echo e($employee->name); ?></td>                          
                          <td><?php echo e($employee->employeeType->type_name); ?></td>
                          <td><?php echo e($employee->mobile); ?></td>                        
                          <td>
                            <a href="<?php echo e(route('employee.show',$employee->id)); ?>" class="btn btn-sm btn-primary">View</a>
                          </td>                          
                        </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                    <?php else: ?>
                    <h4> Employee Record Not found</h4>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PFD\resources\views/hotel/employee/index.blade.php ENDPATH**/ ?>