<?php $__env->startSection('title','Add Schedule'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-heading">
                    Add Schedule
                    <a href="<?php echo e(route('schedule.index')); ?>" class="btn btn-md btn-primary" style="float: right;">
                        View All
                    </a>
                </div>
                <div class="panel-body">
                    <?php echo e(Form::open(['action' => 'HotelScheduleController@store'])); ?>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">Day</label>
                                <small> *</small>
                                <input type="text" name="day" class="form-control" placeholder="Day Name" required>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-md btn-primary">Add Day</button>
                            </div>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\OFO\resources\views/hotel/schedule/create.blade.php ENDPATH**/ ?>