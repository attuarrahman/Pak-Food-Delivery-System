<?php $__env->startSection('title','Order Details'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Order Details
                    <a href="<?php echo e(route('order-history.index')); ?>" class="btn btn-md btn-default"
                       style="float: right;">
                        View All
                    </a>
                </div>
                <div class="panel-body">
                <div class="card">
                    <div class="card-header"></div>
                    <div class="card-body">
                        
                      
                        <h4></h4>
                      
                        
                        <br>
                       
                        <table class="table">

                            <thead>

                                <th>Food Name</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                

                            </thead>
                            <tr>
                                   
                                <td><?php echo e($orders->food->name); ?></td>
                                <td><?php echo e($orders->quantity); ?></td>
                                <td><?php echo e($orders->price); ?></td>
                               <td> <?php echo e(Form::open(['method'=>'DELETE', 'action'=>['HotelOrderHistoryController@destroy',$orders->order_history_id],'role'=>'form','files'=>'true'])); ?>

                                <button type="submit" class="btn btn-danger">Delete</button>
                                <?php echo e(Form::close()); ?>

                                </td>
                               

                            </tr>
                        </table>




                        
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PFD\resources\views/hotel/order-history/show.blade.php ENDPATH**/ ?>