<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All
                    <a href="<?php echo e(route('user-menu.create')); ?>" class="btn btn-md btn-primary" style="float: right;">
           Add Menu
                    </a>
                </div>
                <div class="panel-body">
                     <div class="panel panel-default">
                                <div class="panel-body">
                                    <h3>Already Added Menu</h3>
                                    <hr>
                                    <?php $i =1; ?>
                                    <?php $__currentLoopData = $userMenu->userMenuDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($detail->food->name == "null"): ?>
                                         <p>food is not avalible </p>
                                        <?php else: ?>
                                         <p>(<?php echo e($i++); ?>) <?php echo e($detail->food->name); ?> | Price: <?php echo e($detail->price); ?></p>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\OFO\resources\views/hotel/menu/index.blade.php ENDPATH**/ ?>