<?php $__env->startSection('title','Special Order'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>Special Order</h1>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php if(session('info')): ?>
        <p class="alert alert-success"><?php echo e(session('info')); ?></p>
    <?php endif; ?>
    <?php if(session('warning')): ?>
        <p class="alert alert-warning"><?php echo e(session('warning')); ?></p>
    <?php endif; ?>
    <div class="customer_login" style="margin-top: 50px;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3>Create Your Order</h3>
                    <hr>
                    <?php echo e(Form::open(['action' => 'SuperCartController@store'])); ?>

                    <div class="form-group">
                        <label for="">Select From Hotel Menu</label>
                        <small> *</small>
                        <select name="food_id" class="form-control" required>
                            <option value="">Select Product</option>
                            <?php $__currentLoopData = session('hotel')->userMenu->userMenuDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($detail->food_id); ?>">
                                    <?php echo e($detail->food->name); ?> - (PKR : <?php echo e($detail->price); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Quantity</label>
                        <small> * Quantity is per parsal.</small>
                        <input type="text" name="quantity" class="form-control" required placeholder="Parsal">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-block btn-md btn-success">
                            Add to Cart
                        </button>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                    <div class="sidebar_widget widget_categories">
                        <h3 class="widget_title">Our Menu For the Day!</h3>
                        <ul>
                            <?php $__currentLoopData = session('hotel')->userMenu->userMenuDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('product.show',$detail->food_id)); ?>"><?php echo e($detail->food->name); ?></a>
                                    (PKR: <?php echo e($detail->price); ?>)
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div><br>
    <div class="shopping_cart_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3>Cart Details</h3>
                    <hr>
                    <div class="table_desc">
                        <div class="cart_page table-responsive">
                            <table>
                                <thead>
                                <tr>
                                    <th class="product_remove">Delete</th>
                                    <th class="product_thumb">Image</th>
                                    <th class="product_name">Product</th>
                                    <th class="product-price">Price</th>
                                    <th class="product_quantity">Parsal</th>
                                    <th class="product_total">Total</th>
                                </tr>
                                </thead>
                                <?php
                                $i = 1;
                                $grand_total = 0;
                                $customer = \Illuminate\Support\Facades\Auth::guard('customer')->user();
                                ?>
                                <tbody>
                                <?php $__currentLoopData = $customer->superCarts()->orderBy('created_at','asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="product_remove">
                                            <?php echo e(Form::open(['method' => 'delete','action' => ['SuperCartController@destroy',$item->id]])); ?>

                                            <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash-o"
                                                                                                   style="color: #fff;"></i>
                                            </button>
                                            <?php echo e(Form::close()); ?>

                                        </td>
                                        <td class="product_thumb">
                                            <img src="<?php echo e(asset('uploads/food/'.$item->food->image)); ?>" width="100px"
                                                 height="100px">
                                        </td>
                                        <td class="product_name">
                                            <?php echo e($item->food->name); ?>

                                        </td>
                                        <td class="product-price">
                                            PKR <?php echo e($item->price); ?>/-
                                        </td>
                                        <td class="product_quantity">
                                            <?php echo e(Form::open(['method' => 'put','action' => ['SuperCartController@update',$item->id]])); ?>

                                            <input name="quantity" min="1" max="12" value="<?php echo e($item->quantity); ?>"
                                                   type="number">
                                            <span>
                                                <button type="submit" class="btn btn-sm btn-primary">Update</button>
                                            </span>
                                            <?php echo e(Form::close()); ?>

                                        </td>
                                        <td class="product_total">
                                            <?php $total = $item->price * $item->quantity; ?>
                                            PKR <?php echo e($total); ?>/-
                                        </td>
                                    </tr>
                                    <?php $grand_total = $grand_total + $total; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <hr>
                            <h5>Total: PKR <?php echo e($grand_total); ?>/-</h5>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <?php if($customer->superCarts()->count() > 0): ?>
                <div class="coupon_area">
                    <div class="row">
                        <div class="col-lg-6 col-md-6"></div>
                        <div class="col-lg-6 col-md-6">
                            <div class="coupon_code right">
                                <h3>Cart Totals</h3>
                                <div class="coupon_inner">
                                    <div class="cart_subtotal">
                                        <p>Total</p>
                                        <p class="cart_amount">PKR <?php echo e($grand_total); ?></p>
                                    </div>
                                    <?php echo e(Form::open(['action' => 'HotelSuperCartController@store'])); ?>

                                    <input type="hidden" name="user_id" value="<?php echo e($item->food->user_id); ?>">
                                    <input type="hidden" value="<?php echo e($customer->id); ?>" name="customer_id">
                                    <div class="form-group">
                                        <label for="">Your Location</label>
                                        <small> *</small>
                                        <input type="text" name="order_location" class="form-control" required>
                                    </div>
                                    <div class="from-group">
                                        <label for="">Description</label>
                                        <small> *</small>
                                        <textarea name="description" required class="form-control"></textarea>
                                    </div>
                                    <br>
                                    <div class="checkout_btn">
                                        <button type="submit" class="btn btn-md btn-success">Proceed to Checkout
                                        </button>
                                    </div>
                                    <?php echo e(Form::close()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--coupon code area end-->
            <?php endif; ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\OFO\resources\views/links/super-cart/index.blade.php ENDPATH**/ ?>