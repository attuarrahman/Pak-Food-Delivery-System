<?php $__env->startSection('title','Add Province'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div style="color:white;background-color: steelblue" class="card-header">Add Province
                    <a href="<?php echo e(route('province.index')); ?>" class="btn btn-md btn-success" style="float: right;">View All</a>
                </div>
                <div class="card-body">
                    <?php echo e(Form::open(['action' => 'AdminProvinceController@store'])); ?>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <lable>Select Country</lable>
                                <select name="country_id" class="form-control" required>
                                    <option value="">Select Country</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-md btn-primary">Add</button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <lable>Province Name</lable>
                                <input type="text" name="name" placeholder="Province Name" class="form-control"
                                       required>
                            </div>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\PFD\resources\views/admin/province/create.blade.php ENDPATH**/ ?>