<?php $__env->startSection('Title','Dashboard'); ?>
<?php $__env->startSection('body_content'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\OFO\resources\views/hotel/dashboard.blade.php ENDPATH**/ ?>