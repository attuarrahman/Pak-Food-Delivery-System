<?php $__env->startSection('title','Add Food To Schedule'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Add Food To Schedule
                    <a href="<?php echo e(route('schedule.index')); ?>" class="btn btn-md btn-default" style="float: right;">Back

                    </a>
                </div>
                <div class="panel-body">
                    <?php echo e(Form::open(['method' => 'put','action' => ['HotelScheduleController@update',$schedule->id]])); ?>

                    <div class="row">
                        <div class="col-md-4">
                            <lable>Select Food</lable>
                            <select name="food_id" class="form-control" required>
                                <option value="">Select Food</option>
                                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($food->id); ?>"><?php echo e($food->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="form-group">
                                <button type="submit" class="btn btn-md btn-primary">Add</button>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <label for="">Decription</label>
                            <textarea name="description" rows="4" class="form-control" required></textarea>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PFD\resources\views/hotel/schedule/edit.blade.php ENDPATH**/ ?>