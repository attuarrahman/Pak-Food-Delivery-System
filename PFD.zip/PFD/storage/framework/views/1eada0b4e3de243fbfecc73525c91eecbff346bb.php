<?php $__env->startSection('title','Hotel Reviews'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>
                        Recent Reviews <br>
                    </h1>
                    <p>
                        <?php
                        $total_stars = 0;
                        foreach ($ratings as $item) {
                            $total_stars = $total_stars + $item->starts;
                        }
                        $rating = $total_stars / $ratings->count();
                        ?>
                        Rating (<?php echo e($rating); ?> <i class="fa fa-star"></i>)
                    </p>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="shop_area shop_reverse">
        <div class="container">

            <!--shop tab product start-->
            <div class="tab-content">
                <div class="tab-pane grid_view fade show active" id="large" role="tabpanel">
                    <div class="row">
                        <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <div class="sidebar_widget widget_categories">
                                    <h3 class="widget_title">
                                        <?php echo e($rating->customer->name); ?> <span style="float: right;"><?php for($i = 1;$i <= $rating->starts;$i++): ?><i class="fa fa-star"></i><?php endfor; ?></span>
                                    </h3>
                                    <ul>
                                        <li>
                                            <?php echo e($rating->review); ?>

                                        </li>
                                    </ul>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\OFO\resources\views/links/rating/index.blade.php ENDPATH**/ ?>