<?php $__env->startSection('title','My Account'); ?>
<?php $__env->startSection('body_content'); ?>

<div class="row">
        <div class="col-md-12">

<?php if(Auth::user()->status == 0): ?>
          <div class="card">
            <div class="card-header " style="font-size: 40px">Details </div>
            <div class="card-body">
              <p style="margin-left: 220px; font-size: 20px; font-family: serif;">your request is succefully send to admin
Please Wait for registration</p>

              <p style="margin-left: 220px; font-size: 20px; font-family: serif;">your restaurant will be register once approve from admin</p>
               


              
            </div>
          </div>
            
<?php else: ?>
<div class="row">
  <div class="col-md-4">
<div class="card">
  <div class="card-header">
    
  </div>
  <div class="card-body">
   <div class="penal">
     <div class="penal-heading btn btn-primary">information about food </div>
     <div class="penal-body"></div>
   </div>
  </div>
</div>
</div>

 <div class="col-md-4">
<div class="card">
  <div class="card-header">
    
  </div>
  <div class="card-body">
   <div class="penal">
     <div class="penal-heading btn btn-primary">information about acount  </div>
     <div class="penal-body"></div>
   </div>
  </div>
</div>
</div>
 <div class="col-md-4">
<div class="card">
  <div class="card-header">
    
  </div>
  <div class="card-body">
   <div class="penal ">
     <div class="penal-heading btn btn-primary
 ">information about admin </div>
     <div class="penal-body">
       
     </div>
   </div>
  </div>
</div>
</div>

</div>

<?php endif; ?>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\PFD\resources\views/hotel/dashboard.blade.php ENDPATH**/ ?>