<?php $__env->startSection('title','Employee Details'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Employee Details
                    <a href="<?php echo e(route('employee.index')); ?>" class="btn btn-md btn-default" style="float: right;">
                        View All
                    </a>

                </div>
                <div class="panel-body">
                    <div class="row">
                       
                        <div class="col-md-4">
                            <h3>Employee Type</h3>
                            <p><?php echo e($employee->employeeType->type_name); ?></p>
                            <hr>
                            <h3>Address</h3>
                            <p><?php echo e($employee->address); ?></p>
                            <hr>
                        </div>
                        <div class="col-md-4">
                            <h3>Name</h3>
                            <p><?php echo e($employee->name); ?></p>
                            <hr>
                            <h3>Salary</h3>
                            <p><?php echo e($employee->salary); ?></p>
                            <hr>
                        </div>
                        <div class="col-md-4">
                            <h3>Mobile</h3>
                            <p><?php echo e($employee->mobile); ?></p>
                            <hr>
                            <h4>Delete</h4>
                            <?php echo e(Form::open(['method' => 'DELETE', 'action'=>['HotelEmployeeController@destroy',$employee->id], 'role'=>'form', 'files'=>'true'])); ?>

                            <button class="btn btn-warning">Delete</button>
                            <?php echo e(Form::close()); ?>

                            <h4>Update</h4>
                             <a href="<?php echo e(route('employee.edit',$employee->id)); ?>" class="btn btn-primary">Update</a>
                            <hr>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PFD\resources\views/hotel/employee/show.blade.php ENDPATH**/ ?>