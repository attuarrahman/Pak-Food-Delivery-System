<?php $__env->startSection('title','All Foods'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All Foods
                    <a href="<?php echo e(route('food.create')); ?>" class="btn btn-md btn-default" style="float: right;">
                        Add Food
                    </a>
              
   </div>
   

    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <div class="col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <?php echo e($food->name); ?>

                    </div>
                    <div class="panel-body">
                        <img src="<?php echo e(asset('uploads/food/'.$food->image)); ?>" class="img-responsive">
                        <hr>
                        Category: <?php echo e($food->category->name); ?> <br>
                        Price: <?php echo e($food->price); ?> <br>
                        <a href="<?php echo e(route('food.show',$food->id)); ?>" class="btn btn-block btn-md btn-primary">View
                            Details</a>
                    </div>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <p style="text-align: center">No food found. please add some food.</p>

        <?php endif; ?>
    </div>
     </div>
          </div>
            </div>
            

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\PFD\resources\views/hotel/food/index.blade.php ENDPATH**/ ?>