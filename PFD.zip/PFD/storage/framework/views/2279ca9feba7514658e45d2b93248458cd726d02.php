<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e($hotel->name); ?></div>
                <div class="card-body">
                   <table class="table">
                       <thead>
                           <th>Country</th>
                           <th>Province</th>
                           <th>Location</th>
                           <th>Phone</th>
                           <th>Email</th>
                           <th>Total many</th>

                       </thead>

                       <tr class="">
                           <td><?php echo e($hotel->country->name); ?></td>
                           <td><?php echo e($hotel->province->name); ?></td>
                           <td><?php echo e($hotel->city->city_name); ?></td>
                           <td><?php echo e($hotel->phone); ?></td>
                           <td><?php echo e($hotel->email); ?></td>
                          
                           <td>Rs|<?php echo e($hotel->orderHistories->count()); ?></td>
                          
                          

                           


                       </tr>
                      
                  <tr>
                   <td>
                   <?php echo e(Form::open(['method' => 'DELETE', 'action'=>['AdminHotelController@destroy',$hotel->id], 'role'=>'form', 'files'=>'true'])); ?>

            <button type="submit" class="btn btn-danger">Delete</button>
              
                  <?php echo e(Form::close()); ?>

                  </td>
                  <td>

                       <?php echo e(Form::open(['method' => 'PUT', 'action'=>['RequestHotelController@update',$hotel->id], 'role'=>'form', 'files'=>'true'])); ?>

                       <input type="hidden" name="Block" value="5">
            <button type="submit" class="btn btn-primary">Improve</button>
            <?php echo e(Form::close()); ?>

            </td>
            
             
                  </tr>
                 
                  </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\OFO\resources\views/admin/Request_hotel/show.blade.php ENDPATH**/ ?>