<?php $__env->startSection('title','Hotel Details'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>Hotel Products</h1>
                    <p>
                        <?php if(session('hotel')->rating->count() > 0): ?>
                        <?php
                        $total_stars = 0;
                        foreach (session('hotel')->rating as $item) {
                            $total_stars = $total_stars + $item->starts;
                        }
                        $rating = $total_stars / session('hotel')->rating->count();
                        ?>
                        <span>Rating (<?php echo e(round($rating,1)); ?> <i class="fa fa-star"></i>)</span>
                        <?php else: ?>
                        (0 <i class="fa fa-star"></i>)
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php if(session('info')): ?>
        <p class="alert alert-success"><?php echo e(session('info')); ?></p>
    <?php endif; ?>
    <?php if(session('warning')): ?>
        <p class="alert alert-warning"><?php echo e(session('warning')); ?></p>
    <?php endif; ?>
    <div class="shop_area shop_reverse">
        <div class="container">

            <!--shop tab product start-->
            <div class="tab-content">
                <div class="tab-pane grid_view fade show active" id="large" role="tabpanel">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="row">
                                <?php if($hotel->userMenu): ?>
                                <?php if($hotel->userMenu->userMenuDetails()->count() > 0): ?>
                                <?php $__currentLoopData = $hotel->userMenu->userMenuDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                                    <div class="col-lg-3 col-md-4">
                                        <div class="single_product">
                                            <div class="product_thumb">
                                                <a href=""><img src="<?php echo e(asset('uploads/food/'.$detail->food->image)); ?>"
                                                                alt=""></a>
                                            </div>
                                            <div class="product_content">
                                                <h3>
                                                    <a href="<?php echo e(route('product.show',$detail->food_id)); ?>"><?php echo e($detail->food->name); ?></a>
                                                </h3>
                                                <span class="current_price">Rs. <?php echo e($detail->price); ?>/-</span><br>
                                                <?php echo e(Form::open(['action' => 'HomeCartController@store'])); ?>

                                                <input type="hidden" name="price" value="<?php echo e($detail->price); ?>">
                                                <input type="hidden" name="quantity" value="1">
                                                <input type="hidden" name="food_id" value="<?php echo e($detail->food_id); ?>">
                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-md btn-success">Add to Cart
                                                    </button>
                                                </div>
                                                <?php echo e(Form::close()); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php else: ?>
                                <div>product is not found that</div>
                                <?php endif; ?>
                               
                            </div>
                        </div>
                        <div class="col-md-4">
                            <?php if(\Illuminate\Support\Facades\Auth::guard('customer')->user()): ?>
                                <button type="button" class="btn btn-block btn-md btn-success"
                                        data-toggle="modal" data-target="#rate-model">
                                    Rate Hotel &nbsp; <i class="fa fa-star"></i><i class="fa fa-star"></i><i
                                            class="fa fa-star"></i>
                                </button>
                                <br>
                            <?php endif; ?>
                            <div class="sidebar_widget widget_categories">
                                <h3 class="widget_title">Our Menu For the Day!</h3>
                                <ul>
                                    <?php if($hotel->userMenu): ?>
                                    <?php $__currentLoopData = $hotel->userMenu->userMenuDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('product.show',$detail->food_id)); ?>"><?php echo e($detail->food->name); ?></a>
                                            (PKR: <?php echo e($detail->price); ?>)
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                            <div class="sidebar_widget widget_categories">
                                <h3 class="widget_title">
                                    Request through Special Order? <br>
                                    <p>"Special service through special order, some are":</p>
                                </h3>
                                <ul>
                                    <li>On time delivery</li>
                                    <li>Order beyond the limits</li>
                                    <li>Special Cooking</li>
                                    <li>More Cost but good food.</li>
                                    <br>
                                    <li>
                                        <?php if(Auth::guard('customer')->user()): ?>
                                        <?php if($hotel->userMenu): ?>
                                        <h4><a href="<?php echo e(route('super-cart.index')); ?>"
                                               class="btn btn-block btn-md btn-primary">Click to Order!</a></h4>
                                               <?php else: ?>
                                                  <h4><a href="#"
                                               class="btn btn-block btn-md btn-primary ">NO item</a></h4>

                                               <?php endif; ?>
                                               <?php else: ?>
                                               <h4><a href="<?php echo e(route('customer.login')); ?>"
                                               class="btn btn-block btn-md btn-primary">Click to Order!</a></h4>
                                               <?php endif; ?>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--shop tab product end-->
        </div>
    </div>

    <div class="modal fade" id="rate-model" tabindex="-1" role="dialog" aria-labelledby="modal-default"
         aria-hidden="true">
        <div class="modal-dialog modal- modal-dialog-centered modal-" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="modal-title-default">Write A Review</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <button class="btn btn-md btn-default" onclick="addStars(1)" id="btn_1"><i
                                    class="fa fa-star"></i></button>
                        <button class="btn btn-md btn-default" onclick="addStars(2)" id="btn_2"><i
                                    class="fa fa-star"></i></button>
                        <button class="btn btn-md btn-default" onclick="addStars(3)" id="btn_3"><i
                                    class="fa fa-star"></i></button>
                        <button class="btn btn-md btn-default" onclick="addStars(4)" id="btn_4"><i
                                    class="fa fa-star"></i></button>
                        <button class="btn btn-md btn-default" onclick="addStars(5)" id="btn_5"><i
                                    class="fa fa-star"></i></button>
                    </div>
                    <?php echo e(Form::open(['action' => 'RatingController@store'])); ?>

                    <input type="hidden" name="stars" id="stars" value="">
                    <div class="form-group">
                        <label for="">Review</label>
                        <textarea name="review" rows="4" class="form-control">
                        </textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-md btn-default">Rate Now</button>
                    <?php echo e(Form::close()); ?>

                    <button type="button" class="btn btn-md btn-link" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script>

        function addStars(stars) {
            document.getElementById('stars').value = stars;
            if (stars == 1) {
                $('#btn_1').addClass('btn-success', true);
                $('#btn_2').addClass('btn-default', true);
                $('#btn_3').addClass('btn-default', true);
                $('#btn_4').addClass('btn-default', true);
                $('#btn_5').addClass('btn-default', true);
            }
            if (stars == 2) {
                $('#btn_2').addClass('btn-success', true);
                $('#btn_1').addClass('btn-default', true);
                $('#btn_3').addClass('btn-default', true);
                $('#btn_4').addClass('btn-default', true);
                $('#btn_5').addClass('btn-default', true);
            }
            if (stars == 3) {
                $('#btn_3').addClass('btn-success', true);
                $('#btn_2').addClass('btn-default', true);
                $('#btn_1').addClass('btn-default', true);
                $('#btn_4').addClass('btn-default', true);
                $('#btn_5').addClass('btn-default', true);
            }
            if (stars == 4) {
                $('#btn_4').addClass('btn-success', true);
                $('#btn_2').addClass('btn-default', true);
                $('#btn_3').addClass('btn-default', true);
                $('#btn_1').addClass('btn-default', true);
                $('#btn_5').addClass('btn-default', true);
            }
            if (stars == 5) {
                $('#btn_5').addClass('btn-success', true);
                $('#btn_2').addClass('btn-default', true);
                $('#btn_3').addClass('btn-default', true);
                $('#btn_4').addClass('btn-default', true);
                $('#btn_1').addClass('btn-default', true);
            }
        }

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\OFO\resources\views/links/hotel/show.blade.php ENDPATH**/ ?>