<?php $__env->startSection('title','Add Food'); ?>
<?php $__env->startSection('body_content'); ?>

    <?php if(session('info')): ?>
        <p class="alert alert-success"><?php echo e(session('info')); ?></p>
        <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Add Food
                    <a href="<?php echo e(route('food.index')); ?>" class="btn btn-md btn-primary" style="float: right;">
                        View All
                    </a>
                </div>
                <div class="panel-body">
                    <?php echo e(Form::open(['action' => 'HotelFoodController@store','files' => true])); ?>

                    <div class="row">
                        <div class="col-md-4">
                            <label for="">Select Category</label>
                            <small> *</small>
                            <select name="category_id" class="form-control" required>
                                <option value="">Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="">Food</label>
                            <small> *</small>
                            <input type="text" name="name" class="form-control" placeholder="Food Name" required>
                        </div>
                        <div class="col-md-4">
                            <label for="">Price</label>
                            <small> *</small>
                            <input type="text" name="price" class="form-control" placeholder="Food Price" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <label for="">Select Image</label>
                            <small> *</small>
                            <input type="file" name="image" class="form-control" required>
                        </div>
                        <div class="col-md-8">
                            <label for="">Description</label>
                            <small> *</small>
                            <textarea name="description" class="form-control" rows="4" placeholder="Description..." required></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-md btn-primary">Add Food</button>
                            </div>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OFO\resources\views/hotel/food/create.blade.php ENDPATH**/ ?>