<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('body_content'); ?>

     <div class="row">
        <div class="col-md-12">
          <?php if(session('info')): ?>
        <p class="alert alert-success"><?php echo e(session('info')); ?></p>
        <?php endif; ?>
         <?php if(session('warning')): ?>
        <p class="alert alert-warning"><?php echo e(session('warning')); ?></p>
        <?php endif; ?>
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All Expenses
                    <a href="<?php echo e(route('expenses.create')); ?>" class="btn btn-md btn-default" style="float: right;">
                        Add Expenses
                    </a>
                </div>
                <div class="panel-body">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>S.No</th>
                          <th>Amount</th>
                          <th>Date</th>
                          <th>Details</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $i = 1; ?>
                    <?php $__currentLoopData = Auth::user()->expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($i++); ?></td>                          
                          <td><?php echo e($expenses->amount); ?></td>                          
                          <td><?php echo e($expenses->created_at->toFormattedDateString()); ?></td>                          
                          <td>
                            <a href="<?php echo e(route('expenses.show',$expenses->id)); ?>" class="btn btn-sm btn-primary">View</a>
                          </td>                          
                        </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PFD\resources\views/hotel/expenses/index.blade.php ENDPATH**/ ?>