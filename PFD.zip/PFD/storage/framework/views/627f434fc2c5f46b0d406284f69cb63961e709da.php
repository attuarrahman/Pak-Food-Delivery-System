<?php $__env->startSection('title','Generate Report'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <?php if(session('info')): ?>
                <p class="alert alert-success"><?php echo e(session('info')); ?></p>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    Generate Report
                    <a href="<?php echo e(route('order-history.show',$order->id)); ?>" class="btn btn-md btn-primary"
                       style="float: right;">
                        Back To Order
                    </a>
                </div>
                <div class="panel-body">
                    <button style="float: right;" class="btn btn-sm btn-primary" onclick="printDiv('print-report')"
                            style="cursor:pointer;">
                        <i class="fa fa-print"></i>
                        Print Report
                    </button>
                    <div id="print-report">
                        <div class="row text-center">
                            <div class="col-md-1"></div>
                            <div class="col-md-10 text-center">
                                <h2><?php echo e($order->user->name); ?></h2>
                                <hr>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                        <div class="row text-center">
                            <div class="col-md-1"></div>
                            <div class="col-md-5">
                                <h4>Customer Details</h4>
                                <hr>
                                <h5>Customer: <?php echo e($order->customer->name); ?></h5>
                                <h5>Mobile: <?php echo e($order->customer->mobile); ?></h5>
                                <h5>Address: <?php echo e($order->customer->address); ?></h5>
                            </div>
                            <div class="col-md-5">
                                <h4>Order Details</h4>
                                <hr>
                                <h5>Order Location: <?php echo e($order->order_location); ?></h5>
                                <h5>Order Description: <?php echo e($order->description); ?></h5>
                                <h5>Order Date: <?php echo e($order->created_at->toDateTimeString()); ?></h5>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="col-md-10">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Sub Total</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $sno = 1; $grand_total = 0; ?>
                                    <?php $__currentLoopData = $order->orderHistoryDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($sno++); ?></td>
                                            <td><?php echo e($detail->food->name); ?></td>
                                            <td><?php echo e($detail->quantity); ?></td>
                                            <td><?php echo e($detail->price); ?></td>
                                            <td>
                                                <?php $total = $detail->price * $detail->quantity;?>
                                                PKR <?php echo e($total); ?>

                                            </td>
                                        </tr>
                                        <?php $grand_total = $grand_total + $total; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>Total: PKR <?php echo e($grand_total); ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script>

        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\OFO\resources\views/hotel/order-history/edit.blade.php ENDPATH**/ ?>