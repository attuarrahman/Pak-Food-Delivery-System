<?php $__env->startSection('title','Add Employee'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    All
                    <a href="<?php echo e(route('employee.index')); ?>" class="btn btn-md btn-default" style="float: right;">
                        View All
                    </a>
                </div>
                <div class="panel-body">
                    <?php echo e(Form::open(['action' => 'HotelEmployeeController@store'])); ?>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <lable>Select Type</lable>
                                <select name="employee_type_id" class="form-control" required>
                                    <option value="">Select Type</option>
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <lable>Mobile</lable>
                                <input type="text" name="mobile" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <lable>Salary</lable>
                                <input type="text" name="salary" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-md btn-primary">Add Employee</button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <lable>Name</lable>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <lable>Address</lable>
                                <input type="text" name="address" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>


                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\PFD\resources\views/hotel/employee/create.blade.php ENDPATH**/ ?>