<?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li>
        <a href="<?php echo e(route('check-out.edit',$notification->order_history_id)); ?>">
            <?php echo e($notification->orderHistory->user->name); ?>

            <br>
            <span>Date: <?php echo e($notification->created_at->toDateTimeString()); ?></span>
        </a>
    </li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\Xampp\htdocs\OFO\resources\views/ajax-views/customer-notification.blade.php ENDPATH**/ ?>