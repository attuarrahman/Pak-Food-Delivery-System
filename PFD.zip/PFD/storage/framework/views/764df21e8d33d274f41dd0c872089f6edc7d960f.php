<?php $__env->startSection('title','Verification Code'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-2">
                <?php if(Session::has('success')): ?>
                    <p class="alert alert-primary"><?php echo e(Session('success')); ?></p>
                <?php endif; ?>
                    <?php if(Session::has('warning')): ?>
                        <p class="alert alert-primary"><?php echo e(Session('warning')); ?></p>
                    <?php endif; ?>
                <div class="panel panel-primary">
                    <div class="panel-heading">Enter Verification Code</div>
                    <div class="panel-body">
                        <form action="<?php echo e(url('/code-verification')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="text" name="token" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-md btn-primary">Verify Code</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\PFD\resources\views/auth/new-password/verification-code.blade.php ENDPATH**/ ?>