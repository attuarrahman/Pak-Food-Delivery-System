<?php $__env->startSection('title','Block Restaurant'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
          <?php if(session('success')): ?>
          <p class="alert alert-info"><?php echo e(session('success')); ?></p>
          <?php endif; ?>
            <div class="card">
                <div style="color:white;background-color: steelblue" class="card-header">Block Restaurant</div>
                <div class="card-body">
                  <?php if($hotel->count() > 0 or $hotel->stutus==2): ?>
                   <table class="table">
                       <thead>
                          <th>Restaurnt Name</th>
                           <th>Country</th>
                           <th>Province</th>
                           <th>Location</th>
                           <th>Phone</th>
                           <th>Email</th>
                           <th>Total Money</th>
                           <th>Remaning Money</th>
                           <th>Recevied</th>
                           

                       </thead>

                       <tr class="">
                           <td><?php echo e($hotel->name); ?></td>
                           <td><?php echo e($hotel->country->name); ?></td>
                           <td><?php echo e($hotel->province->name); ?></td>
                           <td><?php echo e($hotel->city->city_name); ?></td>
                           <td><?php echo e($hotel->phone); ?></td>
                           <td><?php echo e($hotel->email); ?></td>
                          <?php $rupes=$hotel->orderHistories->count() ?>
                          <?php $recevied_money=DB::table('Money')->get(); ?>
                          <td><?php echo e($rupes); ?>/PKR</td>
                          <?php if($recevied_money->count() > 0 ): ?>
                          <?php $__currentLoopData = $recevied_money; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $money): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($money->money); ?>

                          <?php $paymoney=$rupes-$money->money ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                           <td><?php echo e($paymoney); ?></td> 
                            <?php endif; ?>
                           
                           <td><div class="col-md-4">
            <button style="margin-left:-30px" type="button" class="btn btn-md-success" data-toggle="modal" data-target="#modal-notification">recevied</button>
            <div class="modal fade" id="modal-notification" tabindex="-1" role="dialog" aria-labelledby="modal-notification" aria-hidden="true">
              <div class="modal-dialog modal-danger modal-dialog-centered modal-" role="document">
                <div class="modal-content bg-gradient-danger">
                  <div class="modal-header" style="background-color:goldenrod">
                    <h6 class="modal-title" id="modal-title-notification">Recevied Money From Restaurant</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="py-2 text-center">
                       <?php echo e(Form::open(['method'=>'POST','action'=>['MoneyController@store','files'=>true]])); ?>

                        
                        <label><b>Enter Recevied Money</b></label>
                        <div class="form-group">
                        <input type="number" name="money" class="form-control">
                      </div>
                      <button type="submit" class="btn btn-white">Add</button>
                     <?php echo e(Form::close()); ?>

                    </div>
                  </div>
                  <div class="modal-footer">
                    
                    <button type="button" class="btn btn-link text-white ml-auto" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>
          </div></td>
                         
                           
                           


                       </tr>
                      
                  <tr>
                
            <td>
              <?php echo e(Form::open(['method' => 'put', 'action' => ['BlockController@update',$hotel->id]])); ?>

              <button type="submit" class="btn btn-danger">Block Restaurant</button>
            </td>
             
                  </tr>
                 
                  </table>
                  <?php else: ?>
                  <h5 style="text-align: center"> Restaurant not found!</h5>
                  <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\PFD\resources\views/admin/Block/show.blade.php ENDPATH**/ ?>