<form action="<?php echo e(url('/send-email-to-account')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" value="<?php echo e($user->id); ?>" name="user_id">
    <input type="hidden" value="<?php echo e($user->token); ?>" name="token">
    <div class="form-group">
        <label for="">Email</label>
        <input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control" readonly>
    </div>
    <div class="form-group">
        <button class="btn btn-md btn-primary">Send Reset Password Link</button>
    </div>
</form><?php /**PATH E:\xampp\htdocs\PFD\resources\views/auth/passwords/send-email.blade.php ENDPATH**/ ?>