<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Expense Details
                    <a href="<?php echo e(route('expenses.index')); ?>" class="btn btn-md btn-default" style="float: right;">
                        View All
                    </a>                </div>
                <div class="panel-body">
                    <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Amount</th>
      <th scope="col">Description</th>
      <th scope="col">Update</th>
      <th scope="col">Delete</th>

     
    </tr>
  </thead>
  <tbody>

    <tr>
      <th scope="row">1</th>
      <td><?php echo e($expenses->amount); ?></td>
      <td><?php echo e($expenses->description); ?></td>
      <td>
          <?php echo e(Form::open(['method' => 'GET', 'action'=>['ExpensesController@edit',$expenses->id], 'role'=>'form', 'files'=>'true'])); ?>

            <button type="submit" class="btn btn-primary">Update</button>
              
        <?php echo e(Form::close()); ?>

      </td>
      <td>
          <?php echo e(Form::open(['method' => 'DELETE', 'action'=>['ExpensesController@destroy',$expenses->id], 'role'=>'form', 'files'=>'true'])); ?>

            <button type="submit" class="btn btn-danger">Delete</button>
              
        <?php echo e(Form::close()); ?>

      </td>

     
    </tr>
  </tbody>
</table>

                </div>
            </div>
          
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\OFO\resources\views/hotel/expenses/show.blade.php ENDPATH**/ ?>