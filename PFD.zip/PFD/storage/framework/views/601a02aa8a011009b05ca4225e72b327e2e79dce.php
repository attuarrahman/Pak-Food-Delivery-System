<?php $__env->startSection('title','Order Details'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>Order Details</h1>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <section class="main_content_area">
        <div class="container">
            <div class="account_dashboard">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h2><?php echo e($order->user->name); ?></h2>
                        
                       <!--  <?php if($order->status == 1  ): ?>
                        <b>Order Status:Your Order is Successfully completed</b>
                        <?php else: ?>
                        <b>Yoru Order is in Pending please wait...</b>
                        <?php endif; ?>  -->
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table_desc">
                            <div class="cart_page table-responsive">
                                <table>
                                    <thead>
                                    <tr>
                                        <th class="product_remove">S.No</th>
                                        <th class="product_thumb">Image</th>
                                        <th class="product_name">Product</th>
                                        <th class="product-price">Price</th>
                                        <th class="product_quantity">Quantity</th>
                                        <th class="product_total">Total</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $sno = 1; $grand_total = 0; ?>
                                    <?php $__currentLoopData = $order->orderHistoryDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($sno++); ?></td>
                                            <td><img src="<?php echo e(asset('uploads/food/'.$detail->food->image)); ?>" width="100px" height="100px"></td>
                                            <td><?php echo e($detail->food->name); ?></td>
                                            <td>PKR <?php echo e($detail->price); ?>/-</td>
                                            <td><?php echo e($detail->quantity); ?></td>
                                            <?php $total = $detail->price * $detail->quantity; ?>
                                            <td>PKR <?php echo e($total); ?>/-</td>
                                        </tr>
                                        <?php $grand_total = $grand_total + $total; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <hr>
                                <h3 style="text-align: right">Total: <?php echo e($grand_total); ?>/-</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\PFD\resources\views/links/order/edit.blade.php ENDPATH**/ ?>