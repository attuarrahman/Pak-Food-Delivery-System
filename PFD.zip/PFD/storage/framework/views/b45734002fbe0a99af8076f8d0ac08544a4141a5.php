<?php $__env->startSection('title','Request Restaurant'); ?>
<?php $__env->startSection('body_content'); ?>
<style type="text/css">
    
</style> 

    <div class="row">
        <div class="col-md-12">
              <?php if(session('success')): ?>
            <p class="alert alert-info"><?php echo e(session('success')); ?></p>
            <?php endif; ?>
            <div class="card">
                <div style="color:white;background-color: steelblue" class="card-header">Restaurant Request</div>
                <div class="card-body">
                    <div class="row">
                       
                            <?php $hotel = DB::table('users')->where('status',0)->get(); ?>
                            <?php $__empty_1 = true; $__currentLoopData = $hotel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header" style="background-color: blue; color: white"><?php echo e($hotels->name); ?></div>
                                <div class="card-body">
                                    <img src="<?php echo e(asset('uploads/food/'.$hotels->logo)); ?>" height="100" width="200">
                                    <p class="">Mobile Number|<?php echo e(date('m-Y', strtotime($hotels->created_at))); ?></p>
                                    <div>
                                        <p class="">Deuration</p>
                                    </div>
                                    <a href="<?php echo e(route('request_hotel.show',$hotels->id)); ?>" class="btn btn-success">Views</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h5 style="text-align: center;">No Restaurant Request Found!</h5>
                        <?php endif; ?>
                       
                 
                    </div>

          </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PFD\resources\views/admin/request_hotel/index.blade.php ENDPATH**/ ?>