<?php $__env->startSection('title','My Account'); ?>
<?php $__env->startSection('body_content'); ?>
    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>My Account</h1>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
       <div style="margin-left: 380px" class="col-md-6"> 
            <div class="card">
                <div style="background-color:#428bca;color: white" class="card-header">Profile Updation</div>

                <div class="card-body">
                 <?php echo e(Form::open(['method'=>'put','files'=>true,'action'=>['CustomerProfileController@update',$profile->id]])); ?>

                 <div class="row">
                 <div class="col-md-6">
                 <div class="form-group">
                  <label>Name</label>
                  <input class="form-control" type="name" name="name" value="<?php echo e($profile->name); ?>" >
                  <label>Email</label>
                  <input class= "form-control" type="email" name="email" value="<?php echo e($profile->email); ?>">
                  <div class="form-group">
                  <label>Mobile</label>
                  <input class="form-control" type="text" name="mobile" value="<?php echo e($profile->mobile); ?>">
                  <label>CNIC No</label>
                  <input class="form-control" type="text" name="cnic" value="<?php echo e($profile->cnic); ?>">
                   </div>
                 <!--  <?php $countries=DB::table('countries')->get(); ?>
                  <label>Country</label>
                  <select class="form-control" name="country_id" value="country_id">
                  <option value="">Select Country</option>
                  <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option  value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <label>Province</label>
                  <select class="form-control" name="province_id" id="province_id" value="<?php echo e($profile->province->name); ?>">
                    <option value="">select province</option>
                  </select>
                  <label>City</label>
                 <select class="form-control" name="city_id" id="city_id" value="<?php echo e($profile->city->city_name); ?>" id="city_id" required>
                                        <option value="">Select City</option>
                                    </select> -->
                  <br>
                <?php echo e(Form::submit('Update Profile',['class'=>'btn btn-primary'])); ?>

                 
                  
                </div>
                 </div>
                 <div class="col-md-6">
                 <label>DOB</label>
                  <input class="form-control" type="date" name="dob" value="<?php echo e($profile->dob); ?>">
                  <label>Address</label>
                  <input class="form-control" type="text" name="address" value="<?php echo e($profile->address); ?>">
                  <label>Picture</label>
                <input class="form-control" type="file" name="profile">
            </div>
              

              <?php echo e(Form::close()); ?> 
                </div>
              </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

   <script>

    function getProvince() {
        var country_id = document.getElementById('country_id').value;
        if (country_id == null) {
            document.getElementById('country_id').style.border = "1px solid red";
        } else {
            document.getElementById('country_id').style.border = "1px solid #ced4da";
            var data = "country_id=" + country_id;
            $.ajax({
                type: "GET",
                url: '<?php echo e(URL::to('/get-province-name')); ?>',
                data: data,
                success: function (data) {
                    document.getElementById('province_id').innerHTML = data;
                }
            });
        }
    }

    function getCity() {
        var province_id = document.getElementById('country_id').value;
        if (province_id == null) {
            document.getElementById('province_id').style.border = "1px solid red";
        } else {
            document.getElementById('province_id').style.border = "1px solid #ced4da";
            var data = "province_id=" + province_id;
            $.ajax({
                type: "GET",
                url: '<?php echo e(URL::to('/get-city-name')); ?>',
                data: data,
                success: function (data) {
                    document.getElementById('city_id').innerHTML = data;
                }
            });
        }
    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\PFD\resources\views/links/account/edit.blade.php ENDPATH**/ ?>