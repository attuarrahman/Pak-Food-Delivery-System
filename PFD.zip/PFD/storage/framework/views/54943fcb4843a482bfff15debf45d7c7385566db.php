<script>
	jQuery(document).ready(function($){

alert('hi i am atta');

});
</script><?php /**PATH C:\xampp\htdocs\PFD\resources\views/ajax-views/category-search.blade.php ENDPATH**/ ?>