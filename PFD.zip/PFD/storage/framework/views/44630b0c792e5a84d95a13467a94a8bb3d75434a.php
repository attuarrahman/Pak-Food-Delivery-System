<?php $__env->startSection('title','My Account'); ?>
<?php $__env->startSection('body_content'); ?>
  <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div style="color:white;background-color: steelblue"  class="card-header" >
                    <p style="margin-left:15px;">My Account</p>
                    <a href="<?php echo e(route('my-account.edit',Auth::id())); ?>" class="btn btn-md btn-default" style="float: right;">
                    Update
                    </a>
                    <br>
                    <br>
                </div>
                <div class="card-body">
                   <div class="card bg-dark" >
                       <div class="card-body ">
                           
                  <img src="<?php echo e(asset('uploads/food/'.Auth::user()->logo)); ?>" height="100" width="100" class="img-circle" style="margin-top: 20px">
                  <h6 align="center"><?php echo e(Auth::user()->name); ?></h6>

                  <img src="<?php echo e(asset('uploads/food/'.Auth::user()->banner)); ?>" height="200" width="150" class="img-thumbnail" style="margin-top: 20px" align="right">  
                   
                       </div>
                       <div class="card" style="margin-top: 120px">
                           <div class="card-header"></div>
                           <div class="card-body">
                               <label style="font-family: fantasy; font-size: 30px">personal information</label>
                               <br>
                               <label style="margin-top: 40px; font-family: sans-serif;">country</label>
                               <div class="row">
                                <div class="col-md-2">
                                         <p class="text" style="font-family: serif;"><?php echo e(Auth::user()->country->name); ?></p>
                                            <label style="margin-top: 40px">province</label>
                                         <p class="text" style="font-family: serif;"><?php echo e(Auth::user()->province->name); ?></p>
                                          
                                         </div>
                                         <div class="col-md-2" style="margin-top: -30px">
                                              <label style="">City</label>
                                         <p class="text" style="font-family: serif;"><?php echo e(Auth::user()->city->city_name); ?></p> 
                                          <label style="margin-top: 40px">Location</label>
                                         <p class="text" style="font-family: serif;"><?php echo e(Auth::user()->location); ?></p>
                                         </div>
                                         <div class="col-md-2" style="margin-top: -30px">
                                              <label style="">Email</label>
                                         <p class="text" style="font-family: serif;"><?php echo e(Auth::user()->email); ?></p>  <label style="margin-top: 40px">Phone</label>
                                         <p class="text" style="font-family: serif;"><?php echo e(Auth::user()->phone); ?></p>
                                         </div>
                                         <div class="col-md-2" style="margin-top: -30px">
                                              <label style="">Opening Time</label>
                                         <p class="text" style="font-family: serif;"><?php echo e(Auth::user()->opening_timing); ?></p>  <label style="margin-top: 40px">Closing Time</label>
                                         <p class="text" style="font-family: serif;"><?php echo e(Auth::user()->closing_timing); ?></p>
                                         </div>
                                         <div class="col-md-2" style="margin-top: -30px">
                                              <label style="">Description</label>
                                         <p class="text" style="font-family: serif;"><?php echo e(Auth::user()->description); ?></p>  
                                         
                                         </div>
                                         </div>

                                </div>
                       </div>
                   </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\PFD\resources\views/hotel/my-account/show.blade.php ENDPATH**/ ?>