  <div class="shop_area shop_reverse">
        <div class="container">
            <!--shop tab product start-->
            <div class="tab-content">
                <div class="tab-pane grid_view fade show active" id="large" role="tabpanel">
	                    <?php $__currentLoopData = $food_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <div class="row">
                             	<?php if($category->user->userMenu): ?>
                            <div  class="col-lg-3 col-md-4">
                                        <div class="single_product">
                                            <div class="product_thumb">
                                                <a href=""><img src="<?php echo e(asset('uploads/food/'.$category->image)); ?>"
                                                                alt=""></a>
                                            </div>
                                            <div class="product_content">
                                           <h3>
                                                    <a href="<?php echo e(route('product.show',$category->id)); ?>"><?php echo e($category->name); ?></a>
                                                </h3>
                                                <span class="current_price">Rs.<?php echo e($category->price); ?>/-</span><br>
                                                <?php echo e(Form::open(['action' => 'HomeCartController@store'])); ?>

                                                <input type="hidden" name="price" value="<?php echo e($category->price); ?>">
                                                <input type="hidden" name="quantity" value="1">
                                                <input type="hidden" name="food_id" value="<?php echo e($category->id); ?>">
                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-md btn-success">Add to Cart
                                                    </button>
                                                </div>
                                                <?php echo e(Form::close()); ?>

                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                            </div> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
<?php /**PATH C:\xampp\htdocs\PFD\resources\views/hotel/category/SearchCategory.blade.php ENDPATH**/ ?>