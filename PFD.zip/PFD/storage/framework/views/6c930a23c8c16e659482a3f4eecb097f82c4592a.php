<?php $__env->startSection('title',' Restaurant Request'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">

            <div class="card">
                <div style="color:white; background-color: steelblue" class="card-header"><?php echo e($hotel->name); ?>

                   <a href="<?php echo e(url('/admin/request_hotel')); ?>" class="btn btn-md btn-success" style="float: right;">View All

                    </a></div>
                <div class="card-body">
                   <table class="table">
                       <thead>
                           <th>Country</th>
                           <th>Province</th>
                           <th>Location</th>
                           <th>Phone</th> 
                           <th>Email</th>
                           <th>Total money</th>

                       </thead>

                       <tr class="">
                           <td><?php echo e($hotel->country->name); ?></td>
                           <td><?php echo e($hotel->province->name); ?></td>
                           <td><?php echo e($hotel->city->city_name); ?></td>
                           <td><?php echo e($hotel->phone); ?></td>
                           <td><?php echo e($hotel->email); ?></td>
                          
                           <td>Rs|<?php echo e($hotel->orderHistories->count()); ?></td>
                          
                          

                           


                       </tr> 
                      
                  <tr>
                   <td>
                   <?php echo e(Form::open(['method' => 'DELETE', 'action'=>['AdminHotelController@destroy',$hotel->id], 'role'=>'form', 'files'=>'true'])); ?>

            <button type="submit" class="btn btn-danger">Delete Restaurant</button>
              
                  <?php echo e(Form::close()); ?>

                  </td> 
                  <td>

                       <?php echo e(Form::open(['method' => 'PUT', 'action'=>['RequestHotelController@update',$hotel->id], 'role'=>'form', 'files'=>'true'])); ?>

                       <input type="hidden" name="Block" value="5">
            <button type="submit" class="btn btn-primary">Approve Restaurant</button>
            <?php echo e(Form::close()); ?>

            </td>
            
             
                  </tr>
                 
                  </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PFD\resources\views/admin/Request_hotel/show.blade.php ENDPATH**/ ?>