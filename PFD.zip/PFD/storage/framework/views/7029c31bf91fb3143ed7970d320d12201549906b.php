<?php $__env->startSection('title','Add Country'); ?>
<?php $__env->startSection('body_content'); ?>

    <?php if(session('info')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Add Country
                    <a href="<?php echo e(route('country.index')); ?>" class="btn btn-md btn-primary" style="float: right;">View All</a>
                </div>
                <div class="card-body">
                    <?php echo e(Form::open(['action' => 'AdminCountryController@store'])); ?>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <lable>Country Name</lable>
                                <input type="text" name="name" placeholder="Country Name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <lable>Short Name</lable>
                                <input type="text" name="short_name" placeholder="Short Name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-md btn-primary">Add</button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <lable>Country Code</lable>
                                <input type="text" name="code" placeholder="Country Code" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\OFO\resources\views/admin/country/create.blade.php ENDPATH**/ ?>