<?php $__env->startSection('title','My Cart'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>Cart Details</h1>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php if(session('info')): ?>
        <p class="alert alert-success"><?php echo e(session('info')); ?></p>
    <?php endif; ?>
    <?php if(session('warning')): ?>
        <p class="alert alert-warning"><?php echo e(session('warning')); ?></p>
    <?php endif; ?>
    <div class="shopping_cart_area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="table_desc">
                        <div class="cart_page table-responsive">
                            <table>
                                <thead>
                                <tr>
                                    <th class="product_remove">Delete</th>
                                    <th class="product_thumb">Image</th>
                                    <th class="product_name">Product</th>
                                    <th class="product-price">Price</th>
                                    <th class="product_quantity">Parsal</th>
                                    <th class="product_total">Total</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $grand_total = 0; ?>
                                <?php $__currentLoopData = $customer->carts()->orderBy('created_at','asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="product_remove">
                                            <?php echo e(Form::open(['method' => 'delete','action' => ['HomeCartController@destroy',$item->id]])); ?>

                                            <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash-o"
                                                                                                   style="color: #fff;"></i>
                                            </button>
                                            <?php echo e(Form::close()); ?>

                                        </td>
                                        <td class="product_thumb">
                                            <img src="<?php echo e(asset('uploads/food/'.$item->food->image)); ?>" width="100px"
                                                 height="100px">
                                        </td>
                                        <td class="product_name">
                                            <?php echo e($item->food->name); ?>

                                        </td>
                                        <td class="product-price">
                                            PKR <?php echo e($item->price); ?>/-
                                        </td>
                                        <td class="product_quantity">
                                            <?php echo e(Form::open(['method' => 'put','action' => ['HomeCartController@update',$item->id]])); ?>

                                            <input name="quantity" min="1" max="12" value="<?php echo e($item->quantity); ?>"
                                                   type="number">
                                            <span>
                                                <button type="submit" class="btn btn-sm btn-primary">Update</button>
                                            </span>
                                            <?php echo e(Form::close()); ?>

                                        </td>
                                        <td class="product_total">
                                            <?php $total = $item->price * $item->quantity; ?>
                                            PKR <?php echo e($total); ?>/-
                                        </td>
                                    </tr>
                                    <?php $grand_total = $grand_total + $total; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--coupon code area start-->
            <?php if($customer->carts()->count() > 0): ?>
                <div class="coupon_area">
                    <div class="row">
                        <div class="col-lg-6 col-md-6"></div>
                        <div class="col-lg-6 col-md-6">
                            <div class="coupon_code right">
                                <h3>Cart Totals</h3>
                                <div class="coupon_inner">
                                    <div class="cart_subtotal">
                                        <p>Total</p>
                                        <p class="cart_amount">PKR <?php echo e($grand_total); ?></p>
                                    </div>
                                    <?php echo e(Form::open(['action' => 'HomeOrderController@store'])); ?>

                                    <input type="hidden" name="user_id" value="<?php echo e($item->food->user_id); ?>">
                                    <input type="hidden" value="<?php echo e($customer->id); ?>" name="customer_id">
                                    <div class="form-group">
                                        <label for="">Your Location</label>
                                        <small> *</small>
                                        <input type="text" name="order_location" class="form-control" required>
                                    </div>
                                    <div class="from-group">
                                        <label for="">Description</label>
                                        <small> *</small>
                                        <textarea name="description" required class="form-control"></textarea>
                                    </div>
                                    <br>
                                    <div class="checkout_btn">
                                        <button type="submit" class="btn btn-md btn-success">
                                            Proceed to Checkout
                                        </button>
                                    </div>
                                    <?php echo e(Form::close()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--coupon code area end-->
            <?php endif; ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OFO\resources\views/links/cart/index.blade.php ENDPATH**/ ?>