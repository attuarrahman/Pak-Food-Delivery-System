<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Online Food System</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="">
    <!-- All CSS Files -->
    <!-- Bootstrap css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <!-- Icon Font -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/et-line.css')); ?>">
    <!-- Plugins css file -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.css')); ?>">
    <!-- Theme main style -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>">
    <!-- Responsive css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
    <!-- Modernizr JS -->
    <script src="<?php echo e(asset('assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>

    <style>

        .buy-btn.top-btn {
            background-color: #7ecc13;
            border-color: #7ecc13;
        }

        .buy-btn:hover {
            background-color: #7ecc13;
            border-color: #7ecc13;
        }

        .buy-btn:focus {
            color: #fff;
        }

        .demo-item .image::after {
            background-color: #7ecc13;
        }

        .demo-item .image i:hover {
            color: #7ecc13;
        }

        .stick .buy-btn.top-btn {
            border: 2px solid #7ecc13;
            color: #fff;
        }

        .stick .buy-btn {
            border: 2px solid #7ecc13;
            color: #7ecc13;
        }

        .single-feature .icon {
            color: #7ecc13;
        }

        .footer-section {
            background-color: #444;
        }

        .stick .buy-btn:hover {
            color: #fff;
        }

        .demo-item .title a:hover {
            color: #7ecc13;
        }

        .footer-section .buy-btn:hover {
            color: #7ecc13;
        }

        .footer-section .buy-btn.bottom-btn {
            color: #fff;
            background-color: #7ecc13;
            border: 2px solid #7ecc13;
        }

        .hero-content h1 strong {
            text-transform: capitalize;
        }

        .stick .non-sticky {
            display: none;
        }

        .demo-item {
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.15);
        }

        .demo-item .title {
            padding: 20px 0;
            margin: 0;
        }

        .section-title h1 {
            line-height: 30px;
            font-size: 30px;
            text-transform: uppercase;
        }

        .logo {
            margin: 5px 0;
        }

        .overlay::before {
            opacity: 0.5;
        }

        @media  only screen and (max-width: 767px) {
            .section-title.mb-70 {
                margin-bottom: 40px;
            }

            .section-title h1 {
                font-size: 25px;
                line-height: 25px;
            }

            .demo-item .title {
                font-size: 16px;
            }

            .demo-item .title a {
                line-height: 22px;
            }

            .stick .logo a .sticky-logo {
                max-width: 130px;
            }

            @media  only screen and (max-width: 450px) {
                .logo {
                    margin: 0;
                }
            }
        }

    </style>

</head>

<body>

<!-- Navbar -->
<div class="header-section section sticker stick">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <!-- Logo -->
                <div class="logo float-left">
                    <a href="">Online Food Ordering</a>
                </div>
            </div>
            <!-- Logo -->
            <div class="col-md-7">
                <?php if(Auth::guard('customer')->user()): ?>
                    <a class="btn btn-md btn-default" style="float: right;" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                          style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                    <a class="btn btn-md btn-primary" href="<?php echo e(route('my-accounts.index')); ?>" style="float: right;">
                        My Account
                    </a>
                <?php else: ?>
                    <a class="btn btn-md btn-success" href="<?php echo e(route('register')); ?>" style="float: right;">Register as
                        Hotel</a>
                    <a class="btn btn-md btn-default" href="<?php echo e(route('customer.register')); ?>" style="float: right;">Create
                        Account</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Header -->
<div class="hero-section section overlay">
    <div class="container">
        <div class="row">
            <div class="hero-content text-center col-xs-12">
                <div class="home-content">
                        <h1 class="white-text">Welcome To Pak Food Delivery</h1>
                    </div>
            </div>

        </div>
    </div>
</div>


<div class="demo-section section pt-120 pb-70">
    <div class="container">
        <div class="row">
            <div class="section-style">
                <div class="section-title col-xs-12 mb-70">
                    <h1>Our Top Hotels</h1>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-6 col-12 mb-50">
                    <div class="demo-item">
                        <h4 class="title"><a href="<?php echo e(route('hotels.show',$hotel->id)); ?>"><?php echo e($hotel->name); ?></a></h4>
                        <p>
                            <?php if($hotel->rating->count() > 0): ?>
                            <?php
                            $total_stars =0;
                            foreach ($hotel->rating as $item) {
                                $total_stars = $total_stars + $item->starts;
                            }
                            $rating = $total_stars / $hotel->rating->count();
                            ?>
                            (<?php echo e($rating); ?> <i class="fa fa-star"></i>)
                            <?php else: ?>
                             ( 0<i class="fa fa-star"></i>)
                            <?php endif; ?>
                        </p><br>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<div class="footer-section section pt-65 pb-50">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <span class="copyright">Copyright @2018  All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></span>
            </div>
        </div>
    </div>
</div>


<!-- Placed JS at the end of the document so the pages load faster -->
<!-- jQuery latest version -->
<script src="<?php echo e(asset('assets/js/vendor/jquery-3.1.1.min.js')); ?>"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<!-- Plugins js -->
<script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
<!-- Main js -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\OFO\resources\views/index.blade.php ENDPATH**/ ?>