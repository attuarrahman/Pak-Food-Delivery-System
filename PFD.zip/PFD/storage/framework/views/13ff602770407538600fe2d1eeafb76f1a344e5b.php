<?php $__env->startSection('title','Order Details'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Order Details
                    <a href="<?php echo e(route('order-history.index')); ?>" class="btn btn-md btn-primary"
                       style="float: right;">
                        View All
                    </a>
                </div>
                <div class="panel-body">

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\OFO\resources\views/hotel/order-history/show.blade.php ENDPATH**/ ?>