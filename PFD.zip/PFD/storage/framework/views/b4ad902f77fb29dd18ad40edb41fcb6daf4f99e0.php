<!doctype html>
<html class="no-js" lang="en">
<head>
<meta name="_token" content="<?php echo e(csrf_token()); ?>">
<title>Online Food System</title>
  <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
   
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="">
    <!-- All CSS Files -->
    <!-- Bootstrap css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <!-- Icon Font -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/et-line.css')); ?>">
    <!-- Plugins css file -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.css')); ?>">
    <!-- Theme main style -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>">
    <!-- Responsive css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
    <!-- Modernizr JS -->
    <script src="<?php echo e(asset('assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <style>

        .buy-btn.top-btn {
            background-color: #7ecc13;
            border-color: #7ecc13;
        }
       #grad {
background-image: url("<?php echo e(asset('uploads/background/pak_food3.jpg')); ?>");
}

        .buy-btn:hover {
            background-color: #7ecc13;
            border-color: #7ecc13;
        }

        .buy-btn:focus {
            color: #fff;
        }

        .demo-item .image::after {
            background-color: #7ecc13;
        }

        .demo-item .image i:hover {
            color: #7ecc13;
        }

        .stick .buy-btn.top-btn {
            border: 2px solid #7ecc13;
            color: #fff;
        }

        .stick .buy-btn {
            border: 2px solid #7ecc13;
            color: #7ecc13;
        }

        .single-feature .icon {
            color: #7ecc13;
        }

        .footer-section {
            background-color: #444;
        }

        .stick .buy-btn:hover {
            color: #fff;
        }

        .demo-item .title a:hover {
            color: #7ecc13;
        }

        .footer-section .buy-btn:hover {
            color: #7ecc13;
        }

        .footer-section .buy-btn.bottom-btn {
            color: #fff;
            background-color: #7ecc13;
            border: 2px solid #7ecc13;
        }

        .hero-content h1 strong {
            text-transform: capitalize;
        }

        .stick .non-sticky {
            display: none;
        }

        .demo-item {
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.15);
        }

        .demo-item .title {
            padding: 20px 0;
            margin: 0;
        }

        .section-title h1 {
            line-height: 30px;
            font-size: 30px;
            text-transform: uppercase;
        }

        .logo {
            margin: 5px 0;
        }

        .overlay::before {
            opacity: 0.5;
        }

        @media  only screen and (max-width: 767px) {
            .section-title.mb-70 {
                margin-bottom: 40px;
            }

            .section-title h1 {
                font-size: 25px;
                line-height: 25px;
            }

            .demo-item .title {
                font-size: 16px;
            }

            .demo-item .title a {
                line-height: 22px;
            }

            .stick .logo a .sticky-logo {
                max-width: 130px;
            }

            @media  only screen and (max-width: 450px) {
                .logo {
                    margin: 0;
                }
            }
        }

    </style>

</head>

<body>
<!-- Navbar -->
<div class="container">
<div class="header-section section sticker stick" style="background-color: white" >
    <div class="container" style="">
        <div class="row">
            <div class="col-md-7">
                <!-- Logo -->
                <div class="logo">
                     
                    <img style="width: 100px; height:100px;margin-top: -20px" src="<?php echo e(asset('uploads\logo\logo.png')); ?>">


               <form class="form-inline active-pink-3 active-pink-4">
               

                </div>


            </div>
            <!-- Logo -->
            <div class="col-md-5">

                <?php if(Auth::guard('customer')->user()): ?>
                    <a class="btn btn-md btn-dark" style="float:right;" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                          style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                    <a class="btn btn-sm btn-primary" href="<?php echo e(route('my-accounts.index')); ?>" style="float: right;">
                        My Account
                    </a>
                <?php else: ?>
                      <a   href="<?php echo e(url('/')); ?>" style="float: left; margin-top: 14px; color: black">Home
                     </a>

                    <a class="btn btn-dark" href="<?php echo e(route('login')); ?>" style="float: right;">Restaurant</a>
                    <a class="btn btn-sm btn-dark" href="<?php echo e(route('customer.login')); ?>" style="float: right;">Customer</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div> 

<!-- Header -->

<div class="hero-section section overlay" style="" id="grad" >
    <div class="container" style="">
        <div class="row">
            <div class="hero-content text-center col-xs-12">
                
                        <h1 class="white-text">Welcome To Pak Food Delivery</h1>
                    </div>
            </div>

        </div>
    </div>
<br>
<br>
  <div class="demo-section section pt-120 pb-70">
    <div class="container">
     <?php if(session('success')): ?>
     <div class="row">
        <div class="col-md-4 col-md-offset-2">
        <p class="alert alert-warning"><?php echo e(session('success')); ?></p>
    
     </div>
        <?php endif; ?>
      <div  class="row">
        <?php echo e(Form::open(['action'=>'SearchController@search_country'])); ?>

                    <div class="col-md-2 ">
                           <div class="form-group">
                                    <label for="">Select Country</label>
                                    <small style="color: red;"> *</small>
                                    <select name="country_id" id="country_id" onblur="getProvince()" required 
                                            class="form-control <?php if ($errors->has('country_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('country_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <option value="">Select Country</option>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option name="country_id" value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                             </div>
                            <div class= "col-md-2">
                                 <div class="form-group">
                                    <label for="">Select Province</label>
                                    <small style="color: red;"> *</small>
                                    <select name="province_id" required id="province_id" onblur="getCity()"
                                            class="form-control <?php if ($errors->has('province_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('province_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <option value="">Select Province</option>
                                    </select>
                           </div>
                           </div>
                               <div class= "col-md-2">
                                 <div class="form-group">
                                    <label for="">Select City</label>
                                    <small style="color: red;"> *</small>
                                    <select name="city_id" id="city_id" required
                                            class="form-control <?php if ($errors->has('city_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <option value="">Select City</option></select>
                            </div>
                        </div>
                            <div class= "col-md-2" style="margin-top: 20px; margin-right: 40px">
                            <button type="submit" class="btn btn-xs-primary">Serach</button>

                            
                       
                        </div>
                    
                        
             <?php echo e(Form::close()); ?>



<div class="col-md-3">
       <div class="form-group">
                        <label class="text">Name</label>
                     <input type="text" class="form-control" id="search" name="search" placeholder="Search Restaurant Here by Name">
                    </div>
                </div>
                </div>
                <hr>
             </div> 
         </div>
<h4 id="city_id" style="text-align: center; color:darkgray"><b>ALL RESTAURANT</b></h4>

        <div id="search_id" class="row">
           <div class="col-md-12">
                <?php $__empty_1 = true; $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div  style="margin-left: 50px" class="col-md-3">
                        <div class="demo-item">
                            <h4 class="title">
                                <a href="<?php echo e(route('hotels.show',$hotel->id)); ?>"><?php echo e($hotel->name); ?> 
                                    <img  src="<?php echo e(asset('uploads/food/'.$hotel->logo)); ?>" class="img-responsive">
                                </a>
                            </h4>
                            <b>Country Name:</b><?php echo e($hotel->country->name); ?><br>
                            <b>Province:</b><?php echo e($hotel->province->name); ?><br>  
                            <b>City:</b><?php echo e($hotel->city->city_name); ?><br>
                            <b>Current Location:</b><?php echo e($hotel->location); ?>

                                    
                            
                            <br><br>      
                        </div>   
                    </div>   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <img src="public/uploads/background/not_found2.jpg" style="margin-left: 520px">
                <?php endif; ?>
           </div>
        </div>
        <br>
</div>
   </div>

<footer class="footer_widgets_area" style="background-color:#2F4F4F
">
        <div class="container">
            <div class="footer_top">  
                <div class="row">
                    <div class="col-lg-4 col-md-6" style="margin-top: 40px">
                        <div class="widgets_container">
                            <div class="footer_title">
                                 <h3 class="" style="color: white">Contact Us</h3>
                            </div>
                            <div class="footer_contact">
                                <p>
                                    <i class="fa fa-map-marker"></i>
                                    <span>Ajib ullah|Atta urrahman</span>
                                </p>
                                <p>
                                    <i class="fa fa-envelope"></i>
                                    <span>Email: ajib0342@gmail.com</span>
                                </p>
                                <p>
                                    <i class="fa fa-phone"></i>
                                    <span>Phone: 03422462969</span>
                                </p>
                            </div>
                        </div>
                    </div>
                     <div class="col-lg-4 col-md-6">
                        <div class="widgets_container">
                            <div class="footer_title">
                                 <h3 style="margin-top: 40px; color: white">Supervised By</h3>
                            </div>
                            <div class="footer_menu">
                                <div class="footer_contact">
                                <p>
                                    <i class="fa fa-user"></i>
                                    <span>Engr:Shaukat Ali</span>
                                </p>
                                <p>
                                    <i class="fa fa-envelope"></i>
                                    <span>Email: shaukar-ali@uom.edu.pk</span>
                                </p>
                                <p>
                                    <i class="fa fa-phone"></i>
                                    <span>Phone: 03459530468</span>
                                </p>
                            </div>

                            </div>
                        </div>
                    </div>

                     <div class="col-lg-2 col-md-4">
                        <div class="widgets_container">
                            <div class="footer_title">
                                 <h3 style="margin-top: 40px; color: white">My Account</h3>
                            </div>
                            <div class="footer_menu">
                                <ul>
                                    <li><a href="my-account.html">My Account</a></li>
                                    <li><a href="cart.html">Shopping Cart</a></li>
                                    <li><a href="#">Wishlist</a></li>
                                    <li><a href="#">Custom Link</a></li>
                                    <li><a href="#">Help</a></li>
<li class="fa fa-facebook"><a href="www.facebook.com">Facebook</li>

                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4">
                        <div class="widgets_container">
                            <div class="footer_title">
                                 <h3 style="margin-top: 40px; color: white">Information</h3>
                            </div>
                            <div class="footer_menu">
                                <ul>
                                    <li><a href="#">Our Blog</a></li>
                                    <li><a href="#">About Our Shop</a></li>
                                    <li><a href="#">Secure Shopping</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                    <li><a href="#">Delivery infomation</a></li>
                                    <li class="fa fa-twitter"><a href="">Twitter</a></li>

                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4">
                        <div class="widgets_container">
                            <div class="footer_title">
                                 <h3 style="margin-top: 40px; color: white"
>Business hours</h3>
                            </div>
                            <div class="footer_menu">
                                <ul>
                                    <li>Mon - Fri: --8am - 5pm</li>
                                    <li>Sat: -----8am - 11am</li>
                                    <li>Sun: -----Closed</li>
                                    <li>Sun: -----Closed</li>
                                    <li>We work all holidays</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            <div class="footer_bottom">
                <div class="row">
                    <div class="col-12">
                        <div class="payment_icons">
                            <ul>
                                <li><img src="assets/img/icon/payment1.png" alt=""></li>
                                <li><img src="assets/img/icon/payment2.png" alt=""></li>
                                <li><img src="assets/img/icon/payment3.png" alt=""></li>
                                <li><img src="assets/img/icon/payment4.png" alt=""></li>
                            </ul>
                        </div>
                        <div class="copyright_info">
                            <p>Copyright © 2018 <a href="#">M4U</a> All Rights Reserved</p>
                        </div>
                    </div>
                </div>
            </div>    
        </div>
    </footer>


<!-- Placed JS at the end of the document so the pages load faster -->
<!-- jQuery latest version -->
<script src="<?php echo e(asset('assets/js/vendor/jquery-3.1.1.min.js')); ?>"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<!-- Plugins js -->
<script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
<!-- Main js -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script> 
<script type="text/javascript">
$('#search').on('keyup',function(){
$value=$(this).val();
$.ajax({
type : 'get',
url : '<?php echo e(URL::to('search')); ?>',
data:{'search':$value},
success:function(data){
 document.getElementById('search_id').innerHTML = data;
}
});
})
</script>
<script type="text/javascript">
$('#city_search').on('keyup',function(){
$value=$(this).val();
alert('value');
$.ajax({
type : 'get',
url : '<?php echo e(URL::to('search')); ?>',
data:{'city_search':$value},
success:function(data){
 document.getElementById('city_search').innerHTML = data;
}
});
})
</script>
<script type="text/javascript">
$.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
</script>
<script>

    function getProvince() {
        var country_id = document.getElementById('country_id').value;
        if (country_id == null) {
            document.getElementById('country_id').style.border = "1px solid red";
        } else {
            document.getElementById('country_id').style.border = "1px solid #ced4da";
            var data = "country_id=" + country_id;
            $.ajax({
                type: "GET",
                url: '<?php echo e(URL::to('/get-province-name')); ?>',
                data: data,
                success: function (data) {
                    document.getElementById('province_id').innerHTML = data;
                }
            });
        }
    }

    function getCity() {
        var province_id = document.getElementById('province_id').value;
        if (province_id == null) {
            document.getElementById('province_id').style.border = "1px solid red";
        } else {
            document.getElementById('province_id').style.border = "1px solid #ced4da";
            var data = "province_id=" + province_id;
            $.ajax({
                type: "GET",
                url: '<?php echo e(URL::to('/get-city-name')); ?>',
                data: data,
                success: function (data) {
                    document.getElementById('city_id').innerHTML = data;
                }
            });
        }
    }

</script>
</div>
</body>

</html><?php /**PATH E:\xampp\htdocs\PFD\resources\views/index.blade.php ENDPATH**/ ?>