<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title','Home'); ?></title>
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="shortcut icon" href=""/>
    <link rel="stylesheet" href="<?php echo e(asset('css/site.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <script src="<?php echo e(asset('js/html5shiv.js')); ?>"></script>
    <script src="<?php echo e(asset('js/respond.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/site.min.js')); ?>"></script>
    
<!------ Include the above in your HEAD tag ---------->
</head>

<body>
<nav role="navigation" class="navbar navbar-custom">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button data-target="#bs-content-row-navbar-collapse-5" data-toggle="collapse" class="navbar-toggle"
                    type="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="#" style="color:white" class="navbar-brand"><?php echo e(Auth::user()->name); ?></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div id="bs-content-row-navbar-collapse-5" class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">

                <!-- <li class="disabled"><a href="#">Link</a></li> -->
                <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">Notification <sup>43</sup></a>
                    <ul role="menu" class="dropdown-menu">
                        <li id="new_notification"></li>
                    </ul>
                </li>

            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<br>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 sidebar-offcanvas" role="navigation">
            <ul class="list-group panel">
                <li style="color:white ;background-color: steelblue" class="list-group-item"><h3>SIDE PANEL</h3></li>
                <?php if(Auth::user()->status ==0 ): ?>
                <li class="list-group-item">
                    <h5><a href="<?php echo e(route('dashboard')); ?>" style="display: block;">Dashboard</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="<?php echo e(route('my-account.show',Auth::id())); ?>" style="display: block;">My Account</a></h5>
                </li>
               <?php else: ?>
                  <li class="list-group-item">
                    <h5><a href="<?php echo e(route('dashboard')); ?>" style="display: block;">Dashboard</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="<?php echo e(route('my-account.show',Auth::id())); ?>" style="display: block;">My Account</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="<?php echo e(route('expenses.index')); ?>" style="display: block;">Expenses</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="<?php echo e(route('employee.index')); ?>" style="display: block;">Employee</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="<?php echo e(route('food.index')); ?>" style="display: block;">Food</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="<?php echo e(route('schedule.index')); ?>" style="display: block;">Schedule</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="<?php echo e(route('user-menu.index')); ?>" style="display: block;">Menu Setup</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="<?php echo e(route('order-request.index')); ?>" style="display: block;">Order Requests</a></h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="<?php echo e(route('special-order.index')); ?>" style="display: block;">Special Order Requests</a>
                    </h5>
                </li>
                <li class="list-group-item">
                    <h5><a href="<?php echo e(route('order-history.index')); ?>" style="display: block;">Order History</a></h5>
                </li>
                <?php endif; ?>
                <li class="list-group-item">
                    <h5>
                        <a style="display: block;" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                              style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </h5>
                </li>
            </ul>
        </div>
        <div class="col-md-9">
            <?php echo $__env->yieldContent('body_content'); ?>
        </div>
    </div>
</div>


<script src="<?php echo e(asset('js/jquery-1.10.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendor.bundle.addons.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendor.bundle.base.js')); ?>"></script>
<script src="<?php echo e(asset('js/application.js')); ?>"></script>
<script src="<?php echo e(asset('js/icheck.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.fs.selecter.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.fs.stepper.min.js')); ?>"></script>

<?php echo $__env->yieldContent('script_content'); ?>

<script>

    $(document).ready(function () {
        getNewNotifications();
    });

    function getNewNotifications() {
        window.setInterval(getNotification, 5000);
    }

    function getNotification() {
        var data = "user_id=" + <?php echo e(Auth::id()); ?>;
        $.ajax({
            type: "GET",
            url: '<?php echo e(URL::to('/hotel/get-order-notification')); ?>',
            data: data,
            success: function (data) {
                if (data != 1) {
                    var audio = new Audio('<?php echo e(asset('assets/notification.wav')); ?>');
                    audio.play();
                    document.getElementById('new_notification').innerHTML += data;
                }
            }
        });
    }

</script>
<div style="background-color:black" class="footer-section section pt-65 pb-50">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <span class="copyright" style="color:darkgray"><br>ThemeWagon offers an wide array of category-oriented Free and Premium Responsive Bootstrap HTML Templates and WordPress Themes that covers all kinds of templates or themes a developer may need!
                 <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a></span>
                <br>
                <br>
            </div>
        </div>
    </div>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\PFD\resources\views/layouts/admin-template.blade.php ENDPATH**/ ?>