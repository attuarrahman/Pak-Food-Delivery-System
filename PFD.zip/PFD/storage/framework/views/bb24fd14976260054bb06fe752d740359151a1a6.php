<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div style="color:white;background-color: steelblue" class="card-header">
                   <p style="margin-left:15px;">Update Account</p>
                     <br>
                    <br>
                </div>
                <div class="card-body">
              <div class="container">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10">
                    <h3>Register As Hotel</h3>
                    <hr>

                      <?php echo e(Form::open(['method' => 'put', 'action'=>['HotelAccountController@update', Auth::id()], 'role'=>'form', 'files'=>'true'])); ?>

                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name"><?php echo e(__('Hotel Name')); ?></label>
                                    <small style="color: red;"> *</small>
                                    <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="name" placeholder="Hotel Name" value="<?php echo e(Auth::user()->name); ?>"
                                           required autocomplete="name" autofocus>

                                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="password"><?php echo e(__('Password')); ?></label>
                                    <small style="color: red;"> *</small>
                                    <input id="password" type="password"
                                           class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="password"
                                           required autocomplete="new-password" placeholder="Password"
                                           aria-required="true" value="<?php echo e(Auth::user()->password); ?>">

                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Select Country</label>
                                    <small style="color: red;"> *</small>
                                    <select name="country_id" id="country_id" onblur="getProvince()" required
                                            class="form-control <?php if ($errors->has('country_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('country_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <option value="">Select Country</option>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Select City</label>
                                    <small style="color: red;"> *</small>
                                    <select name="city_id" id="city_id" required
                                            class="form-control <?php if ($errors->has('city_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <option value="">Select City</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Phone</label>
                                    <small style="color: red;"> *</small>
                                    <input type="text"
                                           class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> required is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="phone" placeholder="Phone" value="<?php echo e(Auth::user()->phone); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Service</label>
                                    <small style="color: red;"> * Service hotel will provide</small>
                                    <textarea type="text" required
                                              class="form-control <?php if ($errors->has('service')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('service'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                              name="service" placeholder="Service" ><?php echo e(Auth::user()->service); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="">Opening Hours</label>
                                    <small style="color: red;"> * Opening hour of hotel.</small>
                                    <input type="text" required
                                           class="form-control <?php if ($errors->has('opening_timing')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('opening_timing'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="opening_timing" placeholder="Opening Hours" value="<?php echo e(Auth::user()->opening_timing); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Description</label>
                                    <small style="color: red;"> * Full description of hotel.</small>
                                    <textarea type="text" required
                                              class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                              name="description" placeholder="Description" ><?php echo e(Auth::user()->description); ?></textarea>
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Register Account')); ?>

                                    </button> 
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email"><?php echo e(__('E-Mail Address')); ?></label>
                                    <small style="color: red;"> *</small>
                                    <input id="email" type="email"
                                           class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="email" placeholder="Email address" value="<?php echo e(Auth::user()->email); ?>" 
                                           required autocomplete="email" >
                                      
                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="password-confirm"><?php echo e(__('Confirm Password')); ?></label>
                                    <small style="color: red;"> *</small>
                                    <input id="password-confirm" type="password" class="form-control"
                                           name="password_confirmation" value="" placeholder="Confirm Password" required
                                           autocomplete="new-password" >
                                </div>
                                <div class="form-group">
                                    <label for="">Select Province</label>
                                    <small style="color: red;"> *</small>
                                    <select name="province_id" required id="province_id" onblur="getCity()"
                                            class="form-control <?php if ($errors->has('province_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('province_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <option value="">Select Province</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Full Address</label>
                                    <small style="color: red;"> * Full address of hotel.</small>
                                    <textarea type="text" required
                                              class="form-control <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                              name="location" placeholder="Full Address" ><?php echo e(Auth::user()->location); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="">Opening Days</label>
                                    <small style="color: red;"> * Total no of days hotel will be open.</small>
                                    <input type="text" required
                                           class="form-control <?php if ($errors->has('opening_days')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('opening_days'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="opening_days" placeholder="Opening Days" value="<?php echo e(Auth::user()->opening_days); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Closing Hours</label>
                                    <small style="color: red;"> * Closing hour of hotel.</small>
                                    <input type="text" required
                                           class="form-control <?php if ($errors->has('closing_timing')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('closing_timing'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                           name="closing_timing" placeholder="Closing Hours" value="<?php echo e(Auth::user()->closing_timing); ?>">
                                </div>
                                 <div class="form-group">
                                    <label for="">Logo</label>
                                    <small style="color: red;"> * Hotel logo.</small>
                                    <input type="file" required
                                           class="form-control"
                                           name="logo" placeholder="Closing Hours" >
                                </div>
                                 <div class="form-group">
                                    <label for="">Banner</label>
                                    <small style="color: red;"> * Hotel banner.</small>
                                    <input type="file" required
                                           class="form-control"
                                           name="banner" placeholder="Closing Hours" >
                                </div>



                            </div>
                        </div>
                   <?php echo e(Form::close()); ?>

                </div>
                <div class="col-md-1"></div>
            </div>
        </div>
                </div>
            </div>
        </div>
    </div>
<?php echo $__env->yieldContent('script_content'); ?>
<script>

    function getProvince() {
        var country_id = document.getElementById('country_id').value;
        if (country_id == null) {
            document.getElementById('country_id').style.border = "1px solid red";
        } else {
            document.getElementById('country_id').style.border = "1px solid #ced4da";
            var data = "country_id=" + country_id;
            $.ajax({
                type: "GET",
                url: '<?php echo e(URL::to('/get-province-name')); ?>',
                data: data,
                success: function (data) {
                    document.getElementById('province_id').innerHTML = data;
                }
            });
        }
    }

    function getCity() {
        var province_id = document.getElementById('country_id').value;
        if (province_id == null) {
            document.getElementById('province_id').style.border = "1px solid red";
        } else {
            document.getElementById('province_id').style.border = "1px solid #ced4da";
            var data = "province_id=" + province_id;
            $.ajax({
                type: "GET",
                url: '<?php echo e(URL::to('/get-city-name')); ?>',
                data: data,
                success: function (data) {
                    document.getElementById('city_id').innerHTML = data;
                }
            });
        }
    }

</script>
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PFD\resources\views/hotel/my-account/edit.blade.php ENDPATH**/ ?>