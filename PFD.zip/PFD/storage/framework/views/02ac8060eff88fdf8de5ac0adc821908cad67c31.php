<?php $__env->startSection('title','Add Menu'); ?>
<?php $__env->startSection('body_content'); ?>

    <?php if(session('info')): ?>
        <p class="alert alert-success"><?php echo e(session('info')); ?></p>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Add Menu
                    <a href="" class="btn btn-md btn-primary" style="float: right;"></a>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-8">
                            <?php echo e(Form::open(['action' => 'HotelMenuController@store'])); ?>

                            <input type="hidden" name="user_menu_id" value="<?php echo e($userMenu->id); ?>">
                            <div class="form-group">
                                <label for="">Select Food</label>
                                <select name="food_id" class="form-control" required>
                                    <option value="">Select Food</option>
                                    <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($food->id); ?>"><?php echo e($food->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Price</label>
                                <input type="text" name="price" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-md btn-primary">Add</button>
                            </div>
                            <?php echo e(Form::close()); ?>

                        </div>
                        <div class="col-md-4">
                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <h3>Already Added Menu</h3>
                                    <hr>
                                    <?php $i =1; ?>
                                    <?php $__currentLoopData = $userMenu->userMenuDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p>(<?php echo e($i++); ?>) <?php echo e($detail->food->name); ?> | Price: <?php echo e($detail->price); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\OFO\resources\views/hotel/menu/create.blade.php ENDPATH**/ ?>