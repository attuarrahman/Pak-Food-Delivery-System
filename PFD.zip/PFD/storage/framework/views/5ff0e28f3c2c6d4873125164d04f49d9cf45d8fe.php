<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('body_content'); ?>
<style type="text/css">
    
</style>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>
                <div class="card-body">
                    <div class="row">
                       
                            <?php $hotel = DB::table('users')->where('status',2)->get(); ?>
                            <?php $__currentLoopData = $hotel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header" style="background-color: blue; color: white"><?php echo e($hotels->name); ?></div>
                                <div class="card-body">
                                    <img src="<?php echo e(asset('uploads/food/'.$hotels->logo)); ?>" height="100" width="200">
                                    <p class="">Mobile Number|<?php echo e(date('m-Y', strtotime($hotels->created_at))); ?></p>
                                    <div>
                                        <p class="">Deuration</p>
                                    </div>
                                    <a href="<?php echo e(route('hotel.show',$hotels->id)); ?>" class="btn btn-primary">Views</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                 
                    </div>

          </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\OFO\resources\views/admin/Request_hotel/index.blade.php ENDPATH**/ ?>