<?php $__env->startSection('title','Forgot Password'); ?>
<?php $__env->startSection('body_content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-2">
                <div class="panel panel-primary">
                    <div class="panel-heading">Search Your Account</div>
                    <div class="panel-body" id="result-response">
                        <?php if(Session::has('status')): ?>
                            <p class="alert alert-primary"><?php echo e(Session('status')); ?></p>
                        <?php endif; ?>
                        <div class="form-group">
                            <label for="email">Enter Email OR Phone number</label>
                            <small style="color: red;">enter email or phone which you entered in profile updation.</small>
                            <input id="email" type="text"
                                   class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                   name="email" required placeholder="Email or Phone" style="border: 1px solid black;">

                            <span class="invalid-feedback" role="alert">
                                <strong id="error-response"></strong>
                            </span>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary" onclick="checkAccount()">
                                <?php echo e(__('Search your account')); ?>

                            </button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_content'); ?>

    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        function checkAccount() {
            var email = $('#email').val();
            if (email == '') {
                document.getElementById('email').style.border = "1px solid red";
            } else {
                document.getElementById('email').style.border = "1px solid #ddd";
                var data = "data=" + email;
                $.ajax({
                    type: "GET",
                    url: '<?php echo e(URL::to('/check-account')); ?>',
                    data: data,
                    success: function (data) {
                        if (data == 0) {
                            document.getElementById('error-response').innerHTML = "No record found";
                        } else {
                            document.getElementById('error-response').innerHTML = "";
                            document.getElementById('result-response').innerHTML = data;
                        }
                    }
                });
            }
        }

    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\PFD\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>