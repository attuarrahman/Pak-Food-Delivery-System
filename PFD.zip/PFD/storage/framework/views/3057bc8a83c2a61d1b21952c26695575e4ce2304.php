<?php $__env->startSection('title','Product Details'); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="shop_header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>Product Details</h1>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <?php if(session('info')): ?>
        <p class="alert alert-success"><?php echo e(session('info')); ?></p>
    <?php endif; ?>
    <?php if(session('warning')): ?>
        <p class="alert alert-warning"><?php echo e(session('warning')); ?></p>
    <?php endif; ?>
    <div class="product_details">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-5">
                    <div class="product-details-tab">

                        <div id="img-1" class="zoomWrapper single-zoom">
                            <a href="#">
                                <img id="zoom1" src="<?php echo e(asset('uploads/food/'.$product->image)); ?>">
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 col-md-7">
                    <div class="product_d_right">
                        <h1><?php echo e($product->name); ?></h1>
                        <div class="product_price">
                            <span class="current_price">Rs. <?php echo e($product->userMenuDetail->price); ?></span>
                            <?php if($product->userMenuDetail->price != $product->price): ?>
                                <span class="old_price">Rs. <?php echo e($product->price); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="product_desc">
                            <p><?php echo e($product->description); ?></p>
                        </div>
                        <?php echo e(Form::open(['action' => 'HomeCartController@store'])); ?>

                        <input type="hidden" name="price" value="<?php echo e($product->userMenuDetail->price); ?>">
                        <input type="hidden" name="food_id" value="<?php echo e($product->id); ?>">
                        <div class="form-group">
                            <label for="">No of Parsal</label>
                            <input type="number" name="quantity" min="1" max="5" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-md btn-success">Add to Cart</button>
                            |
                            Price are count on per parsal
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
                <div class="col-lg-3 offset-lg-0 col-md-6 offset-md-3">
                    <div class="best_seller_product">
                        <div class="best_seller_titile">
                            <h3>Recent Rating</h3>
                            <div class="single_bestseller slick-slide slick-cloned slick-active" data-slick-index="-1"
                                 aria-hidden="false" tabindex="-1" style="width: 238px;">
                                <div class="bestseller_thumb">
                                    <a href="product-details.html" tabindex="0">
                                        <img class="primary_img" src="">
                                    </a>
                                </div>
                                <div class="bestseller_content">
                                    <div class="product_ratting">
                                        <ul>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\OFO\resources\views/links/product/show.blade.php ENDPATH**/ ?>