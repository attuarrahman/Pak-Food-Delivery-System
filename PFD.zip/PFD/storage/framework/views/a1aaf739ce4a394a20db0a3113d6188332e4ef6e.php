<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('body_content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    All
                    <a href="" class="btn btn-md btn-primary" style="float: right;">

                    </a>
                </div>
                <div class="card-body">

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OFO\resources\views/hotel/messenger/index.blade.php ENDPATH**/ ?>